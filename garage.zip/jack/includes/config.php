<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'garage_management');

// Site configuration
define('SITE_NAME', 'Parking Management System');
define('SITE_URL', 'http://localhost/jack');

// Session configuration - Must be set before any session starts
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_secure', 1);

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    // Set session cookie parameters
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => '',
        'secure' => isset($_SERVER['HTTPS']),
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    
    session_start();
}

// Initialize database connection
try {
    $conn = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Check for maintenance mode
function checkMaintenanceMode() {
    global $conn;
    
    // Get the current page
    $current_page = basename($_SERVER['PHP_SELF']);
    
    // Don't check maintenance mode for these pages
    $excluded_pages = ['maintenance.php'];
    
    if (in_array($current_page, $excluded_pages)) {
        return;
    }
    
    try {
        // Check if maintenance mode is enabled
        $stmt = $conn->prepare("SELECT setting_value FROM settings WHERE setting_key = 'maintenance_mode'");
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($result && $result['setting_value'] == '1') {
            // Allow access to login page
            if ($current_page === 'login.php') {
                // If it's a login attempt, check if it's an admin
                if (isset($_POST['email'])) {
                    $stmt = $conn->prepare("SELECT role FROM users WHERE email = ?");
                    $stmt->execute([$_POST['email']]);
                    $user = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    if ($user && $user['role'] === 'admin') {
                        return; // Allow admin to log in
                    }
                } else {
                    return; // Allow access to login page
                }
            }
            
            // Allow access to admin pages if user is logged in as admin
            if (isset($_SESSION['user_id']) && isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin') {
                return;
            }
            
            // For all other cases, redirect to maintenance page
            header('Location: maintenance.php');
            exit();
        }
    } catch (PDOException $e) {
        // If there's a database error, log it and assume maintenance mode is off
        error_log("Maintenance mode check error: " . $e->getMessage());
        return;
    }
}

// Check maintenance mode
checkMaintenanceMode();

// Error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Timezone
date_default_timezone_set('UTC');
?> 