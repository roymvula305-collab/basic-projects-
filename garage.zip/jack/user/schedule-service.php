<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/db.php';

// Check if user is logged in
if (!$auth->isLoggedIn() || $auth->isAdmin()) {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$db = new Database();
$conn = $db->getConnection();

// Get user's vehicles
$stmt = $conn->prepare("SELECT * FROM vehicles WHERE user_id = ? ORDER BY make, model");
$stmt->execute([$user_id]);
$vehicles = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get available services
$stmt = $conn->query("SELECT * FROM services ORDER BY name");
$services = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle form submission
$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $vehicle_id = $_POST['vehicle_id'] ?? '';
    $service_id = $_POST['service_id'] ?? '';
    $appointment_date = $_POST['appointment_date'] ?? '';
    $appointment_time = $_POST['appointment_time'] ?? '';
    $notes = $_POST['notes'] ?? '';

    // Validate inputs
    if (empty($vehicle_id)) {
        $errors[] = "Please select a vehicle";
    }
    if (empty($service_id)) {
        $errors[] = "Please select a service";
    }
    if (empty($appointment_date)) {
        $errors[] = "Please select an appointment date";
    }
    if (empty($appointment_time)) {
        $errors[] = "Please select an appointment time";
    }

    // Check if the selected date and time is in the future
    $appointment_datetime = $appointment_date . ' ' . $appointment_time;
    if (strtotime($appointment_datetime) <= time()) {
        $errors[] = "Please select a future date and time";
    }

    // Check if the selected date is not more than 30 days in the future
    if (strtotime($appointment_date) > strtotime('+30 days')) {
        $errors[] = "Appointments can only be scheduled up to 30 days in advance";
    }

    // Check service bay availability
    if (empty($errors)) {
        // Find an available service bay for the selected time
        $stmt = $conn->prepare("
            SELECT sb.id 
            FROM service_bays sb
            LEFT JOIN service_appointments sa ON sa.bay_id = sb.id 
                AND sa.appointment_date = ? 
                AND sa.start_time = ?
                AND sa.status IN ('scheduled', 'in_progress')
            WHERE sb.status = 'available'
            AND sa.id IS NULL
            LIMIT 1
        ");
        $stmt->execute([$appointment_date, $appointment_time]);
        $available_bay = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$available_bay) {
            $errors[] = "No service bays available at the selected time. Please choose another time.";
        } else {
            // Get service duration
            $stmt = $conn->prepare("SELECT estimated_duration, base_price FROM services WHERE id = ?");
            $stmt->execute([$service_id]);
            $service = $stmt->fetch(PDO::FETCH_ASSOC);

            // Calculate end time
            $end_time = date('H:i:s', strtotime($appointment_time . ' + ' . $service['estimated_duration'] . ' minutes'));

            // Create the appointment
            try {
                $stmt = $conn->prepare("
                    INSERT INTO service_appointments (
                        user_id, vehicle_id, service_id, bay_id,
                        appointment_date, start_time, end_time,
                        status, notes, estimated_cost
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, 'scheduled', ?, ?)
                ");
                $stmt->execute([
                    $user_id,
                    $vehicle_id,
                    $service_id,
                    $available_bay['id'],
                    $appointment_date,
                    $appointment_time,
                    $end_time,
                    $notes,
                    $service['base_price']
                ]);

                $success = true;
                header('Location: appointment-confirmation.php?id=' . $conn->lastInsertId());
                exit();
            } catch (PDOException $e) {
                $errors[] = "Error scheduling appointment: " . $e->getMessage();
            }
        }
    }
}

// Get business hours from settings
$stmt = $conn->query("SELECT setting_value FROM settings WHERE setting_key = 'business_hours'");
$business_hours = json_decode($stmt->fetch(PDO::FETCH_ASSOC)['setting_value'], true);

// Get today's day of week
$today = strtolower(date('l'));
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Schedule Service - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <div class="container py-4">
        <div class="row mb-4">
            <div class="col">
                <h1>Schedule Service</h1>
            </div>
        </div>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo htmlspecialchars($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-body">
                        <form method="POST" action="">
                            <!-- Vehicle Selection -->
                            <div class="mb-4">
                                <label class="form-label">Select Vehicle</label>
                                <?php if (empty($vehicles)): ?>
                                    <p class="text-muted">No vehicles registered. <a href="add-vehicle.php">Add a vehicle</a> first.</p>
                                <?php else: ?>
                                    <?php foreach ($vehicles as $vehicle): ?>
                                        <div class="form-check mb-2">
                                            <input class="form-check-input" type="radio" name="vehicle_id" 
                                                   value="<?php echo $vehicle['id']; ?>" 
                                                   id="vehicle_<?php echo $vehicle['id']; ?>"
                                                   <?php echo isset($_POST['vehicle_id']) && $_POST['vehicle_id'] == $vehicle['id'] ? 'checked' : ''; ?>>
                                            <label class="form-check-label" for="vehicle_<?php echo $vehicle['id']; ?>">
                                                <?php echo htmlspecialchars($vehicle['make'] . ' ' . $vehicle['model']); ?>
                                                (<?php echo htmlspecialchars($vehicle['vehicle_number']); ?>)
                                            </label>
                                        </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>

                            <!-- Service Selection -->
                            <div class="mb-4">
                                <label class="form-label">Select Service</label>
                                <?php foreach ($services as $service): ?>
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="radio" name="service_id" 
                                               value="<?php echo $service['id']; ?>" 
                                               id="service_<?php echo $service['id']; ?>"
                                               <?php echo isset($_POST['service_id']) && $_POST['service_id'] == $service['id'] ? 'checked' : ''; ?>>
                                        <label class="form-check-label" for="service_<?php echo $service['id']; ?>">
                                            <?php echo htmlspecialchars($service['name']); ?>
                                            - $<?php echo number_format($service['base_price'], 2); ?>
                                            (<?php echo $service['estimated_duration']; ?> minutes)
                                        </label>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- Appointment Date and Time -->
                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <label class="form-label">Appointment Date</label>
                                    <input type="date" class="form-control" name="appointment_date" 
                                           min="<?php echo date('Y-m-d'); ?>" 
                                           max="<?php echo date('Y-m-d', strtotime('+30 days')); ?>"
                                           value="<?php echo $_POST['appointment_date'] ?? ''; ?>" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Appointment Time</label>
                                    <select class="form-select" name="appointment_time" required>
                                        <option value="">Select time</option>
                                        <?php
                                        // Generate time slots based on business hours
                                        if (isset($business_hours[$today])) {
                                            list($start, $end) = explode('-', $business_hours[$today]);
                                            $start_time = strtotime($start);
                                            $end_time = strtotime($end);
                                            
                                            for ($time = $start_time; $time <= $end_time; $time += 1800) { // 30-minute intervals
                                                $slot = date('H:i:s', $time);
                                                echo '<option value="' . $slot . '"' . 
                                                     (isset($_POST['appointment_time']) && $_POST['appointment_time'] == $slot ? ' selected' : '') . 
                                                     '>' . date('h:i A', $time) . '</option>';
                                            }
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>

                            <!-- Additional Notes -->
                            <div class="mb-4">
                                <label class="form-label">Additional Notes</label>
                                <textarea class="form-control" name="notes" rows="3" 
                                          placeholder="Please describe any specific issues or concerns"><?php echo $_POST['notes'] ?? ''; ?></textarea>
                            </div>

                            <div class="text-end">
                                <a href="dashboard.php" class="btn btn-link">Cancel</a>
                                <button type="submit" class="btn btn-primary">Schedule Service</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Business Hours</h5>
                        <ul class="list-unstyled">
                            <?php foreach ($business_hours as $day => $hours): ?>
                                <li class="mb-2">
                                    <strong><?php echo ucfirst($day); ?>:</strong>
                                    <?php echo $hours === 'closed' ? 'Closed' : str_replace('-', ' - ', $hours); ?>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>

                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Need Help?</h5>
                        <p class="card-text">If you're unsure about which service you need, our expert mechanics can help diagnose your vehicle's issues.</p>
                        <p class="mb-0">
                            <i class="fas fa-phone me-2"></i> Call us: (123) 456-7890<br>
                            <i class="fas fa-envelope me-2"></i> Email: service@garage.com
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 