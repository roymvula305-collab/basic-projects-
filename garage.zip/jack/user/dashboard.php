<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/db.php';

// Check if user is logged in
if (!$auth->isLoggedIn() || $auth->isAdmin()) {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$db = new Database();
$conn = $db->getConnection();

// Get user's vehicles
$stmt = $conn->prepare("
    SELECT * FROM vehicles 
    WHERE user_id = ?
    ORDER BY created_at DESC
");
$stmt->execute([$user_id]);
$vehicles = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get upcoming appointments
$stmt = $conn->prepare("
    SELECT sa.*, s.name as service_name, v.vehicle_number, v.make, v.model,
           m.name as mechanic_name, sb.bay_number
    FROM service_appointments sa
    JOIN services s ON sa.service_id = s.id
    JOIN vehicles v ON sa.vehicle_id = v.id
    LEFT JOIN mechanics m ON sa.mechanic_id = m.user_id
    JOIN service_bays sb ON sa.bay_id = sb.id
    WHERE sa.user_id = ? AND sa.status IN ('scheduled', 'in_progress')
    ORDER BY sa.appointment_date ASC, sa.start_time ASC
    LIMIT 5
");
$stmt->execute([$user_id]);
$upcoming_appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get service history
$stmt = $conn->prepare("
    SELECT sa.*, s.name as service_name, v.vehicle_number, v.make, v.model,
           m.name as mechanic_name
    FROM service_appointments sa
    JOIN services s ON sa.service_id = s.id
    JOIN vehicles v ON sa.vehicle_id = v.id
    LEFT JOIN mechanics m ON sa.mechanic_id = m.user_id
    WHERE sa.user_id = ? AND sa.status = 'completed'
    ORDER BY sa.appointment_date DESC
    LIMIT 5
");
$stmt->execute([$user_id]);
$service_history = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get vehicle maintenance alerts
$stmt = $conn->prepare("
    SELECT v.*, 
           DATEDIFF(v.next_service_date, CURDATE()) as days_until_service
    FROM vehicles v
    WHERE v.user_id = ? 
    AND v.next_service_date IS NOT NULL
    AND v.next_service_date <= DATE_ADD(CURDATE(), INTERVAL 30 DAY)
    ORDER BY v.next_service_date ASC
");
$stmt->execute([$user_id]);
$maintenance_alerts = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get recent announcements
$stmt = $conn->query("
    SELECT * FROM announcements 
    WHERE (recipient_type = 'all' OR (recipient_type = 'specific' AND recipient_id = ?))
    AND (expires_at IS NULL OR expires_at > NOW())
    ORDER BY created_at DESC 
    LIMIT 3
");
$stmt->execute([$user_id]);
$announcements = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
    <style>
        .dashboard-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .vehicle-card {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 15px;
            transition: transform 0.3s ease;
        }
        .vehicle-card:hover {
            transform: translateY(-5px);
        }
        .appointment-card {
            border-left: 4px solid #007bff;
            padding: 15px;
            margin-bottom: 15px;
            background: white;
            border-radius: 0 5px 5px 0;
        }
        .service-history-item {
            border-bottom: 1px solid #dee2e6;
            padding: 15px 0;
        }
        .service-history-item:last-child {
            border-bottom: none;
        }
        .alert-maintenance {
            background-color: #fff3cd;
            border-color: #ffecb5;
            color: #664d03;
        }
        .stats-icon {
            font-size: 2rem;
            margin-bottom: 10px;
            color: #007bff;
        }
    </style>
</head>
<body>
    <div class="container py-4">
        <div class="row mb-4">
            <div class="col-md-6">
                <h1>Welcome Back, <?php echo htmlspecialchars($_SESSION['user_name']); ?></h1>
            </div>
            <div class="col-md-6 text-end">
                <a href="schedule-service.php" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Schedule Service
                </a>
                <a href="add-vehicle.php" class="btn btn-outline-primary">
                    <i class="fas fa-car"></i> Add Vehicle
                </a>
            </div>
        </div>

        <!-- Maintenance Alerts -->
        <?php if (!empty($maintenance_alerts)): ?>
        <div class="row mb-4">
            <div class="col-12">
                <div class="dashboard-card">
                    <h4><i class="fas fa-exclamation-triangle text-warning"></i> Maintenance Alerts</h4>
                    <?php foreach ($maintenance_alerts as $alert): ?>
                        <div class="alert alert-maintenance mb-2">
                            <strong><?php echo htmlspecialchars($alert['make'] . ' ' . $alert['model']); ?></strong>
                            (<?php echo htmlspecialchars($alert['vehicle_number']); ?>)
                            <?php if ($alert['days_until_service'] <= 0): ?>
                                is <strong>overdue</strong> for service
                            <?php else: ?>
                                needs service in <strong><?php echo $alert['days_until_service']; ?> days</strong>
                            <?php endif; ?>
                            <a href="schedule-service.php?vehicle_id=<?php echo $alert['id']; ?>" class="btn btn-sm btn-warning float-end">
                                Schedule Service
                            </a>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <div class="row">
            <!-- Upcoming Appointments -->
            <div class="col-md-8">
                <div class="dashboard-card">
                    <h4 class="mb-4">Upcoming Appointments</h4>
                    <?php if (empty($upcoming_appointments)): ?>
                        <p class="text-muted">No upcoming appointments</p>
                    <?php else: ?>
                        <?php foreach ($upcoming_appointments as $appointment): ?>
                            <div class="appointment-card">
                                <div class="row">
                                    <div class="col-md-8">
                                        <h5><?php echo htmlspecialchars($appointment['service_name']); ?></h5>
                                        <p class="mb-1">
                                            <i class="fas fa-car text-muted"></i>
                                            <?php echo htmlspecialchars($appointment['make'] . ' ' . $appointment['model']); ?>
                                            (<?php echo htmlspecialchars($appointment['vehicle_number']); ?>)
                                        </p>
                                        <p class="mb-1">
                                            <i class="fas fa-calendar text-muted"></i>
                                            <?php echo date('M d, Y', strtotime($appointment['appointment_date'])); ?>
                                            at <?php echo date('h:i A', strtotime($appointment['start_time'])); ?>
                                        </p>
                                        <p class="mb-1">
                                            <i class="fas fa-user-cog text-muted"></i>
                                            Mechanic: <?php echo $appointment['mechanic_name'] ?? 'To be assigned'; ?>
                                        </p>
                                        <p class="mb-0">
                                            <i class="fas fa-warehouse text-muted"></i>
                                            Bay: <?php echo htmlspecialchars($appointment['bay_number']); ?>
                                        </p>
                                    </div>
                                    <div class="col-md-4 text-end">
                                        <span class="badge bg-<?php echo $appointment['status'] === 'in_progress' ? 'success' : 'primary'; ?>">
                                            <?php echo ucfirst($appointment['status']); ?>
                                        </span>
                                        <?php if ($appointment['status'] === 'scheduled'): ?>
                                            <a href="reschedule-appointment.php?id=<?php echo $appointment['id']; ?>" class="btn btn-sm btn-outline-primary mt-2">
                                                Reschedule
                                            </a>
                                            <a href="cancel-appointment.php?id=<?php echo $appointment['id']; ?>" class="btn btn-sm btn-outline-danger mt-2">
                                                Cancel
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                        <div class="text-end mt-3">
                            <a href="my-appointments.php" class="btn btn-link">View All Appointments</a>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Service History -->
                <div class="dashboard-card">
                    <h4 class="mb-4">Recent Service History</h4>
                    <?php if (empty($service_history)): ?>
                        <p class="text-muted">No service history available</p>
                    <?php else: ?>
                        <?php foreach ($service_history as $service): ?>
                            <div class="service-history-item">
                                <div class="row">
                                    <div class="col-md-8">
                                        <h5><?php echo htmlspecialchars($service['service_name']); ?></h5>
                                        <p class="mb-1">
                                            <i class="fas fa-car text-muted"></i>
                                            <?php echo htmlspecialchars($service['make'] . ' ' . $service['model']); ?>
                                            (<?php echo htmlspecialchars($service['vehicle_number']); ?>)
                                        </p>
                                        <p class="mb-1">
                                            <i class="fas fa-calendar text-muted"></i>
                                            <?php echo date('M d, Y', strtotime($service['appointment_date'])); ?>
                                        </p>
                                        <p class="mb-0">
                                            <i class="fas fa-user-cog text-muted"></i>
                                            Mechanic: <?php echo htmlspecialchars($service['mechanic_name']); ?>
                                        </p>
                                    </div>
                                    <div class="col-md-4 text-end">
                                        <h6 class="mb-2">Total Cost: $<?php echo number_format($service['final_cost'], 2); ?></h6>
                                        <a href="view-service-details.php?id=<?php echo $service['id']; ?>" class="btn btn-sm btn-outline-primary">
                                            View Details
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                        <div class="text-end mt-3">
                            <a href="service-history.php" class="btn btn-link">View Full History</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Right Sidebar -->
            <div class="col-md-4">
                <!-- My Vehicles -->
                <div class="dashboard-card">
                    <h4 class="mb-4">My Vehicles</h4>
                    <?php if (empty($vehicles)): ?>
                        <p class="text-muted">No vehicles registered</p>
                        <a href="add-vehicle.php" class="btn btn-primary btn-sm">Add Vehicle</a>
                    <?php else: ?>
                        <?php foreach ($vehicles as $vehicle): ?>
                            <div class="vehicle-card">
                                <h5><?php echo htmlspecialchars($vehicle['make'] . ' ' . $vehicle['model']); ?></h5>
                                <p class="mb-1">
                                    <strong>Vehicle Number:</strong> <?php echo htmlspecialchars($vehicle['vehicle_number']); ?>
                                </p>
                                <p class="mb-1">
                                    <strong>Type:</strong> <?php echo ucfirst($vehicle['vehicle_type']); ?>
                                </p>
                                <p class="mb-0">
                                    <strong>Last Service:</strong>
                                    <?php echo $vehicle['last_service_date'] ? date('M d, Y', strtotime($vehicle['last_service_date'])) : 'Never'; ?>
                                </p>
                                <div class="mt-2">
                                    <a href="vehicle-details.php?id=<?php echo $vehicle['id']; ?>" class="btn btn-sm btn-outline-primary">View Details</a>
                                    <a href="schedule-service.php?vehicle_id=<?php echo $vehicle['id']; ?>" class="btn btn-sm btn-primary">Schedule Service</a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                        <div class="text-end mt-3">
                            <a href="my-vehicles.php" class="btn btn-link">Manage Vehicles</a>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Announcements -->
                <div class="dashboard-card">
                    <h4 class="mb-4">Announcements</h4>
                    <?php if (empty($announcements)): ?>
                        <p class="text-muted">No announcements</p>
                    <?php else: ?>
                        <?php foreach ($announcements as $announcement): ?>
                            <div class="mb-3">
                                <h6><?php echo htmlspecialchars($announcement['title']); ?></h6>
                                <p class="small text-muted mb-1">
                                    <?php echo date('M d, Y', strtotime($announcement['created_at'])); ?>
                                </p>
                                <p class="mb-0"><?php echo htmlspecialchars($announcement['message']); ?></p>
                            </div>
                        <?php endforeach; ?>
                        <div class="text-end mt-3">
                            <a href="announcements.php" class="btn btn-link">View All</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
        
        .building-entrance {
            background: #FF5722;
            color: white;
            padding: 12px 20px;
            border-radius: 8px;
            margin: 15px 0;
            display: inline-flex;
            align-items: center;
            gap: 12px;
            font-weight: bold;
            font-size: 1.2em;
            text-transform: uppercase;
            letter-spacing: 1px;
            border: 2px solid #E64A19;
        }
        
        .building-entrance i {
            font-size: 1.5em;
        }
        
        .current-time {
            color: rgba(255, 255, 255, 0.9);
            font-size: 1.1em;
            margin-top: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .current-time i {
            color: #ffd700;
        }
        
        /* Responsive Design */
        @media (max-width: 768px) {
            .dashboard-container {
                grid-template-columns: 1fr;
                padding: 10px;
                gap: 15px;
            }
            
            .dashboard-header {
                padding: 15px;
            }
            
            .welcome-section {
                flex-direction: column;
                text-align: center;
            }
            
            .user-stats {
                flex-direction: column;
                gap: 10px;
                margin-top: 15px;
            }
            
            .stat-card {
                width: 100%;
                min-width: auto;
            }
            
            .quick-actions {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .quick-action-btn {
                padding: 10px;
            }
            
            .quick-action-btn i {
                font-size: 20px;
            }
            
            .parking-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 8px;
            }
            
            .parking-slot {
                min-height: 60px;
                padding: 8px;
            }
            
            .floor-navigation {
                flex-wrap: wrap;
                gap: 5px;
            }
            
            .floor-btn {
                padding: 5px 10px;
                font-size: 0.9em;
            }
            
            .building-entrance {
                font-size: 1em;
                padding: 8px 15px;
            }
            
            .announcements-list {
                max-height: 200px;
            }
            
            .booking-item {
                flex-direction: column;
                gap: 10px;
            }
            
            .booking-actions {
                width: 100%;
                justify-content: center;
            }
            
            .current-time {
                font-size: 1em;
                justify-content: center;
            }
            
            .card-header {
                flex-direction: column;
                gap: 10px;
            }
            
            .card-header h3 {
                font-size: 1.2em;
            }
            
            .btn-sm {
                padding: 0.25rem 0.5rem;
                font-size: 0.875rem;
            }
        }
        
        @media (max-width: 480px) {
            .quick-actions {
                grid-template-columns: 1fr;
            }
            
            .parking-grid {
                grid-template-columns: 1fr;
            }
            
            .dashboard-header h2 {
                font-size: 1.5em;
            }
            
            .stat-card h3 {
                font-size: 1.2em;
            }
        }
        
        /* Ensure text remains readable on small screens */
        .parking-slot {
            font-size: clamp(0.8rem, 2vw, 1rem);
        }
        
        /* Prevent horizontal scrolling */
        body {
            overflow-x: hidden;
        }
        
        .overdue-bookings {
            margin-bottom: 20px;
        }
        
        .overdue-bookings .booking-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 8px;
            background-color: #fff3f3;
            border: 1px solid #ffcdd2;
        }
        
        .overdue-bookings .booking-info {
            flex: 1;
        }
        
        .overdue-bookings .booking-info h5 {
            color: #d32f2f;
            margin-bottom: 10px;
        }
        
        .overdue-bookings .booking-info p {
            margin-bottom: 5px;
            color: #333;
        }
        
        .overdue-bookings .booking-info .text-danger {
            font-size: 1.1em;
            margin-top: 10px;
        }
        
        .overdue-bookings .booking-actions {
            margin-left: 20px;
        }
        
        .overdue-bookings .btn-danger {
            background: #d32f2f;
            border: none;
            padding: 8px 20px;
            transition: all 0.3s ease;
        }
        
        .overdue-bookings .btn-danger:hover {
            background: #b71c1c;
            transform: translateY(-2px);
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }
        
        .ending-soon-bookings {
            margin-bottom: 20px;
        }
        
        .ending-soon-bookings .booking-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 8px;
            background-color: #fff8e1;
            border: 1px solid #ffe0b2;
        }
        
        .ending-soon-bookings .booking-info {
            flex: 1;
        }
        
        .ending-soon-bookings .booking-info h5 {
            color: #f57c00;
            margin-bottom: 10px;
        }
        
        .ending-soon-bookings .booking-info p {
            margin-bottom: 5px;
            color: #333;
        }
        
        .ending-soon-bookings .booking-info .text-warning {
            font-size: 1.1em;
            margin-top: 10px;
        }
        
        .ending-soon-bookings .booking-actions {
            margin-left: 20px;
        }
        
        .ending-soon-bookings .btn-warning {
            background: #ff9800;
            border: none;
            padding: 8px 20px;
            transition: all 0.3s ease;
        }
        
        .ending-soon-bookings .btn-warning:hover {
            background: #f57c00;
            transform: translateY(-2px);
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }
        
        .profile-picture-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 10px;
            border: 2px solid #1e3c72;
        }
    </style>
</head>
<body>
    <?php include '../includes/user-nav.php'; ?>
    
    <div class="dashboard-container">
        <div class="dashboard-header">
            <div class="welcome-section">
                <div>
                    <h2>Welcome, <?php echo htmlspecialchars($user['name']); ?>!</h2>
                    <p>Here's what's happening today</p>
                    <div class="current-time">
                        <i class="fas fa-clock"></i>
                        <span id="currentDateTime"></span>
                    </div>
            </div>
                <div class="user-stats">
                    <div class="stat-card">
                        <i class="fas fa-car"></i>
                        <h3><?php echo count($vehicles); ?></h3>
                        <p>Vehicles</p>
        </div>
                    <div class="stat-card">
                        <i class="fas fa-calendar-check"></i>
                        <h3><?php echo count($active_bookings); ?></h3>
                        <p>Active Bookings</p>
                    </div>
                    <div class="stat-card">
                        <i class="fas fa-bell"></i>
                        <h3><?php echo $unread_count; ?></h3>
                        <p>Unread Notifications</p>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="main-content">
            <div class="quick-actions">
                <div class="quick-action-btn" onclick="window.location.href='profile.php'">
                    <?php if (!empty($user['profile_picture'])): ?>
                        <img src="../<?php echo htmlspecialchars($user['profile_picture']); ?>" 
                             alt="Profile Picture" 
                             class="profile-picture-icon">
                    <?php else: ?>
                        <i class="fas fa-user-circle"></i>
                    <?php endif; ?>
                    <p>Profile</p>
                </div>
                <div class="quick-action-btn" onclick="window.location.href='book-slot.php'">
                    <i class="fas fa-plus-circle"></i>
                    <p>Book Slot</p>
                </div>
                <div class="quick-action-btn" onclick="window.location.href='my-vehicles.php'">
                    <i class="fas fa-car"></i>
                    <p>My Vehicles</p>
                </div>
                <div class="quick-action-btn" onclick="window.location.href='my-bookings.php'">
                    <i class="fas fa-list"></i>
                    <p>My Bookings</p>
                </div>
            </div>
            
            <?php if (!empty($ending_soon_bookings)): ?>
            <div class="dashboard-card">
                <div class="card-header">
                    <h3><i class="fas fa-clock text-warning me-2"></i>Bookings Ending Soon</h3>
                </div>
                <div class="ending-soon-bookings">
                    <?php foreach ($ending_soon_bookings as $booking): ?>
                    <div class="booking-item alert alert-warning">
                        <div class="booking-info">
                            <h5>Slot <?php echo htmlspecialchars($booking['slot_number']); ?></h5>
                            <p>Floor <?php echo htmlspecialchars($booking['floor']); ?> - <?php echo ucfirst($booking['type']); ?></p>
                            <p>Vehicle: <?php echo htmlspecialchars($booking['vehicle_number']); ?> 
                               (<?php echo htmlspecialchars($booking['vehicle_type']); ?> 
                                <?php echo htmlspecialchars($booking['vehicle_model']); ?>)</p>
                            <p class="text-warning"><strong>Time Remaining: <?php echo $booking['minutes_remaining']; ?> minutes</strong></p>
                            <p class="text-warning"><strong>Ends at: <?php echo date('H:i', strtotime($booking['end_time'])); ?></strong></p>
                        </div>
                        <div class="booking-actions">
                            <a href="check-out.php?id=<?php echo $booking['id']; ?>" class="btn btn-warning">
                                <i class="fas fa-sign-out-alt me-2"></i>Check Out Now
                            </a>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

            <?php if (!empty($overdue_bookings)): ?>
            <div class="dashboard-card">
                <div class="card-header">
                    <h3><i class="fas fa-exclamation-triangle text-danger me-2"></i>Overdue Bookings</h3>
                </div>
                <div class="overdue-bookings">
                    <?php foreach ($overdue_bookings as $booking): ?>
                    <div class="booking-item alert alert-danger">
                        <div class="booking-info">
                            <h5>Slot <?php echo htmlspecialchars($booking['slot_number']); ?></h5>
                            <p>Floor <?php echo htmlspecialchars($booking['floor']); ?> - <?php echo ucfirst($booking['type']); ?></p>
                            <p>Vehicle: <?php echo htmlspecialchars($booking['vehicle_number']); ?> 
                               (<?php echo htmlspecialchars($booking['vehicle_type']); ?> 
                                <?php echo htmlspecialchars($booking['vehicle_model']); ?>)</p>
                            <p class="text-danger"><strong>Overdue: <?php echo $booking['overdue_hours']; ?> hours</strong></p>
                            <p class="text-danger"><strong>Penalty: K<?php echo number_format($booking['penalty_amount'], 2); ?></strong></p>
                        </div>
                        <div class="booking-actions">
                            <a href="check-out.php?id=<?php echo $booking['id']; ?>" class="btn btn-danger">
                                <i class="fas fa-sign-out-alt me-2"></i>Check Out Now
                            </a>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

            <div class="dashboard-card">
                <div class="card-header">
                    <h3>Upcoming Bookings</h3>
                    <a href="my-bookings.php" class="btn btn-sm btn-primary">View All</a>
                </div>
                <div class="upcoming-bookings">
                        <?php if (empty($active_bookings)): ?>
                        <p class="text-muted">No upcoming bookings</p>
                        <?php else: ?>
                                        <?php foreach ($active_bookings as $booking): ?>
                            <div class="booking-item">
                                <div class="booking-info">
                                    <h5>Slot <?php echo htmlspecialchars($booking['slot_number']); ?></h5>
                                    <p>Floor <?php echo htmlspecialchars($booking['floor']); ?> - <?php echo ucfirst($booking['type']); ?></p>
                                    <small>Ends: <?php echo date('M d, Y H:i', strtotime($booking['end_time'])); ?></small>
                                </div>
                                <div class="booking-actions">
                                    <a href="view-receipt.php?id=<?php echo $booking['id']; ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-receipt"></i>
                                    </a>
                                    <a href="check-out.php?id=<?php echo $booking['id']; ?>" class="btn btn-sm btn-outline-danger">
                                        <i class="fas fa-sign-out-alt"></i>
                                                </a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                        <?php endif; ?>
            </div>
        </div>

            <div class="parking-layout">
            <div class="card-header">
                    <h3>Parking Layout</h3>
                    <div class="building-entrance">
                        <i class="fas fa-door-open"></i>
                        <span>MAIN ENTRANCE</span>
                    </div>
                    <div class="floor-navigation">
                        <?php foreach ($slots_by_floor as $floor => $slots): ?>
                            <button class="floor-btn <?php echo $floor === 1 ? 'active' : ''; ?>" 
                                    onclick="showFloor(<?php echo $floor; ?>)">
                                Floor <?php echo $floor; ?>
                            </button>
                        <?php endforeach; ?>
            </div>
        </div>

                <?php foreach ($slots_by_floor as $floor => $slots): ?>
                    <div class="floor-section" id="floor-<?php echo $floor; ?>" 
                         style="display: <?php echo $floor === 1 ? 'block' : 'none'; ?>;">
                        <div class="parking-grid">
                            <?php foreach ($slots as $slot): ?>
                                <div class="parking-slot <?php echo $slot['type']; ?> <?php echo $slot['display_status']; ?>">
                                    <div class="slot-number"><?php echo htmlspecialchars($slot['slot_number']); ?></div>
                                    <div class="slot-type"><?php echo ucfirst($slot['type']); ?></div>
                                    <div class="slot-status">
                                        <span class="badge bg-<?php 
                                            echo $slot['display_status'] === 'available' ? 'success' : 
                                                ($slot['display_status'] === 'occupied' ? 'danger' : 'warning'); 
                                        ?>">
                                            <?php echo ucfirst($slot['display_status']); ?>
                                        </span>
                                    </div>
                                    <?php if ($slot['display_status'] === 'available'): ?>
                                        <a href="book-slot.php?slot_id=<?php echo $slot['id']; ?>" class="btn btn-sm btn-primary mt-2">
                                            Book Now
                                        </a>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        
<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';

$auth = new Auth($db);

// Check if user is logged in
if (!$auth->isLoggedIn()) {
    header('Location: ../login.php');
    exit();
}

// Check maintenance mode
if ($auth->isMaintenanceMode() && !$auth->isAdmin()) {
    header('Location: ../maintenance.php');
    exit();
}

// Get user data
$stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Get user's vehicles
$stmt = $db->prepare("SELECT * FROM vehicles WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$vehicles = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get user's active bookings
$stmt = $db->prepare("
    SELECT b.*, ps.slot_number, ps.floor, ps.type, ps.status, ps.x_coordinate, ps.y_coordinate,
           CASE 
               WHEN b.end_time < NOW() THEN 'overdue'
               WHEN b.end_time < DATE_ADD(NOW(), INTERVAL 1 HOUR) THEN 'upcoming'
               ELSE 'active'
           END as reminder_status
    FROM bookings b
    JOIN parking_slots ps ON b.slot_id = ps.id
    WHERE b.user_id = ? AND b.status = 'active'
    ORDER BY b.start_time DESC
");
$stmt->execute([$_SESSION['user_id']]);
$active_bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get overdue bookings with penalties
$stmt = $db->prepare("
    SELECT b.*, ps.slot_number, ps.floor, ps.type,
           TIMESTAMPDIFF(HOUR, b.end_time, NOW()) as overdue_hours,
           (TIMESTAMPDIFF(HOUR, b.end_time, NOW()) * 100) as penalty_amount,
           v.vehicle_number, v.vehicle_type, v.vehicle_model
    FROM bookings b
    JOIN parking_slots ps ON b.slot_id = ps.id
    JOIN vehicles v ON b.vehicle_id = v.id
    WHERE b.user_id = ? 
    AND b.status = 'active' 
    AND b.end_time < NOW()
    ORDER BY b.end_time ASC
");
$stmt->execute([$_SESSION['user_id']]);
$overdue_bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get bookings ending within 1 hour
$stmt = $db->prepare("
    SELECT b.*, ps.slot_number, ps.floor, ps.type,
           TIMESTAMPDIFF(MINUTE, NOW(), b.end_time) as minutes_remaining,
           v.vehicle_number, v.vehicle_type, v.vehicle_model
    FROM bookings b
    JOIN parking_slots ps ON b.slot_id = ps.id
    JOIN vehicles v ON b.vehicle_id = v.id
    WHERE b.user_id = ? 
    AND b.status = 'active' 
    AND b.end_time > NOW()
    AND b.end_time <= DATE_ADD(NOW(), INTERVAL 1 HOUR)
    ORDER BY b.end_time ASC
");
$stmt->execute([$_SESSION['user_id']]);
$ending_soon_bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get all slots grouped by floor
$stmt = $db->query("
    SELECT ps.*, 
           b.id as booking_id,
           b.status as booking_status,
           CASE 
               WHEN b.status = 'active' THEN 'occupied'
               ELSE ps.status
           END as display_status
    FROM parking_slots ps
    LEFT JOIN bookings b ON ps.id = b.slot_id AND b.status = 'active'
    ORDER BY ps.floor, ps.x_coordinate, ps.y_coordinate
");
$slots = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Group slots by floor
$slots_by_floor = [];
foreach ($slots as $slot) {
    $slots_by_floor[$slot['floor']][] = $slot;
}

// Get user's announcements
$stmt = $db->prepare("
    SELECT a.*, 
           ar.read_at,
           CASE 
               WHEN a.expires_at IS NULL THEN 'Never'
               WHEN a.expires_at < NOW() THEN 'Expired'
               ELSE DATE_FORMAT(a.expires_at, '%M %d, %Y %H:%i')
           END as expiration_status
    FROM announcements a 
    LEFT JOIN announcement_reads ar ON a.id = ar.announcement_id AND ar.user_id = ?
    WHERE (a.recipient_type = 'all' 
    OR (a.recipient_type = 'specific' AND a.recipient_id = ?))
    AND (a.expires_at IS NULL OR a.expires_at > NOW())
    ORDER BY a.created_at DESC
    LIMIT 5
");
$stmt->execute([$_SESSION['user_id'], $_SESSION['user_id']]);
$announcements = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get count of unread announcements
$stmt = $db->prepare("
    SELECT COUNT(*) 
    FROM announcements a 
    LEFT JOIN announcement_reads ar ON a.id = ar.announcement_id AND ar.user_id = ?
    WHERE (a.recipient_type = 'all' 
    OR (a.recipient_type = 'specific' AND a.recipient_id = ?))
    AND (a.expires_at IS NULL OR a.expires_at > NOW())
    AND ar.id IS NULL
");
$stmt->execute([$_SESSION['user_id'], $_SESSION['user_id']]);
$unread_count = $stmt->fetchColumn();

// Get user's favorite slots
$stmt = $db->prepare("
    SELECT ps.*, uf.created_at as favorited_at
    FROM user_favorites uf
    JOIN parking_slots ps ON uf.slot_id = ps.id
    WHERE uf.user_id = ?
    ORDER BY uf.created_at DESC
    LIMIT 5
");
$stmt->execute([$_SESSION['user_id']]);
$favorite_slots = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get monthly statistics
$stmt = $db->prepare("
    SELECT 
        COUNT(*) as total_bookings,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_bookings,
        SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled_bookings,
        SUM(TIMESTAMPDIFF(HOUR, start_time, end_time)) as total_hours,
        AVG(TIMESTAMPDIFF(HOUR, start_time, end_time)) as avg_duration,
        (
            SELECT ps.slot_number 
            FROM bookings b2 
            JOIN parking_slots ps ON b2.slot_id = ps.id 
            WHERE b2.user_id = bookings.user_id 
            AND b2.start_time >= DATE_SUB(NOW(), INTERVAL 30 DAY)
            GROUP BY b2.slot_id 
            ORDER BY COUNT(*) DESC 
            LIMIT 1
        ) as most_used_slot
    FROM bookings
    WHERE user_id = ?
    AND start_time >= DATE_SUB(NOW(), INTERVAL 30 DAY)
");
$stmt->execute([$_SESSION['user_id']]);
$monthly_stats = $stmt->fetch(PDO::FETCH_ASSOC);

// Get parking history
$stmt = $db->prepare("
    SELECT b.*, ps.slot_number, ps.floor, ps.type
    FROM bookings b
    JOIN parking_slots ps ON b.slot_id = ps.id
    WHERE b.user_id = ?
    ORDER BY b.start_time DESC
    LIMIT 10
");
$stmt->execute([$_SESSION['user_id']]);
$parking_history = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get parking availability heatmap data
$stmt = $db->query("
    SELECT 
        ps.*,
        COUNT(b.id) as current_bookings,
        CASE 
            WHEN ps.status = 'maintenance' THEN 'maintenance'
            WHEN COUNT(b.id) > 0 THEN 'occupied'
            ELSE 'available'
        END as availability_status
    FROM parking_slots ps
    LEFT JOIN bookings b ON ps.id = b.slot_id 
        AND b.status = 'active'
        AND b.end_time > NOW()
    GROUP BY ps.id
");
$heatmap_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .dashboard-container {
            display: grid;
            grid-template-columns: repeat(12, 1fr);
            gap: 20px;
            padding: 20px;
        }
        
        .dashboard-header {
            grid-column: span 12;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        
        .welcome-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .user-stats {
            display: flex;
            gap: 20px;
        }
        
        .stat-card {
            background: rgba(255, 255, 255, 0.1);
            padding: 15px;
            border-radius: 8px;
            text-align: center;
            min-width: 150px;
        }
        
        .main-content {
            grid-column: span 8;
        }
        
        .sidebar {
            grid-column: span 4;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .quick-action-btn {
            background: white;
            border: none;
            border-radius: 8px;
            padding: 15px;
            text-align: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            cursor: pointer;
        }
        
        .quick-action-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }
        
        .quick-action-btn i {
            font-size: 24px;
            margin-bottom: 10px;
            color: #1e3c72;
        }
        
        .upcoming-bookings {
            margin-bottom: 20px;
        }
        
        .booking-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            border-bottom: 1px solid #eee;
        }
        
        .booking-item:last-child {
            border-bottom: none;
        }
        
        .booking-info {
            flex: 1;
        }
        
        .booking-actions {
            display: flex;
            gap: 10px;
        }
        
        .announcements-list {
            max-height: 300px;
            overflow-y: auto;
        }
        
        .announcement-item {
            padding: 10px;
            border-bottom: 1px solid #eee;
        }
        
        .announcement-item:last-child {
            border-bottom: none;
        }
        
        .announcement-date {
            font-size: 0.8em;
            color: #666;
        }
        
        .parking-layout {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-top: 20px;
        }
        
        .floor-navigation {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }
        
        .floor-btn {
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            background: #f8f9fa;
            cursor: pointer;
        }
        
        .floor-btn.active {
            background: #1e3c72;
            color: white;
        }
        
        .parking-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 10px;
            margin-bottom: 20px;
        }
        
        .parking-slot {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
            border-radius: 5px;
            position: relative;
            min-height: 80px;
        }
        
        .parking-slot.handicap {
            background-color: #ffd700;
        }
        
        .parking-slot.electric {
            background-color: #90ee90;
        }
        
        .parking-slot.regular {
            background-color: #f0f0f0;
        }
        
        .parking-slot.occupied {
            background-color: #ff6b6b;
        }
        
        .parking-slot.maintenance {
            background-color: #a9a9a9;
        }
        
        .slot-number {
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .slot-type {
            font-size: 0.8em;
            color: #666;
        }
        
        .building {
            background-color: #333;
            color: white;
            padding: 10px;
            text-align: center;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        
        .floor-label {
            background-color: #007bff;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
            margin-bottom: 10px;
            display: inline-block;
        }
        
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .quick-action-card {
            background: white;
            border-radius: 10px;
            padding: 15px;
            text-align: center;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            transition: transform 0.2s;
            cursor: pointer;
        }
        
        .quick-action-card:hover {
            transform: translateY(-5px);
        }
        
        .quick-action-icon {
            font-size: 24px;
            margin-bottom: 10px;
            color: #007bff;
        }
        
        .heatmap-container {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .timeline {
            position: relative;
            padding: 20px 0;
        }
        
        .timeline-item {
            padding: 10px 20px;
            border-left: 3px solid #007bff;
            margin-bottom: 15px;
            background: white;
            border-radius: 0 10px 10px 0;
        }
        
        .stats-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .favorite-slot {
            background: white;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .building-entrance {
            background: #FF5722;
            color: white;
            padding: 12px 20px;
            border-radius: 8px;
            margin: 15px 0;
            display: inline-flex;
            align-items: center;
            gap: 12px;
            font-weight: bold;
            font-size: 1.2em;
            text-transform: uppercase;
            letter-spacing: 1px;
            border: 2px solid #E64A19;
        }
        
        .building-entrance i {
            font-size: 1.5em;
        }
        
        .current-time {
            color: rgba(255, 255, 255, 0.9);
            font-size: 1.1em;
            margin-top: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .current-time i {
            color: #ffd700;
        }
        
        /* Responsive Design */
        @media (max-width: 768px) {
            .dashboard-container {
                grid-template-columns: 1fr;
                padding: 10px;
                gap: 15px;
            }
            
            .dashboard-header {
                padding: 15px;
            }
            
            .welcome-section {
                flex-direction: column;
                text-align: center;
            }
            
            .user-stats {
                flex-direction: column;
                gap: 10px;
                margin-top: 15px;
            }
            
            .stat-card {
                width: 100%;
                min-width: auto;
            }
            
            .quick-actions {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .quick-action-btn {
                padding: 10px;
            }
            
            .quick-action-btn i {
                font-size: 20px;
            }
            
            .parking-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 8px;
            }
            
            .parking-slot {
                min-height: 60px;
                padding: 8px;
            }
            
            .floor-navigation {
                flex-wrap: wrap;
                gap: 5px;
            }
            
            .floor-btn {
                padding: 5px 10px;
                font-size: 0.9em;
            }
            
            .building-entrance {
                font-size: 1em;
                padding: 8px 15px;
            }
            
            .announcements-list {
                max-height: 200px;
            }
            
            .booking-item {
                flex-direction: column;
                gap: 10px;
            }
            
            .booking-actions {
                width: 100%;
                justify-content: center;
            }
            
            .current-time {
                font-size: 1em;
                justify-content: center;
            }
            
            .card-header {
                flex-direction: column;
                gap: 10px;
            }
            
            .card-header h3 {
                font-size: 1.2em;
            }
            
            .btn-sm {
                padding: 0.25rem 0.5rem;
                font-size: 0.875rem;
            }
        }
        
        @media (max-width: 480px) {
            .quick-actions {
                grid-template-columns: 1fr;
            }
            
            .parking-grid {
                grid-template-columns: 1fr;
            }
            
            .dashboard-header h2 {
                font-size: 1.5em;
            }
            
            .stat-card h3 {
                font-size: 1.2em;
            }
        }
        
        /* Ensure text remains readable on small screens */
        .parking-slot {
            font-size: clamp(0.8rem, 2vw, 1rem);
        }
        
        /* Prevent horizontal scrolling */
        body {
            overflow-x: hidden;
        }
        
        .overdue-bookings {
            margin-bottom: 20px;
        }
        
        .overdue-bookings .booking-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 8px;
            background-color: #fff3f3;
            border: 1px solid #ffcdd2;
        }
        
        .overdue-bookings .booking-info {
            flex: 1;
        }
        
        .overdue-bookings .booking-info h5 {
            color: #d32f2f;
            margin-bottom: 10px;
        }
        
        .overdue-bookings .booking-info p {
            margin-bottom: 5px;
            color: #333;
        }
        
        .overdue-bookings .booking-info .text-danger {
            font-size: 1.1em;
            margin-top: 10px;
        }
        
        .overdue-bookings .booking-actions {
            margin-left: 20px;
        }
        
        .overdue-bookings .btn-danger {
            background: #d32f2f;
            border: none;
            padding: 8px 20px;
            transition: all 0.3s ease;
        }
        
        .overdue-bookings .btn-danger:hover {
            background: #b71c1c;
            transform: translateY(-2px);
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }
        
        .ending-soon-bookings {
            margin-bottom: 20px;
        }
        
        .ending-soon-bookings .booking-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 8px;
            background-color: #fff8e1;
            border: 1px solid #ffe0b2;
        }
        
        .ending-soon-bookings .booking-info {
            flex: 1;
        }
        
        .ending-soon-bookings .booking-info h5 {
            color: #f57c00;
            margin-bottom: 10px;
        }
        
        .ending-soon-bookings .booking-info p {
            margin-bottom: 5px;
            color: #333;
        }
        
        .ending-soon-bookings .booking-info .text-warning {
            font-size: 1.1em;
            margin-top: 10px;
        }
        
        .ending-soon-bookings .booking-actions {
            margin-left: 20px;
        }
        
        .ending-soon-bookings .btn-warning {
            background: #ff9800;
            border: none;
            padding: 8px 20px;
            transition: all 0.3s ease;
        }
        
        .ending-soon-bookings .btn-warning:hover {
            background: #f57c00;
            transform: translateY(-2px);
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }
        
        .profile-picture-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 10px;
            border: 2px solid #1e3c72;
        }
    </style>
</head>
<body>
    <?php include '../includes/user-nav.php'; ?>
    
    <div class="dashboard-container">
        <div class="dashboard-header">
            <div class="welcome-section">
                <div>
                    <h2>Welcome, <?php echo htmlspecialchars($user['name']); ?>!</h2>
                    <p>Here's what's happening today</p>
                    <div class="current-time">
                        <i class="fas fa-clock"></i>
                        <span id="currentDateTime"></span>
                    </div>
            </div>
                <div class="user-stats">
                    <div class="stat-card">
                        <i class="fas fa-car"></i>
                        <h3><?php echo count($vehicles); ?></h3>
                        <p>Vehicles</p>
        </div>
                    <div class="stat-card">
                        <i class="fas fa-calendar-check"></i>
                        <h3><?php echo count($active_bookings); ?></h3>
                        <p>Active Bookings</p>
                    </div>
                    <div class="stat-card">
                        <i class="fas fa-bell"></i>
                        <h3><?php echo $unread_count; ?></h3>
                        <p>Unread Notifications</p>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="main-content">
            <div class="quick-actions">
                <div class="quick-action-btn" onclick="window.location.href='profile.php'">
                    <?php if (!empty($user['profile_picture'])): ?>
                        <img src="../<?php echo htmlspecialchars($user['profile_picture']); ?>" 
                             alt="Profile Picture" 
                             class="profile-picture-icon">
                    <?php else: ?>
                        <i class="fas fa-user-circle"></i>
                    <?php endif; ?>
                    <p>Profile</p>
                </div>
                <div class="quick-action-btn" onclick="window.location.href='book-slot.php'">
                    <i class="fas fa-plus-circle"></i>
                    <p>Book Slot</p>
                </div>
                <div class="quick-action-btn" onclick="window.location.href='my-vehicles.php'">
                    <i class="fas fa-car"></i>
                    <p>My Vehicles</p>
                </div>
                <div class="quick-action-btn" onclick="window.location.href='my-bookings.php'">
                    <i class="fas fa-list"></i>
                    <p>My Bookings</p>
                </div>
            </div>
            
            <?php if (!empty($ending_soon_bookings)): ?>
            <div class="dashboard-card">
                <div class="card-header">
                    <h3><i class="fas fa-clock text-warning me-2"></i>Bookings Ending Soon</h3>
                </div>
                <div class="ending-soon-bookings">
                    <?php foreach ($ending_soon_bookings as $booking): ?>
                    <div class="booking-item alert alert-warning">
                        <div class="booking-info">
                            <h5>Slot <?php echo htmlspecialchars($booking['slot_number']); ?></h5>
                            <p>Floor <?php echo htmlspecialchars($booking['floor']); ?> - <?php echo ucfirst($booking['type']); ?></p>
                            <p>Vehicle: <?php echo htmlspecialchars($booking['vehicle_number']); ?> 
                               (<?php echo htmlspecialchars($booking['vehicle_type']); ?> 
                                <?php echo htmlspecialchars($booking['vehicle_model']); ?>)</p>
                            <p class="text-warning"><strong>Time Remaining: <?php echo $booking['minutes_remaining']; ?> minutes</strong></p>
                            <p class="text-warning"><strong>Ends at: <?php echo date('H:i', strtotime($booking['end_time'])); ?></strong></p>
                        </div>
                        <div class="booking-actions">
                            <a href="check-out.php?id=<?php echo $booking['id']; ?>" class="btn btn-warning">
                                <i class="fas fa-sign-out-alt me-2"></i>Check Out Now
                            </a>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

            <?php if (!empty($overdue_bookings)): ?>
            <div class="dashboard-card">
                <div class="card-header">
                    <h3><i class="fas fa-exclamation-triangle text-danger me-2"></i>Overdue Bookings</h3>
                </div>
                <div class="overdue-bookings">
                    <?php foreach ($overdue_bookings as $booking): ?>
                    <div class="booking-item alert alert-danger">
                        <div class="booking-info">
                            <h5>Slot <?php echo htmlspecialchars($booking['slot_number']); ?></h5>
                            <p>Floor <?php echo htmlspecialchars($booking['floor']); ?> - <?php echo ucfirst($booking['type']); ?></p>
                            <p>Vehicle: <?php echo htmlspecialchars($booking['vehicle_number']); ?> 
                               (<?php echo htmlspecialchars($booking['vehicle_type']); ?> 
                                <?php echo htmlspecialchars($booking['vehicle_model']); ?>)</p>
                            <p class="text-danger"><strong>Overdue: <?php echo $booking['overdue_hours']; ?> hours</strong></p>
                            <p class="text-danger"><strong>Penalty: K<?php echo number_format($booking['penalty_amount'], 2); ?></strong></p>
                        </div>
                        <div class="booking-actions">
                            <a href="check-out.php?id=<?php echo $booking['id']; ?>" class="btn btn-danger">
                                <i class="fas fa-sign-out-alt me-2"></i>Check Out Now
                            </a>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

            <div class="dashboard-card">
                <div class="card-header">
                    <h3>Upcoming Bookings</h3>
                    <a href="my-bookings.php" class="btn btn-sm btn-primary">View All</a>
                </div>
                <div class="upcoming-bookings">
                        <?php if (empty($active_bookings)): ?>
                        <p class="text-muted">No upcoming bookings</p>
                        <?php else: ?>
                                        <?php foreach ($active_bookings as $booking): ?>
                            <div class="booking-item">
                                <div class="booking-info">
                                    <h5>Slot <?php echo htmlspecialchars($booking['slot_number']); ?></h5>
                                    <p>Floor <?php echo htmlspecialchars($booking['floor']); ?> - <?php echo ucfirst($booking['type']); ?></p>
                                    <small>Ends: <?php echo date('M d, Y H:i', strtotime($booking['end_time'])); ?></small>
                                </div>
                                <div class="booking-actions">
                                    <a href="view-receipt.php?id=<?php echo $booking['id']; ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-receipt"></i>
                                    </a>
                                    <a href="check-out.php?id=<?php echo $booking['id']; ?>" class="btn btn-sm btn-outline-danger">
                                        <i class="fas fa-sign-out-alt"></i>
                                                </a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                        <?php endif; ?>
            </div>
        </div>

            <div class="parking-layout">
            <div class="card-header">
                    <h3>Parking Layout</h3>
                    <div class="building-entrance">
                        <i class="fas fa-door-open"></i>
                        <span>MAIN ENTRANCE</span>
                    </div>
                    <div class="floor-navigation">
                        <?php foreach ($slots_by_floor as $floor => $slots): ?>
                            <button class="floor-btn <?php echo $floor === 1 ? 'active' : ''; ?>" 
                                    onclick="showFloor(<?php echo $floor; ?>)">
                                Floor <?php echo $floor; ?>
                            </button>
                        <?php endforeach; ?>
            </div>
        </div>

                <?php foreach ($slots_by_floor as $floor => $slots): ?>
                    <div class="floor-section" id="floor-<?php echo $floor; ?>" 
                         style="display: <?php echo $floor === 1 ? 'block' : 'none'; ?>;">
                        <div class="parking-grid">
                            <?php foreach ($slots as $slot): ?>
                                <div class="parking-slot <?php echo $slot['type']; ?> <?php echo $slot['display_status']; ?>">
                                    <div class="slot-number"><?php echo htmlspecialchars($slot['slot_number']); ?></div>
                                    <div class="slot-type"><?php echo ucfirst($slot['type']); ?></div>
                                    <div class="slot-status">
                                        <span class="badge bg-<?php 
                                            echo $slot['display_status'] === 'available' ? 'success' : 
                                                ($slot['display_status'] === 'occupied' ? 'danger' : 'warning'); 
                                        ?>">
                                            <?php echo ucfirst($slot['display_status']); ?>
                                        </span>
                                    </div>
                                    <?php if ($slot['display_status'] === 'available'): ?>
                                        <a href="book-slot.php?slot_id=<?php echo $slot['id']; ?>" class="btn btn-sm btn-primary mt-2">
                                            Book Now
                                        </a>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        
        <div class="sidebar">
            <div class="dashboard-card">
                <div class="card-header">
                    <h3>Recent Announcements</h3>
                    <a href="announcements.php" class="btn btn-sm btn-primary">View All</a>
                </div>
                <div class="announcements-list">
                    <?php if (empty($announcements)): ?>
                        <p class="text-muted">No recent announcements</p>
                    <?php else: ?>
                        <?php foreach ($announcements as $announcement): ?>
                            <div class="announcement-item">
                                <h5><?php echo htmlspecialchars($announcement['title']); ?></h5>
                                <p><?php echo htmlspecialchars($announcement['message'] ?? 'No message available'); ?></p>
                                <div class="announcement-date">
                                    <?php echo date('M d, Y', strtotime($announcement['created_at'])); ?>
                                    <?php if (!$announcement['read_at']): ?>
                                        <span class="badge bg-danger">New</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="dashboard-card">
                <div class="card-header">
                    <h3>Favorite Slots</h3>
                </div>
                <?php if (empty($favorite_slots)): ?>
                    <p class="text-muted">No favorite slots yet</p>
                <?php else: ?>
                    <?php foreach ($favorite_slots as $slot): ?>
                        <div class="booking-item">
                            <div class="booking-info">
                                <h5>Slot <?php echo htmlspecialchars($slot['slot_number']); ?></h5>
                                <p>Floor <?php echo htmlspecialchars($slot['floor']); ?></p>
                            </div>
                            <div class="booking-actions">
                                <a href="book-slot.php?slot_id=<?php echo $slot['id']; ?>" class="btn btn-sm btn-primary">
                                    <i class="fas fa-bookmark"></i>
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
    <script>
    function showFloor(floorNumber) {
        // Hide all floor sections
        document.querySelectorAll('.floor-section').forEach(section => {
            section.style.display = 'none';
        });
        
        // Show selected floor
        document.getElementById(`floor-${floorNumber}`).style.display = 'block';
        
        // Update active button
        document.querySelectorAll('.floor-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        document.querySelector(`.floor-btn:nth-child(${floorNumber})`).classList.add('active');
    }

    // Update current date and time
    function updateDateTime() {
        const now = new Date();
        const options = { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        };
        document.getElementById('currentDateTime').textContent = now.toLocaleDateString('en-US', options);
    }

    // Update time immediately and then every second
    updateDateTime();
    setInterval(updateDateTime, 1000);
    </script>
</body>
</html> 