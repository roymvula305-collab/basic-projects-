<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/db.php';

// Check if user is logged in
if (!$auth->isLoggedIn() || $auth->isAdmin()) {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$vehicle_id = $_GET['vehicle_id'] ?? 0;

$db = new Database();
$conn = $db->getConnection();

// Get vehicle details
$stmt = $conn->prepare("
    SELECT * FROM vehicles 
    WHERE id = ? AND user_id = ?
");
$stmt->execute([$vehicle_id, $user_id]);
$vehicle = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$vehicle) {
    header('Location: my-vehicles.php');
    exit();
}

// Get all service history for the vehicle
$stmt = $conn->prepare("
    SELECT sa.*, 
           s.name as service_name, s.description as service_description,
           m.name as mechanic_name,
           GROUP_CONCAT(
               CONCAT(sp.quantity_used, 'x ', p.name, ' ($', sp.unit_price, ')')
               SEPARATOR '\n'
           ) as parts_used
    FROM service_appointments sa
    JOIN services s ON sa.service_id = s.id
    LEFT JOIN mechanics m ON sa.mechanic_id = m.user_id
    LEFT JOIN service_parts sp ON sa.id = sp.appointment_id
    LEFT JOIN parts_inventory p ON sp.part_id = p.id
    WHERE sa.vehicle_id = ? AND sa.status = 'completed'
    GROUP BY sa.id
    ORDER BY sa.appointment_date DESC
");
$stmt->execute([$vehicle_id]);
$service_history = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate total service costs
$total_service_cost = 0;
foreach ($service_history as $service) {
    $total_service_cost += $service['final_cost'];
}

// Get service statistics
$stmt = $conn->prepare("
    SELECT 
        COUNT(*) as total_services,
        MIN(appointment_date) as first_service,
        MAX(appointment_date) as last_service,
        AVG(final_cost) as avg_cost
    FROM service_appointments
    WHERE vehicle_id = ? AND status = 'completed'
");
$stmt->execute([$vehicle_id]);
$stats = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Service History - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
    <style>
        .service-card {
            margin-bottom: 1.5rem;
            border: none;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .service-header {
            background: #f8f9fa;
            padding: 1rem;
            border-bottom: 1px solid #dee2e6;
        }
        .stats-box {
            text-align: center;
            padding: 1.5rem;
            background: #f8f9fa;
            border-radius: 0.5rem;
            margin-bottom: 1rem;
        }
        .stats-box h3 {
            margin: 0;
            color: #1e3c72;
        }
        .stats-box p {
            margin: 0;
            color: #6c757d;
        }
        .parts-list {
            list-style: none;
            padding-left: 0;
        }
        .parts-list li {
            padding: 0.5rem 0;
            border-bottom: 1px solid #dee2e6;
        }
        .parts-list li:last-child {
            border-bottom: none;
        }
    </style>
</head>
<body>
    <div class="container py-4">
        <div class="row mb-4">
            <div class="col-md-6">
                <h1>Service History</h1>
                <h4 class="text-muted">
                    <?php echo htmlspecialchars($vehicle['make'] . ' ' . $vehicle['model'] . ' (' . $vehicle['year'] . ')'); ?>
                </h4>
                <p class="mb-0">
                    Vehicle Number: <?php echo htmlspecialchars($vehicle['vehicle_number']); ?>
                </p>
            </div>
            <div class="col-md-6 text-end">
                <a href="my-vehicles.php" class="btn btn-outline-primary me-2">
                    <i class="fas fa-arrow-left"></i> Back to Vehicles
                </a>
                <a href="schedule-service.php?vehicle_id=<?php echo $vehicle_id; ?>" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Schedule Service
                </a>
            </div>
        </div>

        <!-- Service Statistics -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="stats-box">
                    <h3><?php echo $stats['total_services']; ?></h3>
                    <p>Total Services</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-box">
                    <h3>$<?php echo number_format($total_service_cost, 2); ?></h3>
                    <p>Total Cost</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-box">
                    <h3>$<?php echo number_format($stats['avg_cost'], 2); ?></h3>
                    <p>Average Cost</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-box">
                    <h3><?php echo $vehicle['mileage']; ?></h3>
                    <p>Current Mileage</p>
                </div>
            </div>
        </div>

        <!-- Service History -->
        <?php if (empty($service_history)): ?>
            <div class="alert alert-info">
                <p class="mb-0">No service history available for this vehicle.</p>
            </div>
        <?php else: ?>
            <?php foreach ($service_history as $service): ?>
                <div class="card service-card">
                    <div class="service-header">
                        <div class="row align-items-center">
                            <div class="col-md-8">
                                <h5 class="mb-0"><?php echo htmlspecialchars($service['service_name']); ?></h5>
                                <p class="text-muted mb-0">
                                    <?php echo date('F j, Y', strtotime($service['appointment_date'])); ?>
                                    <span class="mx-2">•</span>
                                    Mechanic: <?php echo htmlspecialchars($service['mechanic_name']); ?>
                                </p>
                            </div>
                            <div class="col-md-4 text-end">
                                <h5 class="mb-0">$<?php echo number_format($service['final_cost'], 2); ?></h5>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php if ($service['service_description']): ?>
                            <p class="mb-3"><?php echo nl2br(htmlspecialchars($service['service_description'])); ?></p>
                        <?php endif; ?>

                        <?php if ($service['parts_used']): ?>
                            <h6>Parts Used:</h6>
                            <ul class="parts-list">
                                <?php foreach (explode("\n", $service['parts_used']) as $part): ?>
                                    <li><?php echo htmlspecialchars($part); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>

                        <?php if ($service['notes']): ?>
                            <h6>Service Notes:</h6>
                            <p class="mb-0"><?php echo nl2br(htmlspecialchars($service['notes'])); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="card-footer bg-white">
                        <div class="row align-items-center">
                            <div class="col">
                                <small class="text-muted">
                                    Service ID: #<?php echo $service['id']; ?>
                                </small>
                            </div>
                            <div class="col text-end">
                                <a href="view-service-details.php?id=<?php echo $service['id']; ?>" class="btn btn-outline-primary btn-sm">
                                    View Full Details
                                </a>
                                <a href="#" class="btn btn-outline-secondary btn-sm" onclick="window.print()">
                                    <i class="fas fa-print"></i> Print
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 