<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/db.php';

// Check if user is logged in
if (!$auth->isLoggedIn() || $auth->isAdmin()) {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$appointment_id = $_GET['id'] ?? 0;

$db = new Database();
$conn = $db->getConnection();

// Get appointment details
$stmt = $conn->prepare("
    SELECT sa.*, s.name as service_name, s.description as service_description,
           v.make, v.model, v.vehicle_number,
           sb.bay_number, m.name as mechanic_name
    FROM service_appointments sa
    JOIN services s ON sa.service_id = s.id
    JOIN vehicles v ON sa.vehicle_id = v.id
    JOIN service_bays sb ON sa.bay_id = sb.id
    LEFT JOIN mechanics m ON sa.mechanic_id = m.user_id
    WHERE sa.id = ? AND sa.user_id = ?
");
$stmt->execute([$appointment_id, $user_id]);
$appointment = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$appointment) {
    header('Location: dashboard.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment Confirmation - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
    <style>
        .confirmation-card {
            max-width: 800px;
            margin: 0 auto;
        }
        .detail-row {
            padding: 15px 0;
            border-bottom: 1px solid #dee2e6;
        }
        .detail-row:last-child {
            border-bottom: none;
        }
        .success-icon {
            font-size: 4rem;
            color: #198754;
            margin-bottom: 1rem;
        }
    </style>
</head>
<body>
    <div class="container py-5">
        <div class="confirmation-card">
            <div class="text-center mb-4">
                <i class="fas fa-check-circle success-icon"></i>
                <h1 class="mb-4">Appointment Confirmed!</h1>
                <p class="lead">Your service appointment has been successfully scheduled.</p>
            </div>

            <div class="card">
                <div class="card-body">
                    <h4 class="card-title mb-4">Appointment Details</h4>

                    <div class="detail-row">
                        <div class="row">
                            <div class="col-md-4">
                                <strong>Service</strong>
                            </div>
                            <div class="col-md-8">
                                <?php echo htmlspecialchars($appointment['service_name']); ?>
                            </div>
                        </div>
                    </div>

                    <div class="detail-row">
                        <div class="row">
                            <div class="col-md-4">
                                <strong>Vehicle</strong>
                            </div>
                            <div class="col-md-8">
                                <?php echo htmlspecialchars($appointment['make'] . ' ' . $appointment['model']); ?>
                                (<?php echo htmlspecialchars($appointment['vehicle_number']); ?>)
                            </div>
                        </div>
                    </div>

                    <div class="detail-row">
                        <div class="row">
                            <div class="col-md-4">
                                <strong>Date & Time</strong>
                            </div>
                            <div class="col-md-8">
                                <?php 
                                echo date('l, F j, Y', strtotime($appointment['appointment_date'])) . ' at ' . 
                                     date('h:i A', strtotime($appointment['start_time']));
                                ?>
                            </div>
                        </div>
                    </div>

                    <div class="detail-row">
                        <div class="row">
                            <div class="col-md-4">
                                <strong>Service Bay</strong>
                            </div>
                            <div class="col-md-8">
                                Bay #<?php echo htmlspecialchars($appointment['bay_number']); ?>
                            </div>
                        </div>
                    </div>

                    <div class="detail-row">
                        <div class="row">
                            <div class="col-md-4">
                                <strong>Estimated Cost</strong>
                            </div>
                            <div class="col-md-8">
                                $<?php echo number_format($appointment['estimated_cost'], 2); ?>
                            </div>
                        </div>
                    </div>

                    <?php if (!empty($appointment['notes'])): ?>
                    <div class="detail-row">
                        <div class="row">
                            <div class="col-md-4">
                                <strong>Notes</strong>
                            </div>
                            <div class="col-md-8">
                                <?php echo nl2br(htmlspecialchars($appointment['notes'])); ?>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card mt-4">
                <div class="card-body">
                    <h5 class="card-title">Important Information</h5>
                    <ul class="mb-0">
                        <li>Please arrive 10 minutes before your scheduled appointment time.</li>
                        <li>Bring your vehicle registration and insurance documents.</li>
                        <li>If you need to reschedule or cancel, please do so at least 24 hours in advance.</li>
                        <li>The estimated cost may vary based on additional parts or services required.</li>
                    </ul>
                </div>
            </div>

            <div class="text-center mt-4">
                <a href="dashboard.php" class="btn btn-primary me-2">Return to Dashboard</a>
                <a href="#" class="btn btn-outline-primary" onclick="window.print()">
                    <i class="fas fa-print me-2"></i>Print Details
                </a>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 