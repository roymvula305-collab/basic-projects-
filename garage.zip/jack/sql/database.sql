-- Create database
CREATE DATABASE IF NOT EXISTS garage_management;
USE garage_management;

-- Create users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    nrc_passport VARCHAR(50) UNIQUE,
    phone VARCHAR(20) UNIQUE,
    city VARCHAR(100),
    country VARCHAR(100),
    password VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    profile_picture VARCHAR(255) DEFAULT NULL,
    role ENUM('user', 'admin', 'mechanic') DEFAULT 'user',
    reset_token VARCHAR(64) DEFAULT NULL,
    reset_token_expires DATETIME DEFAULT NULL,
    last_login DATETIME DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Create mechanics table
CREATE TABLE IF NOT EXISTS mechanics (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    specialization VARCHAR(100),
    experience_years INT,
    certification TEXT,
    status ENUM('available', 'busy', 'off_duty') DEFAULT 'available',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Create vehicles table
CREATE TABLE IF NOT EXISTS vehicles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    vehicle_number VARCHAR(20) NOT NULL,
    vehicle_type ENUM('car', 'motorcycle', 'truck', 'van', 'bus') NOT NULL,
    make VARCHAR(50) NOT NULL,
    model VARCHAR(100) NOT NULL,
    year INT NOT NULL,
    vin_number VARCHAR(17),
    mileage INT,
    vehicle_color VARCHAR(50) NOT NULL,
    last_service_date DATE,
    next_service_date DATE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Create service_bays table (replaces parking_slots)
CREATE TABLE IF NOT EXISTS service_bays (
    id INT AUTO_INCREMENT PRIMARY KEY,
    bay_number VARCHAR(10) NOT NULL,
    bay_type ENUM('general', 'diagnostic', 'alignment', 'tire', 'paint') NOT NULL DEFAULT 'general',
    status ENUM('available', 'occupied', 'maintenance') NOT NULL DEFAULT 'available',
    equipment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_bay (bay_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create services table
CREATE TABLE IF NOT EXISTS services (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    estimated_duration INT, -- in minutes
    base_price DECIMAL(10,2) NOT NULL,
    category ENUM('maintenance', 'repair', 'diagnostic', 'cosmetic') NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Create parts_inventory table
CREATE TABLE IF NOT EXISTS parts_inventory (
    id INT AUTO_INCREMENT PRIMARY KEY,
    part_number VARCHAR(50) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    category VARCHAR(50) NOT NULL,
    quantity INT NOT NULL DEFAULT 0,
    unit_price DECIMAL(10,2) NOT NULL,
    reorder_level INT NOT NULL,
    supplier VARCHAR(100),
    location VARCHAR(50),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_updated DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create service_appointments table (replaces bookings)
CREATE TABLE IF NOT EXISTS service_appointments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    vehicle_id INT NOT NULL,
    bay_id INT NOT NULL,
    mechanic_id INT,
    service_id INT NOT NULL,
    appointment_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME,
    status ENUM('scheduled', 'in_progress', 'completed', 'cancelled') DEFAULT 'scheduled',
    notes TEXT,
    estimated_cost DECIMAL(10,2) DEFAULT 0.00,
    final_cost DECIMAL(10,2) DEFAULT 0.00,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (vehicle_id) REFERENCES vehicles(id),
    FOREIGN KEY (bay_id) REFERENCES service_bays(id),
    FOREIGN KEY (mechanic_id) REFERENCES mechanics(id),
    FOREIGN KEY (service_id) REFERENCES services(id)
);

-- Create service_parts table
CREATE TABLE IF NOT EXISTS service_parts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    appointment_id INT NOT NULL,
    part_id INT NOT NULL,
    quantity_used INT NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    total_price DECIMAL(10,2) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (appointment_id) REFERENCES service_appointments(id),
    FOREIGN KEY (part_id) REFERENCES parts_inventory(id)
);

-- Create payments table
CREATE TABLE IF NOT EXISTS payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    appointment_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_method ENUM('cash', 'credit_card', 'debit_card', 'mobile_money', 'bank_transfer') NOT NULL,
    payment_status ENUM('pending', 'completed', 'failed', 'refunded') DEFAULT 'pending',
    transaction_reference VARCHAR(100),
    payment_date DATETIME NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (appointment_id) REFERENCES service_appointments(id)
);

-- Create settings table
CREATE TABLE IF NOT EXISTS settings (
    setting_key VARCHAR(50) PRIMARY KEY,
    setting_value TEXT NOT NULL
);

-- Create announcements table
CREATE TABLE IF NOT EXISTS announcements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    recipient_type ENUM('all', 'specific') NOT NULL DEFAULT 'all',
    recipient_id INT,
    created_at DATETIME NOT NULL,
    expires_at DATETIME,
    FOREIGN KEY (recipient_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Insert default admin user
INSERT INTO users (email, password, name, role) VALUES 
('admin@garage.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Admin User', 'admin');

-- Insert default service bays
INSERT INTO service_bays (bay_number, bay_type) VALUES
('B1', 'general'),
('B2', 'general'),
('B3', 'diagnostic'),
('B4', 'alignment'),
('B5', 'tire'),
('B6', 'paint');

-- Insert common services
INSERT INTO services (name, description, estimated_duration, base_price, category) VALUES
('Oil Change', 'Standard oil change service with filter replacement', 60, 45.00, 'maintenance'),
('Tire Rotation', 'Rotate and balance all tires', 45, 35.00, 'maintenance'),
('Brake Inspection', 'Complete brake system inspection', 30, 25.00, 'diagnostic'),
('Engine Diagnostic', 'Computer diagnostic of engine systems', 60, 75.00, 'diagnostic'),
('Wheel Alignment', 'Four-wheel alignment service', 90, 89.00, 'maintenance'),
('Battery Service', 'Battery test and terminal cleaning', 30, 25.00, 'maintenance');

-- Insert default settings
INSERT INTO settings (setting_key, setting_value) VALUES
('labor_rate', '85.00'),
('business_hours', '{"monday":"8:00-17:00","tuesday":"8:00-17:00","wednesday":"8:00-17:00","thursday":"8:00-17:00","friday":"8:00-17:00","saturday":"9:00-14:00","sunday":"closed"}'),
('notification_email', 'notifications@garage.com'),
('site_name', 'Auto Garage Management System'),
('site_description', 'Professional automotive repair and maintenance services'),
('maintenance_mode', '0'); 