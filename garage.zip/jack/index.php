<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';

// Check if user is already logged in
if ($auth->isLoggedIn()) {
    if ($auth->isAdmin()) {
        header('Location: admin/dashboard.php');
    } else {
        header('Location: user/dashboard.php');
    }
    exit();
}

// Get garage statistics
$db = new Database();
$conn = $db->getConnection();

// Get service bay statistics
$stmt = $conn->query("SELECT COUNT(*) as total FROM service_bays");
$total_bays = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

$stmt = $conn->query("SELECT COUNT(*) as available FROM service_bays WHERE status = 'available'");
$available_bays = $stmt->fetch(PDO::FETCH_ASSOC)['available'];
$occupied_bays = $total_bays - $available_bays;

// Get today's appointments
$stmt = $conn->query("SELECT COUNT(*) as total FROM service_appointments WHERE DATE(appointment_date) = CURDATE()");
$today_appointments = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

// Get active services
$stmt = $conn->query("SELECT COUNT(*) as total FROM service_appointments WHERE status = 'in_progress'");
$active_services = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

// Get mechanics availability
$stmt = $conn->query("SELECT 
    COUNT(CASE WHEN status = 'available' THEN 1 END) as available,
    COUNT(CASE WHEN status = 'busy' THEN 1 END) as busy,
    COUNT(*) as total
    FROM mechanics");
$mechanics_stats = $stmt->fetch(PDO::FETCH_ASSOC);

// Get low stock parts
$stmt = $conn->query("
    SELECT COUNT(*) as count 
    FROM parts_inventory 
    WHERE quantity <= reorder_level
");
$low_stock_parts = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

// Get popular services
$stmt = $conn->query("
    SELECT s.name, COUNT(*) as count 
    FROM service_appointments sa 
    JOIN services s ON sa.service_id = s.id 
    WHERE sa.status = 'completed' 
    GROUP BY s.id 
    ORDER BY count DESC 
    LIMIT 5
");
$popular_services = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get recent announcements
$stmt = $conn->query("
    SELECT * FROM announcements 
    WHERE expires_at IS NULL OR expires_at > NOW()
    ORDER BY created_at DESC 
    LIMIT 3
");
$recent_announcements = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <style>
        .hero-section {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            padding: 100px 0;
            position: relative;
            overflow: hidden;
        }
        .hero-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('assets/images/garage-pattern.png') repeat;
            opacity: 0.1;
            animation: movePattern 20s linear infinite;
        }
        @keyframes movePattern {
            0% { background-position: 0 0; }
            100% { background-position: 100% 100%; }
        }
        .stats-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
        }
        .stats-card:hover {
            transform: translateY(-5px);
        }
        .stats-icon {
            font-size: 2.5rem;
            margin-bottom: 15px;
            color: #1e3c72;
        }
        .service-section {
            background: #f8f9fa;
            padding: 50px 0;
        }
        .service-card {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            text-align: center;
            margin-bottom: 30px;
            transition: transform 0.3s ease;
        }
        .service-card:hover {
            transform: translateY(-5px);
        }
        .service-icon {
            font-size: 2.5rem;
            color: #1e3c72;
            margin-bottom: 20px;
        }
        .mechanic-status {
            font-size: 0.9rem;
            padding: 5px 10px;
            border-radius: 20px;
        }
        .cta-section {
            background: #f8f9fa;
            padding: 80px 0;
        }
        .service-times {
            background: #f8f9fa;
            padding: 50px 0;
        }
        .time-bar {
            height: 30px;
            background: #e9ecef;
            border-radius: 15px;
            margin-bottom: 10px;
            overflow: hidden;
        }
        .time-fill {
            height: 100%;
            background: #1e3c72;
            border-radius: 15px;
        }
        .announcement-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .announcement-date {
            font-size: 0.9rem;
            color: #6c757d;
        }
    </style>
</head>
<body>
    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <h1 class="display-4 mb-4">Professional Auto Repair & Maintenance Services</h1>
                    <p class="lead mb-4">Trust our expert mechanics to keep your vehicle running smoothly. Schedule your service appointment today!</p>
                    <a href="register.php" class="btn btn-light btn-lg me-3">Register Now</a>
                    <a href="login.php" class="btn btn-outline-light btn-lg">Login</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div class="stats-card text-center">
                        <i class="fas fa-tools stats-icon"></i>
                        <h3><?php echo $active_services; ?></h3>
                        <p class="text-muted">Active Services</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stats-card text-center">
                        <i class="fas fa-calendar-check stats-icon"></i>
                        <h3><?php echo $today_appointments; ?></h3>
                        <p class="text-muted">Today's Appointments</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stats-card text-center">
                        <i class="fas fa-user-cog stats-icon"></i>
                        <h3><?php echo $mechanics_stats['available']; ?>/<?php echo $mechanics_stats['total']; ?></h3>
                        <p class="text-muted">Available Mechanics</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stats-card text-center">
                        <i class="fas fa-warehouse stats-icon"></i>
                        <h3><?php echo $available_bays; ?>/<?php echo $total_bays; ?></h3>
                        <p class="text-muted">Available Service Bays</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Services Section -->
    <section class="service-section">
        <div class="container">
            <h2 class="text-center mb-5">Our Services</h2>
            <div class="row">
                <div class="col-md-4">
                    <div class="service-card">
                        <i class="fas fa-oil-can service-icon"></i>
                        <h4>Oil Change</h4>
                        <p>Regular maintenance to keep your engine running smoothly</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="service-card">
                        <i class="fas fa-car-battery service-icon"></i>
                        <h4>Battery Service</h4>
                        <p>Testing, maintenance, and replacement services</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="service-card">
                        <i class="fas fa-cogs service-icon"></i>
                        <h4>Engine Diagnostics</h4>
                        <p>Computer-aided diagnosis of engine issues</p>
                    </div>
                </div>
            </div>
            <div class="row mt-4">
                <div class="col-md-4">
                    <div class="service-card">
                        <i class="fas fa-tire service-icon"></i>
                        <h4>Tire Services</h4>
                        <p>Rotation, balancing, and alignment services</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="service-card">
                        <i class="fas fa-brake-system service-icon"></i>
                        <h4>Brake Service</h4>
                        <p>Complete brake system inspection and repair</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="service-card">
                        <i class="fas fa-air-conditioner service-icon"></i>
                        <h4>AC Service</h4>
                        <p>AC system diagnosis and maintenance</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Popular Services Section -->
    <section class="py-5">
        <div class="container">
            <h2 class="text-center mb-5">Most Popular Services</h2>
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <?php foreach ($popular_services as $service): ?>
                    <div class="mb-4">
                        <h5><?php echo htmlspecialchars($service['name']); ?></h5>
                        <div class="time-bar">
                            <div class="time-fill" style="width: <?php echo min(($service['count'] / 10) * 100, 100); ?>%"></div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </section>

    <!-- Announcements Section -->
    <section class="py-5 bg-light">
        <div class="container">
            <h2 class="text-center mb-5">Latest Updates</h2>
            <div class="row justify-content-center">
                <?php foreach ($recent_announcements as $announcement): ?>
                <div class="col-lg-4">
                    <div class="announcement-card">
                        <h5><?php echo htmlspecialchars($announcement['title']); ?></h5>
                        <p><?php echo htmlspecialchars($announcement['message']); ?></p>
                        <p class="announcement-date">
                            <i class="far fa-calendar-alt me-2"></i>
                            <?php echo date('M d, Y', strtotime($announcement['created_at'])); ?>
                        </p>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta-section">
        <div class="container text-center">
            <h2 class="mb-4">Ready to Get Started?</h2>
            <p class="lead mb-4">Join us today and experience professional auto care services</p>
            <a href="register.php" class="btn btn-primary btn-lg">Schedule Service Now</a>
        </div>
    </section>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>