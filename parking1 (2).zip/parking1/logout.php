<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';

// Perform logout
$result = $auth->logout();

// Redirect to index page
header('Location: index.php');
exit();
?> 