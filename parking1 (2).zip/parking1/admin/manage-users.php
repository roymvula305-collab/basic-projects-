<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';

// Check if user is logged in and is admin
if (!$auth->isLoggedIn() || !$auth->isAdmin()) {
    header('Location: ../login.php');
    exit();
}

$error = '';
$success = '';

// Handle user management actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add_user') {
        $name = $_POST['name'] ?? '';
        $email = $_POST['email'] ?? '';
        $nrc_passport = $_POST['nrc_passport'] ?? '';
        $phone = $_POST['phone'] ?? '';
        $city = $_POST['city'] ?? '';
        $country = $_POST['country'] ?? '';
        $password = $_POST['password'] ?? '';
        $role = $_POST['role'] ?? '';
        
        try {
            // Validate input
            if (empty($name) || empty($email) || empty($password) || empty($role)) {
                throw new Exception('Please fill in all required fields');
            }
            
            // Check if email already exists
            $stmt = $db->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->rowCount() > 0) {
                throw new Exception('Email already exists');
            }
            
            // Hash password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // Insert new user
            $stmt = $db->prepare("
                INSERT INTO users (name, email, password, nrc_passport, phone, city, country, role, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
            ");
            $stmt->execute([$name, $email, $hashed_password, $nrc_passport, $phone, $city, $country, $role]);
            
            echo json_encode(['success' => true, 'message' => 'User added successfully']);
            exit;
            
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit;
        }
    }
    elseif ($action === 'update_user') {
        $user_id = $_POST['user_id'] ?? 0;
        $name = $_POST['name'] ?? '';
        $email = $_POST['email'] ?? '';
        $nrc_passport = $_POST['nrc_passport'] ?? '';
        $phone = $_POST['phone'] ?? '';
        $city = $_POST['city'] ?? '';
        $country = $_POST['country'] ?? '';
        $role = $_POST['role'] ?? '';
        
        try {
            // Validate input
            if (empty($user_id) || empty($name) || empty($email) || empty($role)) {
                throw new Exception('Please fill in all required fields');
            }
            
            // Check if email already exists for another user
            $stmt = $db->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
            $stmt->execute([$email, $user_id]);
            if ($stmt->rowCount() > 0) {
                throw new Exception('Email already exists');
            }
            
            // Update user
            $stmt = $db->prepare("
                UPDATE users 
                SET name = ?, email = ?, nrc_passport = ?, phone = ?, city = ?, country = ?, role = ?
                WHERE id = ?
            ");
            $stmt->execute([$name, $email, $nrc_passport, $phone, $city, $country, $role, $user_id]);
            
            echo json_encode(['success' => true, 'message' => 'User updated successfully']);
            exit;
            
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit;
        }
    }
    elseif ($action === 'delete_user') {
        $user_id = $_POST['user_id'] ?? 0;
        
        try {
            // Check if user has active bookings
            $stmt = $db->prepare("
                SELECT id FROM bookings 
                WHERE user_id = ? AND status IN ('active', 'confirmed')
            ");
            $stmt->execute([$user_id]);
            if ($stmt->rowCount() > 0) {
                throw new Exception('Cannot delete user with active bookings');
            }
            
            // Start transaction
            $db->beginTransaction();
            
            // Delete user's vehicles
            $stmt = $db->prepare("DELETE FROM vehicles WHERE user_id = ?");
            $stmt->execute([$user_id]);
            
            // Delete user's bookings
            $stmt = $db->prepare("DELETE FROM bookings WHERE user_id = ?");
            $stmt->execute([$user_id]);
            
            // Delete user
            $stmt = $db->prepare("DELETE FROM users WHERE id = ?");
            $stmt->execute([$user_id]);
            
            $db->commit();
            echo json_encode(['success' => true, 'message' => 'User deleted successfully']);
            exit;
            
        } catch (Exception $e) {
            $db->rollBack();
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit;
        }
    }
}
elseif ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'get') {
    $user_id = $_GET['id'] ?? 0;
    
    try {
        $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user) {
            echo json_encode($user);
        } else {
            echo json_encode(['error' => 'User not found']);
        }
        exit;
    } catch (Exception $e) {
        echo json_encode(['error' => $e->getMessage()]);
        exit;
    }
}

// Get all users with their vehicle count and last login
$stmt = $db->prepare("
    SELECT 
        u.*, 
           COUNT(v.id) as vehicle_count,
        COUNT(b.id) as active_bookings,
        (SELECT MAX(login_time) FROM user_login_history WHERE user_id = u.id AND status = 'success') as last_login
    FROM users u
    LEFT JOIN vehicles v ON u.id = v.user_id
    LEFT JOIN bookings b ON u.id = b.user_id AND b.status IN ('active', 'confirmed')
    GROUP BY u.id
    ORDER BY u.name
");
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get statistics
$stmt = $db->prepare("
    SELECT 
        COUNT(*) as total_users,
        SUM(CASE WHEN role = 'admin' THEN 1 ELSE 0 END) as admin_users,
        SUM(CASE WHEN role = 'user' THEN 1 ELSE 0 END) as regular_users,
        (SELECT COUNT(DISTINCT user_id) FROM bookings WHERE status = 'active') as active_users,
        (SELECT COUNT(DISTINCT user_id) FROM bookings WHERE status = 'completed') as completed_users,
        (SELECT COUNT(DISTINCT user_id) FROM bookings WHERE status = 'cancelled') as cancelled_users,
        (SELECT COUNT(*) FROM vehicles) as total_vehicles,
        (SELECT COUNT(*) FROM vehicles) / COUNT(*) as avg_vehicles_per_user
    FROM users
");
$stmt->execute();
$stats = $stmt->fetch(PDO::FETCH_ASSOC);

// Get user activity data for the last 30 days
$stmt = $db->prepare("
    SELECT 
        DATE(created_at) as date,
        COUNT(*) as new_users,
        (SELECT COUNT(DISTINCT user_id) 
         FROM bookings 
         WHERE DATE(created_at) = DATE(u.created_at) 
         AND status = 'active') as active_users,
        (SELECT COUNT(*) 
         FROM bookings 
         WHERE DATE(created_at) = DATE(u.created_at)) as bookings
    FROM users u
    WHERE created_at >= DATE_SUB(CURRENT_DATE, INTERVAL 30 DAY)
    GROUP BY DATE(created_at)
    ORDER BY date ASC
");
$stmt->execute();
$user_activity = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get user activity logs with proper joins
$stmt = $db->prepare("
    SELECT 
        al.*,
        u.name as user_name,
        u.email
    FROM user_activity_logs al
    JOIN users u ON al.user_id = u.id
    ORDER BY al.created_at DESC
    LIMIT 100
");
$stmt->execute();
$activity_logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get user login history with proper joins
$stmt = $db->prepare("
    SELECT 
        lh.*,
        u.name as user_name,
        u.email
    FROM user_login_history lh
    JOIN users u ON lh.user_id = u.id
    ORDER BY lh.login_time DESC
    LIMIT 100
");
$stmt->execute();
$login_history = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get user booking history with duration calculation
$stmt = $db->prepare("
    SELECT 
        b.*,
        u.name as user_name,
        v.vehicle_number,
        v.vehicle_type,
        ps.slot_number,
        ps.floor,
        TIMESTAMPDIFF(HOUR, b.start_time, b.end_time) as duration
    FROM bookings b
    JOIN users u ON b.user_id = u.id
    JOIN vehicles v ON b.vehicle_id = v.id
    JOIN parking_slots ps ON b.slot_id = ps.id
    ORDER BY b.created_at DESC
    LIMIT 100
");
$stmt->execute();
$booking_history = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
    <link href="assets/css/admin.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
    .card {
        margin-bottom: 1.5rem;
        border: none;
        box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
    }

    .card-header {
        background-color: #f8f9fa;
        border-bottom: 1px solid rgba(0, 0, 0, 0.125);
        padding: 1rem;
    }

    .card-header h5 {
        margin: 0;
        color: #495057;
    }

    .table-responsive {
        margin: 0;
        padding: 0;
    }

    .table {
        margin-bottom: 0;
    }

    .table th {
        background-color: #f8f9fa;
        border-bottom: 2px solid #dee2e6;
        padding: 0.75rem;
        font-weight: 600;
        text-align: left;
    }

    .table td {
        padding: 0.75rem;
        vertical-align: middle;
    }

    .table-striped tbody tr:nth-of-type(odd) {
        background-color: rgba(0, 0, 0, 0.02);
    }

    .badge {
        padding: 0.5em 0.75em;
        font-weight: 500;
    }

    .text-muted {
        font-size: 0.875rem;
    }
    </style>
</head>
<body>
    <div class="wrapper">
        <?php include 'includes/admin-nav.php'; ?>
        
        <div class="main-content">
            <div class="container-fluid py-4">
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <!-- Statistics Cards -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card stat-card bg-primary text-white">
                    <div class="card-body">
                        <h5 class="card-title">Total Users</h5>
                        <h2><?php echo $stats['total_users']; ?></h2>
                        <div class="stat-details">
                            <span>Active: <?php echo $stats['active_users']; ?></span>
                            <span>Completed: <?php echo $stats['completed_users']; ?></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stat-card bg-success text-white">
                    <div class="card-body">
                        <h5 class="card-title">Admin Users</h5>
                        <h2><?php echo $stats['admin_users']; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stat-card bg-info text-white">
                    <div class="card-body">
                        <h5 class="card-title">Regular Users</h5>
                        <h2><?php echo $stats['regular_users']; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stat-card bg-warning text-white">
                    <div class="card-body">
                        <h5 class="card-title">Total Vehicles</h5>
                        <h2><?php echo $stats['total_vehicles']; ?></h2>
                        <div class="stat-details">
                            <span>Avg/User: <?php echo number_format($stats['avg_vehicles_per_user'], 1); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- User Activity Chart -->
        <div class="card mb-4">
            <div class="card-header">
                <h5>User Activity Overview</h5>
            </div>
            <div class="card-body">
                <div style="height: 400px;">
                    <canvas id="userActivityChart"></canvas>
                </div>
            </div>
        </div>
        
        <div class="card fade-in">
            <div class="card-header">
                <h4>Manage Users</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>NRC/Passport</th>
                                <th>Phone</th>
                                <th>City</th>
                                <th>Country</th>
                                <th>Role</th>
                                <th>Status</th>
                                <th>Vehicles</th>
                                <th>Last Login</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $user): ?>
                                <tr>
                                    <td><?php echo $user['id']; ?></td>
                                    <td><?php echo htmlspecialchars($user['name'] ?? ''); ?></td>
                                    <td><?php echo htmlspecialchars($user['email'] ?? ''); ?></td>
                                    <td><?php echo htmlspecialchars($user['nrc_passport'] ?? ''); ?></td>
                                    <td><?php echo htmlspecialchars($user['phone'] ?? ''); ?></td>
                                    <td><?php echo htmlspecialchars($user['city'] ?? ''); ?></td>
                                    <td><?php echo htmlspecialchars($user['country'] ?? ''); ?></td>
                                    <td>
                                        <span class="badge bg-<?php echo ($user['role'] ?? 'user') === 'admin' ? 'danger' : 'primary'; ?>">
                                            <?php echo ucfirst($user['role'] ?? 'user'); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo ($user['status'] ?? 'active') === 'active' ? 'success' : 'secondary'; ?>">
                                            <?php echo ucfirst($user['status'] ?? 'active'); ?>
                                        </span>
                                    </td>
                                    <td><?php echo $user['vehicle_count']; ?></td>
                                    <td><?php 
                                        if (!empty($user['last_login'])) {
                                            echo date('Y-m-d H:i', strtotime($user['last_login']));
                                        } else {
                                            echo 'Never';
                                        }
                                    ?></td>
                                    <td>
                                        <button type="button" class="btn btn-sm btn-info view-user" data-id="<?php echo $user['id']; ?>">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-warning edit-user" data-id="<?php echo $user['id']; ?>">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-danger delete-user" data-id="<?php echo $user['id']; ?>">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Add User Modal -->
    <div class="modal fade" id="addUserModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New User</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="addUserForm">
                        <div class="mb-3">
                            <label for="name" class="form-label">Full Name</label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                        <div class="mb-3">
                            <label for="nrc_passport" class="form-label">NRC/Passport Number</label>
                            <input type="text" class="form-control" id="nrc_passport" name="nrc_passport" required>
                        </div>
                        <div class="mb-3">
                            <label for="phone" class="form-label">Phone Number</label>
                            <input type="tel" class="form-control" id="phone" name="phone" required>
                        </div>
                        <div class="mb-3">
                            <label for="city" class="form-label">City</label>
                            <input type="text" class="form-control" id="city" name="city" required>
                        </div>
                        <div class="mb-3">
                            <label for="country" class="form-label">Country</label>
                            <input type="text" class="form-control" id="country" name="country" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        <div class="mb-3">
                            <label for="role" class="form-label">Role</label>
                            <select class="form-select" id="role" name="role" required>
                                <option value="user">User</option>
                                <option value="admin">Admin</option>
                            </select>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" onclick="saveUser()">Save User</button>
                </div>
            </div>
        </div>
    </div>
                                
                                <!-- Edit User Modal -->
    <div class="modal fade" id="editUserModal" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Edit User</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                                <div class="modal-body">
                    <form id="editUserForm">
                        <input type="hidden" id="edit_user_id" name="user_id">
                        <div class="mb-3">
                            <label for="edit_name" class="form-label">Full Name</label>
                            <input type="text" class="form-control" id="edit_name" name="name" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="edit_email" name="email" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_nrc_passport" class="form-label">NRC/Passport Number</label>
                            <input type="text" class="form-control" id="edit_nrc_passport" name="nrc_passport" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_phone" class="form-label">Phone Number</label>
                            <input type="tel" class="form-control" id="edit_phone" name="phone" required>
                        </div>
                                                    <div class="mb-3">
                            <label for="edit_city" class="form-label">City</label>
                            <input type="text" class="form-control" id="edit_city" name="city" required>
                                                    </div>
                                                    <div class="mb-3">
                            <label for="edit_country" class="form-label">Country</label>
                            <input type="text" class="form-control" id="edit_country" name="country" required>
                                                    </div>
                                                    <div class="mb-3">
                            <label for="edit_role" class="form-label">Role</label>
                            <select class="form-select" id="edit_role" name="role" required>
                                <option value="user">User</option>
                                <option value="admin">Admin</option>
                                                        </select>
                                                    </div>
                    </form>
                                                </div>
                                                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" onclick="updateUser()">Update User</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
    <script>
    function viewUserDetails(userId) {
        // Fetch user details and show in modal
        fetch(`manage-users.php?action=view&id=${userId}`)
            .then(response => response.json())
            .then(data => {
                // Show user details in a modal
                // Implementation depends on your UI requirements
            });
    }

    function editUser(userId) {
        // Fetch user details
        fetch(`manage-users.php?action=get&id=${userId}`)
            .then(response => response.json())
            .then(data => {
                // Populate edit form
                document.getElementById('edit_user_id').value = data.id;
                document.getElementById('edit_name').value = data.name;
                document.getElementById('edit_email').value = data.email;
                document.getElementById('edit_nrc_passport').value = data.nrc_passport;
                document.getElementById('edit_phone').value = data.phone;
                document.getElementById('edit_city').value = data.city;
                document.getElementById('edit_country').value = data.country;
                document.getElementById('edit_role').value = data.role;
                
                // Show edit modal
                new bootstrap.Modal(document.getElementById('editUserModal')).show();
            });
    }

    function saveUser() {
        const form = document.getElementById('addUserForm');
        const formData = new FormData(form);
        formData.append('action', 'add_user');
        
        fetch('manage-users.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert(data.message);
            }
        });
    }

    function updateUser() {
        const form = document.getElementById('editUserForm');
        const formData = new FormData(form);
        formData.append('action', 'update_user');
        
        fetch('manage-users.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert(data.message);
            }
        });
    }

    function deleteUser(userId) {
        if (confirm('Are you sure you want to delete this user?')) {
            const formData = new FormData();
            formData.append('action', 'delete_user');
            formData.append('user_id', userId);
            
            fetch('manage-users.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert(data.message);
                }
            });
        }
    }

    document.addEventListener('DOMContentLoaded', function() {
        // User Activity Chart
        const ctx = document.getElementById('userActivityChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: <?php echo json_encode(array_column($user_activity, 'date')); ?>,
                datasets: [{
                    label: 'New Users',
                    data: <?php echo json_encode(array_column($user_activity, 'new_users')); ?>,
                    borderColor: '#3498db',
                    backgroundColor: 'rgba(52, 152, 219, 0.1)',
                    tension: 0.1,
                    fill: true
                }, {
                    label: 'Active Users',
                    data: <?php echo json_encode(array_column($user_activity, 'active_users')); ?>,
                    borderColor: '#2ecc71',
                    backgroundColor: 'rgba(46, 204, 113, 0.1)',
                    tension: 0.1,
                    fill: true
                }, {
                    label: 'Bookings',
                    data: <?php echo json_encode(array_column($user_activity, 'bookings')); ?>,
                    borderColor: '#e74c3c',
                    backgroundColor: 'rgba(231, 76, 60, 0.1)',
                    tension: 0.1,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: true,
                        text: 'User Activity (Last 30 Days)'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    }
                }
            }
        });

        // User Management Actions
        document.querySelectorAll('.view-user').forEach(button => {
            button.addEventListener('click', function() {
                const userId = this.dataset.id;
                viewUserDetails(userId);
            });
        });

        document.querySelectorAll('.edit-user').forEach(button => {
            button.addEventListener('click', function() {
                const userId = this.dataset.id;
                editUser(userId);
            });
        });

        document.querySelectorAll('.delete-user').forEach(button => {
            button.addEventListener('click', function() {
                const userId = this.dataset.id;
                deleteUser(userId);
            });
        });

        // Save new user
        document.getElementById('saveUser').addEventListener('click', function() {
            const form = document.getElementById('addUserForm');
            const formData = new FormData(form);
            
            fetch('api/add-user.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert(data.message);
                }
            });
        });
    });
    </script>
</body>
</html> 