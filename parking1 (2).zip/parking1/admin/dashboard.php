<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';

// Check if user is logged in and is admin
if (!$auth->isLoggedIn() || !$auth->isAdmin()) {
    header('Location: ../login.php');
    exit();
}

// Get statistics
$stats = [
    'total_slots' => 0,
    'available_slots' => 0,
    'occupied_slots' => 0,
    'maintenance_slots' => 0,
    'total_bookings' => 0,
    'active_bookings' => 0,
    'total_revenue' => 0,
    'total_penalties' => 0
];

// Get slot statistics
$stmt = $db->query("
    SELECT ps.status, COUNT(*) as count 
    FROM parking_slots ps
    GROUP BY ps.status
");
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $stats['total_slots'] += $row['count'];
    switch ($row['status']) {
        case 'available':
            $stats['available_slots'] = $row['count'];
            break;
        case 'occupied':
            $stats['occupied_slots'] = $row['count'];
            break;
        case 'maintenance':
            $stats['maintenance_slots'] = $row['count'];
            break;
    }
}

// Get booking statistics
$stmt = $db->query("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN b.status = 'active' THEN 1 ELSE 0 END) as active,
        SUM(
            CASE 
                WHEN b.status = 'completed' THEN 
                    (TIMESTAMPDIFF(HOUR, b.start_time, b.end_time) * 50) + 
                    (CASE WHEN b.penalty_amount > 0 THEN b.penalty_amount ELSE 0 END)
                ELSE 0 
            END
        ) as revenue,
        SUM(b.penalty_amount) as penalties
    FROM bookings b
");
$row = $stmt->fetch(PDO::FETCH_ASSOC);
$stats['total_bookings'] = $row['total'];
$stats['active_bookings'] = $row['active'];
$stats['total_revenue'] = $row['revenue'];
$stats['total_penalties'] = $row['penalties'];

// Get upcoming and overdue bookings
$stmt = $db->query("
    SELECT 
        b.*,
        u.name as user_name,
        u.email as user_email,
        ps.slot_number,
        ps.floor,
        CASE 
            WHEN b.end_time < NOW() THEN 'overdue'
            WHEN b.end_time < DATE_ADD(NOW(), INTERVAL 1 HOUR) THEN 'upcoming'
            ELSE 'active'
        END as reminder_status,
        TIMESTAMPDIFF(HOUR, b.start_time, b.end_time) * 50 as regular_amount,
        CASE 
            WHEN b.end_time < NOW() THEN 
                TIMESTAMPDIFF(HOUR, b.end_time, NOW()) * 100
            ELSE 0 
        END as estimated_penalty
    FROM bookings b
    JOIN users u ON b.user_id = u.id
    JOIN parking_slots ps ON b.slot_id = ps.id
    WHERE b.status = 'active'
    AND (b.end_time < NOW() OR b.end_time < DATE_ADD(NOW(), INTERVAL 1 HOUR))
    ORDER BY b.end_time ASC
");
$reminders = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get all slots grouped by floor
$stmt = $db->query("
    SELECT ps.*, 
           b.id as booking_id,
           b.status as booking_status,
           CASE 
               WHEN b.status = 'active' THEN 'occupied'
               ELSE ps.status
           END as display_status
    FROM parking_slots ps
    LEFT JOIN bookings b ON ps.id = b.slot_id AND b.status = 'active'
    ORDER BY ps.floor, ps.x_coordinate, ps.y_coordinate
");
$slots = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Group slots by floor
$slots_by_floor = [];
foreach ($slots as $slot) {
    $slots_by_floor[$slot['floor']][] = $slot;
}

// Get additional statistics
try {
    // Get today's statistics
    $stmt = $conn->prepare("
        SELECT 
            COUNT(*) as today_bookings,
            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as today_completed,
            SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as today_active,
            SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as today_cancelled,
            SUM(CASE WHEN status = 'completed' THEN amount ELSE 0 END) as today_revenue
        FROM bookings 
        WHERE DATE(created_at) = CURDATE()
    ");
    $stmt->execute();
    $today_stats = $stmt->fetch(PDO::FETCH_ASSOC);

    // Get weekly statistics
    $stmt = $conn->prepare("
        SELECT 
            COUNT(*) as weekly_bookings,
            SUM(CASE WHEN status = 'completed' THEN amount ELSE 0 END) as weekly_revenue,
            AVG(CASE WHEN status = 'completed' THEN amount ELSE 0 END) as avg_booking_amount
        FROM bookings 
        WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
    ");
    $stmt->execute();
    $weekly_stats = $stmt->fetch(PDO::FETCH_ASSOC);

    // Get popular parking slots
    $stmt = $conn->prepare("
        SELECT s.name, COUNT(b.id) as booking_count
        FROM slots s
        LEFT JOIN bookings b ON s.id = b.slot_id
        WHERE b.created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
        GROUP BY s.id
        ORDER BY booking_count DESC
        LIMIT 5
    ");
    $stmt->execute();
    $popular_slots = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $error = 'Failed to load statistics: ' . $e->getMessage();
}

// Get popular parking slots (last 30 days)
$stmt = $db->prepare("
    SELECT s.slot_number, COUNT(b.id) as booking_count
    FROM parking_slots s
    LEFT JOIN bookings b ON s.id = b.slot_id
    WHERE b.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    GROUP BY s.id
    ORDER BY booking_count DESC
    LIMIT 5
");
$stmt->execute();
$popular_slots = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get recent bookings
$stmt = $db->prepare("
    SELECT b.*, u.name as user_name, s.slot_number as slot_name
    FROM bookings b
    JOIN users u ON b.user_id = u.id
    JOIN parking_slots s ON b.slot_id = s.id
    ORDER BY b.created_at DESC
    LIMIT 5
");
$stmt->execute();
$recent_bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get total slots
$total_revenue = $stmt->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
    <link href="assets/css/admin.css" rel="stylesheet">
    <style>
        .parking-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 10px;
            margin-bottom: 20px;
        }
        .parking-slot {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
            border-radius: 5px;
            position: relative;
            min-height: 80px;
        }
        .parking-slot.handicap {
            background-color: #ffd700;
        }
        .parking-slot.electric {
            background-color: #90ee90;
        }
        .parking-slot.regular {
            background-color: #f0f0f0;
        }
        .parking-slot.occupied {
            background-color: #ff6b6b;
        }
        .parking-slot.maintenance {
            background-color: #a9a9a9;
        }
        .slot-number {
            font-weight: bold;
            margin-bottom: 5px;
        }
        .slot-type {
            font-size: 0.8em;
            color: #666;
        }
        .building {
            background-color: #333;
            color: white;
            padding: 10px;
            text-align: center;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        .floor-label {
            background-color: #007bff;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
            margin-bottom: 10px;
            display: inline-block;
        }
        .stat-card {
            transition: transform 0.3s ease;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <?php include 'includes/admin-nav.php'; ?>
        
        <div class="main-content">
            <div class="container-fluid py-4">
        <!-- Reminders Section -->
        <?php if (!empty($reminders)): ?>
        <div class="row mb-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header bg-warning">
                        <h5 class="mb-0">
                            <i class="fas fa-bell"></i> Booking Reminders
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>User</th>
                                        <th>Slot</th>
                                        <th>End Time</th>
                                        <th>Status</th>
                                        <th>Penalty</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($reminders as $reminder): ?>
                                    <tr class="<?php echo $reminder['reminder_status'] === 'overdue' ? 'table-danger' : 'table-warning'; ?>">
                                        <td>
                                            <?php echo htmlspecialchars($reminder['user_name']); ?><br>
                                            <small class="text-muted"><?php echo htmlspecialchars($reminder['user_email']); ?></small>
                                        </td>
                                        <td>
                                            <?php echo htmlspecialchars($reminder['slot_number']); ?><br>
                                            <small class="text-muted">Floor <?php echo htmlspecialchars($reminder['floor']); ?></small>
                                        </td>
                                        <td>
                                            <?php echo date('Y-m-d H:i', strtotime($reminder['end_time'])); ?><br>
                                            <small class="text-muted">
                                                <?php 
                                                $end_time = new DateTime($reminder['end_time']);
                                                $now = new DateTime();
                                                $diff = $now->diff($end_time);
                                                if ($end_time < $now) {
                                                    echo 'Overdue by ' . $diff->format('%h hours %i minutes');
                                                } else {
                                                    echo 'Ends in ' . $diff->format('%h hours %i minutes');
                                                }
                                                ?>
                                            </small>
                                        </td>
                                        <td>
                                            <span class="badge bg-<?php echo $reminder['reminder_status'] === 'overdue' ? 'danger' : 'warning'; ?>">
                                                <?php echo ucfirst($reminder['reminder_status']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php if ($reminder['reminder_status'] === 'overdue'): ?>
                                                K<?php echo number_format($reminder['estimated_penalty'], 2); ?>
                                            <?php else: ?>
                                                -
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="view-bookings.php?id=<?php echo $reminder['id']; ?>" class="btn btn-sm btn-primary">
                                                <i class="fas fa-eye"></i> View
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Statistics Cards -->
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card bg-primary text-white">
                    <div class="card-body">
                        <h5 class="card-title">Today's Bookings</h5>
                        <h2><?php echo $today_stats['today_bookings'] ?? 0; ?></h2>
                        <div class="d-flex justify-content-between align-items-center">
                            <small>Active: <?php echo $today_stats['today_active'] ?? 0; ?></small>
                            <small>Completed: <?php echo $today_stats['today_completed'] ?? 0; ?></small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-info text-white">
                    <div class="card-body">
                        <h5 class="card-title">Weekly Bookings</h5>
                        <h2><?php echo $weekly_stats['weekly_bookings'] ?? 0; ?></h2>
                        <small>Avg/Booking: <?php echo $settings['currency'] ?? 'K'; ?><?php echo number_format($weekly_stats['avg_booking_amount'] ?? 0, 2); ?></small>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-warning text-white">
                    <div class="card-body">
                        <h5 class="card-title">Today's Cancellations</h5>
                        <h2><?php echo $today_stats['today_cancelled'] ?? 0; ?></h2>
                        <small>Cancellation Rate: <?php echo $today_stats['today_bookings'] > 0 ? round(($today_stats['today_cancelled'] / $today_stats['today_bookings']) * 100, 1) : 0; ?>%</small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Popular Parking Slots -->
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Popular Parking Slots</h5>
                <a href="view-bookings.php" class="btn btn-sm btn-primary">See More</a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Slot Name</th>
                                <th>Bookings (30 days)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach (array_slice($popular_slots, 0, 3) as $slot): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($slot['slot_number']); ?></td>
                                    <td><?php echo $slot['booking_count']; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Recent Activity -->
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Recent Activity</h5>
                <a href="view-bookings.php" class="btn btn-sm btn-primary">See More</a>
            </div>
            <div class="card-body">
                <div class="activity-list">
                    <?php foreach (array_slice($recent_bookings, 0, 3) as $booking): ?>
                        <div class="activity-item mb-3">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <strong><?php echo htmlspecialchars($booking['user_name']); ?></strong>
                                    <span class="badge bg-<?php 
                                        echo $booking['status'] === 'active' ? 'success' : 
                                            ($booking['status'] === 'completed' ? 'secondary' : 'danger'); 
                                    ?>">
                                        <?php echo ucfirst($booking['status']); ?>
                                    </span>
                                </div>
                                <small class="text-muted">
                                    <?php echo date('M d, Y H:i', strtotime($booking['created_at'])); ?>
                                </small>
                            </div>
                            <div class="mt-1">
                                <small class="text-muted">
                                    Slot: <?php echo htmlspecialchars($booking['slot_name']); ?>
                                </small>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- Parking Layout -->
        <div class="card fade-in">
            <div class="card-header">
                <h4>Parking Layout</h4>
            </div>
            <div class="card-body">
                <?php foreach ($slots_by_floor as $floor => $slots): ?>
                    <div class="mb-4">
                        <div class="floor-label">Floor <?php echo $floor; ?></div>
                        <div class="building">Building Entrance</div>
                        <div class="parking-grid">
                            <?php foreach ($slots as $slot): ?>
                                <div class="parking-slot <?php echo $slot['type']; ?> <?php echo $slot['display_status']; ?>">
                                    <div class="slot-number"><?php echo htmlspecialchars($slot['slot_number']); ?></div>
                                    <div class="slot-type"><?php echo ucfirst($slot['type']); ?></div>
                                    <div class="slot-status">
                                        <span class="badge bg-<?php 
                                            echo $slot['display_status'] === 'available' ? 'success' : 
                                                ($slot['display_status'] === 'occupied' ? 'danger' : 'warning'); 
                                        ?>">
                                            <?php echo ucfirst($slot['display_status']); ?>
                                        </span>
                                    </div>
                                    <?php if (!empty($slot['booking_id'])): ?>
                                        <a href="view-bookings.php?booking_id=<?php echo $slot['booking_id']; ?>" class="btn btn-sm btn-info mt-2">
                                            <i class="fas fa-info-circle"></i> View Booking
                                        </a>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/main.js"></script>
</body>
</html> 