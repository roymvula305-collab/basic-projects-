<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';

// Check if user is logged in and is admin
if (!$auth->isLoggedIn() || !$auth->isAdmin()) {
    header('Location: ../login.php');
    exit();
}

$error = '';
$success = '';

// Handle actions
if (isset($_GET['action'])) {
    switch ($_GET['action']) {
        case 'add_announcement':
            $title = $_POST['title'] ?? '';
            $message = $_POST['message'] ?? '';
            $recipient_type = $_POST['recipient_type'] ?? 'all';
            $recipient_id = $_POST['recipient_id'] ?? null;
            $duration_days = $_POST['duration_days'] ?? null;
            
            if (empty($title) || empty($message)) {
                $error = 'Please fill in all required fields';
            } else {
                try {
                    // Calculate expiration date if duration is set
                    $expires_at = null;
                    if ($duration_days && is_numeric($duration_days)) {
                        $expires_at = date('Y-m-d H:i:s', strtotime("+$duration_days days"));
                    }
                    
                    $stmt = $db->prepare("INSERT INTO announcements (title, message, recipient_type, recipient_id, created_at, expires_at, duration_days) VALUES (?, ?, ?, ?, NOW(), ?, ?)");
                    $stmt->execute([$title, $message, $recipient_type, $recipient_id, $expires_at, $duration_days]);
                    $success = 'Announcement sent successfully';
                    header('Location: manage-announcements.php?success=1');
                    exit();
                } catch (PDOException $e) {
                    $error = 'Failed to send announcement: ' . $e->getMessage();
                }
            }
            break;
            
        case 'delete_announcement':
            $id = $_GET['id'] ?? 0;
            if ($id) {
                try {
                    $stmt = $db->prepare("DELETE FROM announcements WHERE id = ?");
                    $stmt->execute([$id]);
                    $success = 'Announcement deleted successfully';
                    header('Location: manage-announcements.php?success=2');
                    exit();
                } catch (PDOException $e) {
                    $error = 'Failed to delete announcement: ' . $e->getMessage();
                }
            }
            break;
    }
}

// Get all announcements
$stmt = $db->query("
    SELECT a.*, u.name as recipient_name,
           CASE 
               WHEN a.expires_at IS NULL THEN 'Never'
               WHEN a.expires_at < NOW() THEN 'Expired'
               ELSE DATE_FORMAT(a.expires_at, '%M %d, %Y %H:%i')
           END as expiration_status
    FROM announcements a 
    LEFT JOIN users u ON a.recipient_id = u.id 
    ORDER BY a.created_at DESC
");
$announcements = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get all users for recipient selection
$stmt = $db->query("SELECT id, name FROM users ORDER BY name");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Announcements - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
    <link href="assets/css/admin.css" rel="stylesheet">
</head>
<body>
    <div class="wrapper">
        <?php include 'includes/admin-nav.php'; ?>
        
        <div class="main-content">
            <div class="container-fluid py-4">
                <div class="card">
                    <div class="card-header">
                        <h4>Manage Announcements</h4>
                    </div>
                    <div class="card-body">
                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        
                        <?php if ($success): ?>
                            <div class="alert alert-success"><?php echo $success; ?></div>
                        <?php endif; ?>

                        <!-- Add Announcement Button -->
                        <button type="button" class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addAnnouncementModal">
                            <i class="fas fa-plus"></i> New Announcement
                        </button>

                        <!-- Announcements Table -->
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Title</th>
                                        <th>Message</th>
                                        <th>Recipient</th>
                                        <th>Date</th>
                                        <th>Expires</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($announcements as $announcement): ?>
                                        <tr class="<?php echo $announcement['expiration_status'] === 'Expired' ? 'table-secondary' : ''; ?>">
                                            <td><?php echo htmlspecialchars($announcement['title']); ?></td>
                                            <td><?php echo htmlspecialchars($announcement['message']); ?></td>
                                            <td>
                                                <?php 
                                                if ($announcement['recipient_type'] === 'all') {
                                                    echo 'All Users';
                                                } else {
                                                    echo htmlspecialchars($announcement['recipient_name'] ?? 'User not found');
                                                }
                                                ?>
                                            </td>
                                            <td><?php echo date('M d, Y H:i', strtotime($announcement['created_at'])); ?></td>
                                            <td><?php echo $announcement['expiration_status']; ?></td>
                                            <td>
                                                <?php if ($announcement['expiration_status'] === 'Expired'): ?>
                                                    <span class="badge bg-secondary">Expired</span>
                                                <?php else: ?>
                                                    <span class="badge bg-success">Active</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="manage-announcements.php?action=delete_announcement&id=<?php echo $announcement['id']; ?>" 
                                                   class="btn btn-sm btn-danger" 
                                                   onclick="return confirm('Are you sure you want to delete this announcement?')">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Announcement Modal -->
    <div class="modal fade" id="addAnnouncementModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">New Announcement</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="manage-announcements.php?action=add_announcement">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Title</label>
                            <input type="text" class="form-control" name="title" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Message</label>
                            <textarea class="form-control" name="message" rows="4" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Recipient</label>
                            <select class="form-select" name="recipient_type" id="recipientType" required>
                                <option value="all">All Users</option>
                                <option value="specific">Specific User</option>
                            </select>
                        </div>
                        <div class="mb-3" id="specificUserContainer" style="display: none;">
                            <label class="form-label">Select User</label>
                            <select class="form-select" name="recipient_id">
                                <?php foreach ($users as $user): ?>
                                    <option value="<?php echo $user['id']; ?>"><?php echo htmlspecialchars($user['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Duration (in days)</label>
                            <input type="number" class="form-control" name="duration_days" min="1" placeholder="Leave empty for no expiration">
                            <small class="text-muted">The announcement will automatically expire after the specified number of days.</small>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Send Announcement</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.getElementById('recipientType').addEventListener('change', function() {
            const specificUserContainer = document.getElementById('specificUserContainer');
            specificUserContainer.style.display = this.value === 'specific' ? 'block' : 'none';
        });
    </script>
</body>
</html> 