<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';

// Check if user is logged in and is admin
if (!$auth->isLoggedIn() || !$auth->isAdmin()) {
    header('Location: ../login.php');
    exit();
}

// Get date range
$date_from = $_GET['date_from'] ?? date('Y-m-d', strtotime('-30 days'));
$date_to = $_GET['date_to'] ?? date('Y-m-d');

// Get daily statistics
$stmt = $db->prepare("
    SELECT 
        DATE(created_at) as date,
        COUNT(*) as total_bookings,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_bookings,
        SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled_bookings
    FROM bookings
    WHERE created_at BETWEEN ? AND ?
    GROUP BY DATE(created_at)
    ORDER BY date DESC
");
$stmt->execute([$date_from . ' 00:00:00', $date_to . ' 23:59:59']);
$daily_stats = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get revenue statistics
$stmt = $db->prepare("
    SELECT 
        DATE(b.created_at) as date,
        COUNT(*) as total_bookings,
        SUM(CASE WHEN b.status = 'completed' THEN 1 ELSE 0 END) as completed_bookings,
        SUM(CASE WHEN b.status = 'cancelled' THEN 1 ELSE 0 END) as cancelled_bookings,
        SUM(
            CASE 
                WHEN b.status = 'completed' THEN 
                    (TIMESTAMPDIFF(HOUR, b.start_time, b.end_time) * 50) + 
                    (CASE WHEN b.penalty_amount > 0 THEN b.penalty_amount ELSE 0 END)
                ELSE 0 
            END
        ) as total_revenue,
        SUM(b.penalty_amount) as total_penalties,
        SUM(
            CASE 
                WHEN b.status = 'completed' THEN 
                    (TIMESTAMPDIFF(HOUR, b.start_time, b.end_time) * 50) + 
                    COALESCE(b.penalty_amount, 0)
                ELSE 0 
            END
        ) as total_with_penalties
    FROM bookings b
    WHERE b.created_at BETWEEN ? AND ?
    GROUP BY DATE(b.created_at)
    ORDER BY date ASC
");
$stmt->execute([$date_from . ' 00:00:00', $date_to . ' 23:59:59']);
$daily_stats = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get slot type statistics
$stmt = $db->prepare("
    SELECT 
        p.type,
        COUNT(*) as total_bookings,
        COALESCE(SUM(py.amount), 0) as total_revenue
    FROM bookings b
    JOIN parking_slots p ON b.slot_id = p.id
    LEFT JOIN payments py ON b.id = py.booking_id
    WHERE b.created_at BETWEEN ? AND ?
    GROUP BY p.type
");
$stmt->execute([$date_from . ' 00:00:00', $date_to . ' 23:59:59']);
$slot_stats = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate totals
$total_bookings = 0;
$total_revenue = 0;
$total_penalties = 0;
$total_with_penalties = 0;
$total_completed = 0;
$total_cancelled = 0;

foreach ($daily_stats as $stat) {
    $total_bookings += $stat['total_bookings'];
    $total_revenue += $stat['total_revenue'];
    $total_penalties += $stat['total_penalties'];
    $total_with_penalties += $stat['total_with_penalties'];
    $total_completed += $stat['completed_bookings'];
    $total_cancelled += $stat['cancelled_bookings'];
}

$avg_revenue_per_booking = $total_bookings > 0 ? $total_revenue / $total_bookings : 0;

// Get user activity statistics
$stmt = $db->prepare("
    SELECT 
        u.id,
        u.name,
        COUNT(b.id) as total_bookings,
        SUM(CASE WHEN b.status = 'completed' THEN 1 ELSE 0 END) as completed_bookings,
        SUM(CASE WHEN b.status = 'cancelled' THEN 1 ELSE 0 END) as cancelled_bookings,
        SUM(
            CASE 
                WHEN b.status = 'completed' THEN 
                    (TIMESTAMPDIFF(HOUR, b.start_time, b.end_time) * 50) + 
                    COALESCE(b.penalty_amount, 0)
                ELSE 0 
            END
        ) as total_spent,
        MAX(b.created_at) as last_booking
    FROM users u
    LEFT JOIN bookings b ON u.id = b.user_id
    WHERE b.created_at BETWEEN ? AND ?
    GROUP BY u.id
    ORDER BY total_spent DESC
    LIMIT 10
");
$stmt->execute([$date_from . ' 00:00:00', $date_to . ' 23:59:59']);
$top_users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get peak hours analysis
$stmt = $db->prepare("
    SELECT 
        HOUR(check_in_time) as hour,
        COUNT(*) as total_bookings,
        AVG(TIMESTAMPDIFF(HOUR, start_time, end_time)) as avg_duration
    FROM bookings
    WHERE check_in_time BETWEEN ? AND ?
    GROUP BY HOUR(check_in_time)
    ORDER BY hour
");
$stmt->execute([$date_from . ' 00:00:00', $date_to . ' 23:59:59']);
$peak_hours = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get vehicle type statistics
$stmt = $db->prepare("
    SELECT 
        v.vehicle_type,
        COUNT(*) as total_bookings,
        AVG(TIMESTAMPDIFF(HOUR, b.start_time, b.end_time)) as avg_duration,
        SUM(
            CASE 
                WHEN b.status = 'completed' THEN 
                    (TIMESTAMPDIFF(HOUR, b.start_time, b.end_time) * 50) + 
                    COALESCE(b.penalty_amount, 0)
                ELSE 0 
            END
        ) as total_revenue
    FROM vehicles v
    JOIN bookings b ON v.id = b.vehicle_id
    WHERE b.created_at BETWEEN ? AND ?
    GROUP BY v.vehicle_type
");
$stmt->execute([$date_from . ' 00:00:00', $date_to . ' 23:59:59']);
$vehicle_stats = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
    <link href="assets/css/admin.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels"></script>
</head>
<body>
    <div class="wrapper">
        <?php include 'includes/admin-nav.php'; ?>
        
        <div class="main-content">
            <div class="container-fluid py-4">
        <!-- Date Range Filter -->
        <div class="card mb-4">
            <div class="card-body">
                <form method="GET" action="" class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label">Date From</label>
                        <input type="date" class="form-control" name="date_from" value="<?php echo $date_from; ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Date To</label>
                        <input type="date" class="form-control" name="date_to" value="<?php echo $date_to; ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">&nbsp;</label>
                        <button type="submit" class="btn btn-primary d-block">Generate Report</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Summary Statistics -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card stat-card bg-primary text-white">
                    <div class="card-body">
                        <h5 class="card-title">Total Bookings</h5>
                        <h2><?php echo $total_bookings; ?></h2>
                                <div class="stat-details">
                                    <span>Completed: <?php echo $total_completed; ?></span>
                                    <span>Cancelled: <?php echo $total_cancelled; ?></span>
                                </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stat-card bg-success text-white">
                    <div class="card-body">
                        <h5 class="card-title">Total Revenue</h5>
                        <h2>K<?php echo number_format($total_revenue, 2); ?></h2>
                                <div class="stat-details">
                                    <span>Avg/Booking: K<?php echo number_format($avg_revenue_per_booking, 2); ?></span>
                                </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stat-card bg-danger text-white">
                    <div class="card-body">
                        <h5 class="card-title">Total Penalties</h5>
                        <h2>K<?php echo number_format($total_penalties, 2); ?></h2>
                                <div class="stat-details">
                                    <span>Penalty Rate: <?php echo number_format(($total_penalties / $total_revenue) * 100, 1); ?>%</span>
                                </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stat-card bg-info text-white">
                    <div class="card-body">
                        <h5 class="card-title">Total with Penalties</h5>
                        <h2>K<?php echo number_format($total_with_penalties, 2); ?></h2>
                                <div class="stat-details">
                                    <span>Growth: <?php echo number_format((($total_with_penalties - $total_revenue) / $total_revenue) * 100, 1); ?>%</span>
                                </div>
                    </div>
                </div>
            </div>
        </div>

                <!-- Charts Row 1 -->
        <div class="row mb-4">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                                <h5>Daily Bookings Trend</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="bookingsChart"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                                <h5>Revenue Analysis</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="revenueChart"></canvas>
                    </div>
                </div>
            </div>
        </div>

                <!-- Charts Row 2 -->
                <div class="row mb-4">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h5>Peak Hours Analysis</h5>
                            </div>
                            <div class="card-body">
                                <canvas id="peakHoursChart"></canvas>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h5>Vehicle Type Distribution</h5>
                            </div>
                            <div class="card-body">
                                <canvas id="vehicleTypeChart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Top Users -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5>Top Users by Spending</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>User</th>
                                        <th>Total Bookings</th>
                                        <th>Completed</th>
                                        <th>Cancelled</th>
                                        <th>Total Spent</th>
                                        <th>Last Booking</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($top_users as $user): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($user['name']); ?></td>
                                            <td><?php echo $user['total_bookings']; ?></td>
                                            <td><?php echo $user['completed_bookings']; ?></td>
                                            <td><?php echo $user['cancelled_bookings']; ?></td>
                                            <td>K<?php echo number_format($user['total_spent'], 2); ?></td>
                                            <td><?php echo date('Y-m-d H:i', strtotime($user['last_booking'])); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                </div>
            </div>
        </div>

        <!-- Slot Type Statistics -->
        <div class="card mb-4">
            <div class="card-header">
                        <h5>Slot Type Performance</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Type</th>
                                <th>Total Bookings</th>
                                <th>Total Revenue</th>
                                <th>Avg. Revenue/Booking</th>
                                        <th>Utilization Rate</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($slot_stats as $stat): ?>
                                <tr>
                                    <td><?php echo ucfirst($stat['type']); ?></td>
                                    <td><?php echo $stat['total_bookings']; ?></td>
                                    <td>K<?php echo number_format($stat['total_revenue'], 2); ?></td>
                                    <td>K<?php echo number_format($stat['total_revenue'] / $stat['total_bookings'], 2); ?></td>
                                            <td><?php echo number_format(($stat['total_bookings'] / $total_bookings) * 100, 1); ?>%</td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
                </div>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Bookings Chart
        new Chart(document.getElementById('bookingsChart'), {
            type: 'line',
            data: {
                labels: <?php echo json_encode(array_column($daily_stats, 'date')); ?>,
                datasets: [{
                    label: 'Total Bookings',
                    data: <?php echo json_encode(array_column($daily_stats, 'total_bookings')); ?>,
                    borderColor: '#3498db',
                    tension: 0.1
                }, {
                    label: 'Completed',
                    data: <?php echo json_encode(array_column($daily_stats, 'completed_bookings')); ?>,
                    borderColor: '#2ecc71',
                    tension: 0.1
                }, {
                    label: 'Cancelled',
                    data: <?php echo json_encode(array_column($daily_stats, 'cancelled_bookings')); ?>,
                    borderColor: '#e74c3c',
                    tension: 0.1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    }
                }
            }
        });

        // Revenue Chart
        new Chart(document.getElementById('revenueChart'), {
            type: 'bar',
            data: {
                labels: <?php echo json_encode(array_column($daily_stats, 'date')); ?>,
                datasets: [{
                    label: 'Revenue',
                    data: <?php echo json_encode(array_column($daily_stats, 'total_revenue')); ?>,
                    backgroundColor: '#2ecc71'
                }, {
                    label: 'Penalties',
                    data: <?php echo json_encode(array_column($daily_stats, 'total_penalties')); ?>,
                    backgroundColor: '#e74c3c'
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    }
                }
            }
        });

        // Peak Hours Chart
        new Chart(document.getElementById('peakHoursChart'), {
            type: 'bar',
            data: {
                labels: <?php echo json_encode(array_map(function($hour) { return sprintf('%02d:00', $hour['hour']); }, $peak_hours)); ?>,
                datasets: [{
                    label: 'Bookings',
                    data: <?php echo json_encode(array_column($peak_hours, 'total_bookings')); ?>,
                    backgroundColor: '#3498db'
                }, {
                    label: 'Avg. Duration (hours)',
                    data: <?php echo json_encode(array_column($peak_hours, 'avg_duration')); ?>,
                    backgroundColor: '#9b59b6',
                    yAxisID: 'y1'
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Number of Bookings'
                        }
                    },
                    y1: {
                        position: 'right',
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Average Duration'
                        }
                    }
                }
            }
        });

        // Vehicle Type Chart
        new Chart(document.getElementById('vehicleTypeChart'), {
            type: 'doughnut',
            data: {
                labels: <?php echo json_encode(array_column($vehicle_stats, 'vehicle_type')); ?>,
                datasets: [{
                    data: <?php echo json_encode(array_column($vehicle_stats, 'total_revenue')); ?>,
                    backgroundColor: [
                        '#3498db',
                        '#2ecc71',
                        '#e74c3c',
                        '#f1c40f',
                        '#9b59b6'
                    ]
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'right',
                    },
                    datalabels: {
                        formatter: (value) => {
                            return 'K' + value.toLocaleString();
                        }
                    }
                }
            }
        });
        });
    </script>
</body>
</html> 