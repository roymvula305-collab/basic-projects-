<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';

// Check if user is logged in and is admin
if (!$auth->isLoggedIn() || !$auth->isAdmin()) {
    header('Location: ../login.php');
    exit();
}

// Get filter parameters
$status = $_GET['status'] ?? 'all';
$date_from = $_GET['date_from'] ?? date('Y-m-d', strtotime('-7 days'));
$date_to = $_GET['date_to'] ?? date('Y-m-d');

// Get all bookings with user and slot details
$stmt = $db->prepare("
    SELECT 
        b.*,
        u.name as user_name,
        u.email as user_email,
        ps.slot_number,
        ps.floor,
        ps.type as slot_type,
        p.amount as payment_amount,
        p.status as payment_status,
        p.created_at as payment_date,
        p.payment_method,
        v.vehicle_number,
        v.vehicle_type,
        v.vehicle_model,
        v.vehicle_color,
        CASE 
            WHEN b.end_time < NOW() AND b.status = 'active' THEN 
                TIMESTAMPDIFF(HOUR, b.end_time, NOW()) * 100
            ELSE b.penalty_amount 
        END as current_penalty
    FROM bookings b
    LEFT JOIN users u ON b.user_id = u.id
    LEFT JOIN parking_slots ps ON b.slot_id = ps.id
    LEFT JOIN payments p ON b.id = p.booking_id
    LEFT JOIN vehicles v ON b.vehicle_id = v.id
    ORDER BY b.created_at DESC
");
$stmt->execute();
$bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate statistics
$total_bookings = count($bookings);
$active_bookings = array_filter($bookings, function($b) { return $b['status'] === 'active'; });
$completed_bookings = array_filter($bookings, function($b) { return $b['status'] === 'completed'; });
$cancelled_bookings = array_filter($bookings, function($b) { return $b['status'] === 'cancelled'; });

$total_revenue = array_reduce($bookings, function($sum, $b) {
    return $sum + ($b['payment_status'] === 'completed' ? $b['amount'] : 0);
}, 0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Bookings - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
    <link href="assets/css/admin.css" rel="stylesheet">
</head>
<body>
    <div class="wrapper">
        <?php include 'includes/admin-nav.php'; ?>
        
        <div class="main-content">
            <div class="container-fluid py-4">
        <!-- Statistics Cards -->
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card bg-primary text-white">
                    <div class="card-body">
                        <h5 class="card-title">Total Bookings</h5>
                        <h2><?php echo $total_bookings; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-success text-white">
                    <div class="card-body">
                        <h5 class="card-title">Active Bookings</h5>
                        <h2><?php echo count($active_bookings); ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-info text-white">
                    <div class="card-body">
                        <h5 class="card-title">Completed</h5>
                        <h2><?php echo count($completed_bookings); ?></h2>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filters -->
        <div class="card mb-4">
            <div class="card-body">
                <form method="GET" action="" class="row g-3">
                    <div class="col-md-3">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select">
                            <option value="all" <?php echo $status === 'all' ? 'selected' : ''; ?>>All</option>
                            <option value="active" <?php echo $status === 'active' ? 'selected' : ''; ?>>Active</option>
                            <option value="completed" <?php echo $status === 'completed' ? 'selected' : ''; ?>>Completed</option>
                            <option value="cancelled" <?php echo $status === 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Date From</label>
                        <input type="date" class="form-control" name="date_from" value="<?php echo $date_from; ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Date To</label>
                        <input type="date" class="form-control" name="date_to" value="<?php echo $date_to; ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">&nbsp;</label>
                        <button type="submit" class="btn btn-primary d-block">Apply Filters</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Bookings Table -->
        <div class="card">
            <div class="card-header">
                <h4>Booking Records</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>User</th>
                                <th>Slot</th>
                                <th>Duration</th>
                                <th>Status</th>
                                <th>Payment</th>
                                <th>Created At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($bookings as $booking): ?>
                                <tr>
                                    <td>#<?php echo $booking['id']; ?></td>
                                    <td>
                                        <?php echo htmlspecialchars($booking['user_name']); ?><br>
                                        <small class="text-muted"><?php echo htmlspecialchars($booking['user_email']); ?></small>
                                    </td>
                                    <td>
                                        Floor <?php echo htmlspecialchars($booking['floor']); ?> - 
                                        Slot <?php echo htmlspecialchars($booking['slot_number']); ?><br>
                                        <small class="text-muted"><?php echo ucfirst($booking['slot_type']); ?></small>
                                    </td>
                                    <td>
                                        <?php echo date('Y-m-d H:i', strtotime($booking['start_time'])); ?><br>
                                        <small class="text-muted">to</small><br>
                                        <?php echo date('Y-m-d H:i', strtotime($booking['end_time'])); ?>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php 
                                            echo $booking['status'] === 'active' ? 'success' : 
                                                ($booking['status'] === 'completed' ? 'secondary' : 'danger'); 
                                        ?>">
                                            <?php echo ucfirst($booking['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($booking['payment_amount']): ?>
                                            K<?php echo number_format($booking['payment_amount'], 2); ?><br>
                                            <?php if ($booking['current_penalty'] > 0): ?>
                                                <span class="text-danger">
                                                    Penalty: K<?php echo number_format($booking['current_penalty'], 2); ?>
                                                </span><br>
                                            <?php endif; ?>
                                            <span class="badge bg-<?php 
                                                echo $booking['payment_status'] === 'completed' ? 'success' : 
                                                    ($booking['payment_status'] === 'pending' ? 'warning' : 'danger'); 
                                            ?>">
                                                <?php echo ucfirst($booking['payment_status']); ?>
                                            </span>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo date('Y-m-d H:i', strtotime($booking['created_at'])); ?></td>
                                    <td>
                                        <button type="button" class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#viewBookingModal<?php echo $booking['id']; ?>">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                    </td>
                                </tr>
                                
                                <!-- View Booking Modal -->
                                <div class="modal fade" id="viewBookingModal<?php echo $booking['id']; ?>" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Booking Details #<?php echo $booking['id']; ?></h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <h6>User Information</h6>
                                                <p>
                                                    <strong>Name:</strong> <?php echo htmlspecialchars($booking['user_name']); ?><br>
                                                    <strong>Email:</strong> <?php echo htmlspecialchars($booking['user_email']); ?>
                                                </p>
                                                
                                                <h6>Parking Details</h6>
                                                <p>
                                                    <strong>Slot:</strong> <?php echo htmlspecialchars($booking['slot_number']); ?><br>
                                                    <strong>Floor:</strong> <?php echo htmlspecialchars($booking['floor']); ?><br>
                                                    <strong>Type:</strong> <?php echo ucfirst($booking['slot_type']); ?>
                                                </p>
                                                
                                                <h6>Booking Time</h6>
                                                <p>
                                                    <strong>Start:</strong> <?php echo date('Y-m-d H:i', strtotime($booking['start_time'])); ?><br>
                                                    <strong>End:</strong> <?php echo date('Y-m-d H:i', strtotime($booking['end_time'])); ?>
                                                </p>
                                                
                                                <?php if ($booking['check_in_time']): ?>
                                                    <h6>Check-in/out Time</h6>
                                                    <p>
                                                        <strong>Check-in:</strong> <?php echo date('Y-m-d H:i', strtotime($booking['check_in_time'])); ?><br>
                                                        <?php if ($booking['check_out_time']): ?>
                                                            <strong>Check-out:</strong> <?php echo date('Y-m-d H:i', strtotime($booking['check_out_time'])); ?>
                                                        <?php endif; ?>
                                                    </p>
                                                <?php endif; ?>
                                                
                                                <?php if ($booking['payment_amount']): ?>
                                                    <h6>Payment Information</h6>
                                                    <p>
                                                        <strong>Amount:</strong> K<?php echo number_format($booking['payment_amount'], 2); ?><br>
                                                        <?php if ($booking['current_penalty'] > 0): ?>
                                                            <strong class="text-danger">Penalty Amount:</strong> K<?php echo number_format($booking['current_penalty'], 2); ?><br>
                                                            <strong class="text-danger">Total Due:</strong> K<?php echo number_format($booking['payment_amount'] + $booking['current_penalty'], 2); ?><br>
                                                        <?php endif; ?>
                                                        <strong>Method:</strong> <?php echo ucfirst($booking['payment_method']); ?><br>
                                                        <strong>Status:</strong> <?php echo ucfirst($booking['payment_status']); ?>
                                                    </p>
                                                <?php endif; ?>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
</body>
</html> 