<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';

// Check if user is logged in and is admin
if (!$auth->isLoggedIn() || !$auth->isAdmin()) {
    header('Location: ../login.php');
    exit();
}

$error = '';
$success = '';

// Default settings
$settings = [
    'maintenance_mode' => '0',
    'currency' => 'K',
    'notification_email' => '',
    'notification_phone' => ''
];

// Handle settings update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'update_settings') {
        try {
            // Update settings in session
            $_SESSION['settings'] = [
                'maintenance_mode' => isset($_POST['maintenance_mode']) ? '1' : '0',
                'currency' => $_POST['currency'] ?? 'K',
                'notification_email' => $_POST['notification_email'] ?? '',
                'notification_phone' => $_POST['notification_phone'] ?? ''
            ];
            
            $success = 'Settings updated successfully';
            
        } catch (Exception $e) {
            $error = 'Failed to update settings: ' . $e->getMessage();
        }
    }
            }
            
// Get settings from session or use defaults
$settings = $_SESSION['settings'] ?? $settings;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
    <link href="assets/css/admin.css" rel="stylesheet">
</head>
<body>
    <div class="wrapper">
        <?php include 'includes/admin-nav.php'; ?>
        
        <div class="main-content">
            <div class="container-fluid py-4">
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <div class="row">
                    <div class="col-md-6">
                <div class="card fade-in mb-4">
                    <div class="card-header">
                        <h4>Notification Settings</h4>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                                    <input type="hidden" name="action" value="update_settings">
                            
                            <div class="mb-3">
                                <label for="notification_email" class="form-label">Notification Email</label>
                                <input type="email" class="form-control" id="notification_email" name="notification_email" 
                                               value="<?php echo htmlspecialchars($settings['notification_email']); ?>">
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="notification_phone" class="form-label">Notification Phone</label>
                                        <input type="text" class="form-control" id="notification_phone" name="notification_phone" 
                                               value="<?php echo htmlspecialchars($settings['notification_phone']); ?>">
                            </div>
                            
                            <div class="d-grid">
                                        <button type="submit" class="btn btn-primary">Save Settings</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
                    <div class="col-md-6">
                <div class="card fade-in">
                    <div class="card-header">
                        <h4>System Settings</h4>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                                    <input type="hidden" name="action" value="update_settings">
                            
                            <div class="mb-3">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="maintenance_mode" name="maintenance_mode" 
                                                   <?php echo $settings['maintenance_mode'] == '1' ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="maintenance_mode">Maintenance Mode</label>
                                </div>
                                        <small class="text-muted">When enabled, only administrators can access the system.</small>
                                    </div>
                                    
                                    <?php if ($settings['maintenance_mode'] == '1'): ?>
                                        <div class="alert alert-warning">
                                            <i class="fas fa-exclamation-triangle"></i>
                                            Maintenance mode is currently enabled. Regular users cannot access the system.
                                        </div>
                                    <?php endif; ?>
                                    
                                    <div class="mb-3">
                                        <label for="currency" class="form-label">Currency Symbol</label>
                                        <input type="text" class="form-control" id="currency" name="currency" 
                                               value="<?php echo htmlspecialchars($settings['currency']); ?>" required>
                            </div>
                            
                            <div class="d-grid">
                                        <button type="submit" class="btn btn-primary">Save Settings</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
</body>
</html> 