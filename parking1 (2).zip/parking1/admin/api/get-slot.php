<?php
require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/auth.php';

// Check if user is logged in and is admin
if (!$auth->isLoggedIn() || !$auth->isAdmin()) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

// Get slot ID from query parameter
$id = $_GET['id'] ?? 0;

if (empty($id)) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Slot ID is required']);
    exit();
}

try {
    // Get slot details
    $stmt = $db->prepare("SELECT * FROM parking_slots WHERE id = ?");
    $stmt->execute([$id]);
    $slot = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$slot) {
        throw new Exception('Slot not found');
    }
    
    header('Content-Type: application/json');
    echo json_encode(['success' => true, 'data' => $slot]);
} catch (Exception $e) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} 