<?php
require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/auth.php';

// Check if user is logged in and is admin
if (!$auth->isLoggedIn() || !$auth->isAdmin()) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

// Get POST data
$id = $_POST['id'] ?? 0;
$slot_number = $_POST['slot_number'] ?? '';
$floor = $_POST['floor'] ?? '';
$type = $_POST['type'] ?? '';
$status = $_POST['status'] ?? '';
$x_coordinate = $_POST['x_coordinate'] ?? 0;
$y_coordinate = $_POST['y_coordinate'] ?? 0;

// Validate input
if (empty($id) || empty($slot_number) || empty($floor) || empty($type) || empty($status)) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Please fill in all required fields']);
    exit();
}

try {
    // Start transaction
    $db->beginTransaction();
    
    // Check if slot exists
    $stmt = $db->prepare("SELECT id FROM parking_slots WHERE id = ?");
    $stmt->execute([$id]);
    if (!$stmt->fetch()) {
        throw new Exception('Slot not found');
    }
    
    // Check if slot number is unique for this floor
    $stmt = $db->prepare("SELECT id FROM parking_slots WHERE slot_number = ? AND floor = ? AND id != ?");
    $stmt->execute([$slot_number, $floor, $id]);
    if ($stmt->fetch()) {
        throw new Exception('Slot number already exists on this floor');
    }
    
    // Update slot
    $stmt = $db->prepare("
        UPDATE parking_slots 
        SET slot_number = ?, floor = ?, type = ?, status = ?, x_coordinate = ?, y_coordinate = ? 
        WHERE id = ?
    ");
    $stmt->execute([$slot_number, $floor, $type, $status, $x_coordinate, $y_coordinate, $id]);
    
    $db->commit();
    
    header('Content-Type: application/json');
    echo json_encode(['success' => true, 'message' => 'Slot updated successfully']);
} catch (Exception $e) {
    $db->rollBack();
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} 