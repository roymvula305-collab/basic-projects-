<?php
require_once '../../includes/config.php';
require_once '../../includes/db.php';
require_once '../../includes/auth.php';

// Check if user is logged in and is admin
if (!$auth->isLoggedIn() || !$auth->isAdmin()) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

// Get POST data
$slot_id = $_POST['slot_id'] ?? 0;
$start_time = $_POST['start_time'] ?? '';
$end_time = $_POST['end_time'] ?? '';
$reason = $_POST['reason'] ?? '';

// Validate input
if (empty($slot_id) || empty($start_time) || empty($end_time) || empty($reason)) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Please fill in all fields']);
    exit();
}

try {
    // Start transaction
    $db->beginTransaction();
    
    // Check if slot is available
    $stmt = $db->prepare("SELECT status FROM parking_slots WHERE id = ?");
    $stmt->execute([$slot_id]);
    $slot = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$slot) {
        throw new Exception('Slot not found');
    }
    
    if ($slot['status'] !== 'available') {
        throw new Exception('Slot is not available for maintenance');
    }
    
    // Check for overlapping maintenance schedules
    $stmt = $db->prepare("
        SELECT COUNT(*) 
        FROM maintenance_schedule 
        WHERE slot_id = ? 
        AND (
            (start_time BETWEEN ? AND ?)
            OR (end_time BETWEEN ? AND ?)
            OR (? BETWEEN start_time AND end_time)
            OR (? BETWEEN start_time AND end_time)
        )
    ");
    $stmt->execute([$slot_id, $start_time, $end_time, $start_time, $end_time, $start_time, $end_time]);
    
    if ($stmt->fetchColumn() > 0) {
        throw new Exception('There is already a maintenance schedule for this slot during the specified time');
    }
    
    // Insert maintenance schedule
    $stmt = $db->prepare("
        INSERT INTO maintenance_schedule (slot_id, start_time, end_time, reason, status) 
        VALUES (?, ?, ?, ?, 'scheduled')
    ");
    $stmt->execute([$slot_id, $start_time, $end_time, $reason]);
    
    // Update slot status
    $stmt = $db->prepare("UPDATE parking_slots SET status = 'maintenance' WHERE id = ?");
    $stmt->execute([$slot_id]);
    
    $db->commit();
    
    header('Content-Type: application/json');
    echo json_encode(['success' => true, 'message' => 'Maintenance scheduled successfully']);
} catch (Exception $e) {
    $db->rollBack();
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} 