<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';

// Check if user is logged in and is admin
if (!$auth->isLoggedIn() || !$auth->isAdmin()) {
    header('Location: ../login.php');
    exit();
}

$error = '';
$success = '';

// Handle actions
if (isset($_GET['action'])) {
    switch ($_GET['action']) {
        case 'add_slot':
            $slot_number = $_POST['slot_number'] ?? '';
            $floor = $_POST['floor'] ?? '';
            $type = $_POST['type'] ?? '';
            $x_coordinate = $_POST['x_coordinate'] ?? 0;
            $y_coordinate = $_POST['y_coordinate'] ?? 0;
            
            if (empty($slot_number) || empty($floor) || empty($type)) {
                $error = 'Please fill in all required fields';
            } else {
                try {
                    $stmt = $db->prepare("INSERT INTO parking_slots (slot_number, floor, type, x_coordinate, y_coordinate) VALUES (?, ?, ?, ?, ?)");
                    $stmt->execute([$slot_number, $floor, $type, $x_coordinate, $y_coordinate]);
                    $success = 'Slot added successfully';
                    header('Location: manage-slots.php?success=1');
                    exit();
                } catch (PDOException $e) {
                    $error = 'Failed to add slot: ' . $e->getMessage();
                }
            }
            break;
            
        case 'edit_slot':
            $id = $_POST['id'] ?? 0;
            $slot_number = $_POST['slot_number'] ?? '';
            $floor = $_POST['floor'] ?? '';
            $type = $_POST['type'] ?? '';
            $status = $_POST['status'] ?? '';
            $x_coordinate = $_POST['x_coordinate'] ?? 0;
            $y_coordinate = $_POST['y_coordinate'] ?? 0;
            
            if (empty($slot_number) || empty($floor) || empty($type) || empty($status)) {
                $error = 'Please fill in all required fields';
            } else {
                try {
                    $stmt = $db->prepare("UPDATE parking_slots SET slot_number = ?, floor = ?, type = ?, status = ?, x_coordinate = ?, y_coordinate = ? WHERE id = ?");
                    $stmt->execute([$slot_number, $floor, $type, $status, $x_coordinate, $y_coordinate, $id]);
                    $success = 'Slot updated successfully';
                    header('Location: manage-slots.php?success=2');
                    exit();
                } catch (PDOException $e) {
                    $error = 'Failed to update slot: ' . $e->getMessage();
                }
            }
            break;
            
        case 'delete_slot':
            $id = $_GET['id'] ?? 0;
            if ($id) {
                try {
                    $stmt = $db->prepare("DELETE FROM parking_slots WHERE id = ?");
                    $stmt->execute([$id]);
                    $success = 'Slot deleted successfully';
                    header('Location: manage-slots.php?success=3');
                    exit();
                } catch (PDOException $e) {
                    $error = 'Failed to delete slot: ' . $e->getMessage();
                }
            }
            break;
        
        case 'add_floor':
            $floor_number = $_POST['floor_number'] ?? '';
            $floor_name = $_POST['floor_name'] ?? '';
            
            if (empty($floor_number)) {
                $error = 'Please enter a floor number';
            } else {
                try {
                    // Check if floor already exists
                    $stmt = $db->prepare("SELECT COUNT(*) FROM parking_slots WHERE floor = ?");
                    $stmt->execute([$floor_number]);
                    if ($stmt->fetchColumn() > 0) {
                        $error = 'Floor already exists';
                    } else {
                        // Start transaction
                        $db->beginTransaction();
                        
                        // Create initial slots for the floor
                        $stmt = $db->prepare("INSERT INTO parking_slots (slot_number, floor, type, status, x_coordinate, y_coordinate) VALUES (?, ?, ?, 'available', ?, ?)");
                        
                        // Create 10 regular slots
                        for ($i = 1; $i <= 10; $i++) {
                            $slot_number = $floor_number . str_pad($i, 2, '0', STR_PAD_LEFT);
                            $stmt->execute([$slot_number, $floor_number, 'regular', $i, 0]);
                        }
                        
                        // Create 2 handicap slots
                        for ($i = 11; $i <= 12; $i++) {
                            $slot_number = $floor_number . str_pad($i, 2, '0', STR_PAD_LEFT);
                            $stmt->execute([$slot_number, $floor_number, 'handicap', $i, 0]);
                        }
                        
                        // Create 2 electric slots
                        for ($i = 13; $i <= 14; $i++) {
                            $slot_number = $floor_number . str_pad($i, 2, '0', STR_PAD_LEFT);
                            $stmt->execute([$slot_number, $floor_number, 'electric', $i, 0]);
                        }
                        
                        $db->commit();
                        $success = "Floor $floor_number added successfully with 14 initial slots";
                        header('Location: manage-slots.php?success=5');
                        exit();
                    }
                } catch (PDOException $e) {
                    $db->rollBack();
                    $error = 'Failed to add floor: ' . $e->getMessage();
                }
            }
            break;
        
        case 'bulk_add_slots':
            $floor = $_POST['floor'] ?? '';
            $start_slot = $_POST['start_slot'] ?? '';
            $slot_count = $_POST['slot_count'] ?? 0;
            $type = $_POST['type'] ?? '';
            
            if (empty($floor) || empty($start_slot) || empty($type) || $slot_count < 1) {
                $error = 'Please fill in all required fields';
            } else {
                try {
                    $db->beginTransaction();
                    
                    // Get the last x_coordinate for this floor
                    $stmt = $db->prepare("SELECT MAX(x_coordinate) FROM parking_slots WHERE floor = ?");
                    $stmt->execute([$floor]);
                    $last_x = $stmt->fetchColumn() ?? 0;
                    
                    // Create slots
                    $stmt = $db->prepare("INSERT INTO parking_slots (slot_number, floor, type, status, x_coordinate, y_coordinate) VALUES (?, ?, ?, 'available', ?, 0)");
                    
                    for ($i = 0; $i < $slot_count; $i++) {
                        $slot_number = $start_slot . str_pad($i + 1, 2, '0', STR_PAD_LEFT);
                        $x_coordinate = $last_x + $i + 1;
                        $stmt->execute([$slot_number, $floor, $type, $x_coordinate]);
                    }
                    
                    $db->commit();
                    $success = "Successfully created $slot_count slots";
                    header('Location: manage-slots.php?success=4');
                    exit();
                } catch (PDOException $e) {
                    $db->rollBack();
                    $error = 'Failed to create slots: ' . $e->getMessage();
                }
            }
            break;
    }
}

// Get all slots
$stmt = $db->query("SELECT * FROM parking_slots ORDER BY floor, x_coordinate, y_coordinate");
$slots = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get slot statistics
$stmt = $db->prepare("
    SELECT 
        COUNT(*) as total_slots,
        SUM(CASE WHEN status = 'available' THEN 1 ELSE 0 END) as available_slots,
        SUM(CASE WHEN status = 'occupied' THEN 1 ELSE 0 END) as occupied_slots,
        SUM(CASE WHEN status = 'maintenance' THEN 1 ELSE 0 END) as maintenance_slots,
        SUM(CASE WHEN type = 'regular' THEN 1 ELSE 0 END) as regular_slots,
        SUM(CASE WHEN type = 'regular' AND status = 'available' THEN 1 ELSE 0 END) as regular_available,
        SUM(CASE WHEN type = 'handicap' THEN 1 ELSE 0 END) as handicap_slots,
        SUM(CASE WHEN type = 'handicap' AND status = 'available' THEN 1 ELSE 0 END) as handicap_available,
        SUM(CASE WHEN type = 'electric' THEN 1 ELSE 0 END) as electric_slots,
        SUM(CASE WHEN type = 'electric' AND status = 'available' THEN 1 ELSE 0 END) as electric_available
    FROM parking_slots
");
$stmt->execute();
$stats = $stmt->fetch(PDO::FETCH_ASSOC);

// Get floor statistics
$stmt = $db->prepare("
    SELECT 
        floor,
        COUNT(*) as total_slots,
        SUM(CASE WHEN status = 'available' THEN 1 ELSE 0 END) as available_slots,
        SUM(CASE WHEN status = 'occupied' THEN 1 ELSE 0 END) as occupied_slots,
        SUM(CASE WHEN status = 'maintenance' THEN 1 ELSE 0 END) as maintenance_slots,
        SUM(CASE WHEN type = 'regular' THEN 1 ELSE 0 END) as regular_slots,
        SUM(CASE WHEN type = 'handicap' THEN 1 ELSE 0 END) as handicap_slots,
        SUM(CASE WHEN type = 'electric' THEN 1 ELSE 0 END) as electric_slots
    FROM parking_slots
    GROUP BY floor
    ORDER BY floor
");
$stmt->execute();
$floor_stats = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get slot utilization history
$stmt = $db->prepare("
    SELECT 
        DATE(created_at) as date,
        COUNT(*) as total_bookings,
        AVG(TIMESTAMPDIFF(HOUR, start_time, end_time)) as avg_duration,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_bookings,
        SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled_bookings
    FROM bookings
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    GROUP BY DATE(created_at)
    ORDER BY date
");
$stmt->execute();
$utilization_history = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get maintenance schedule
$stmt = $db->prepare("
    SELECT 
        ms.*,
        ps.slot_number,
        ps.floor,
        ps.type
    FROM maintenance_schedule ms
    JOIN parking_slots ps ON ms.slot_id = ps.id
    WHERE ms.end_time >= NOW()
    ORDER BY ms.start_time
");
$stmt->execute();
$maintenance_schedule = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Parking Slots - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
    <link href="assets/css/admin.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js"></script>
</head>
<body>
    <div class="wrapper">
        <?php include 'includes/admin-nav.php'; ?>
        
        <div class="main-content">
            <div class="container-fluid py-4">
                <!-- Statistics Cards -->
                <div class="row mb-4">
                    <div class="col-md-4">
                        <div class="card stat-card bg-primary text-white">
                            <div class="card-body">
                                <h5 class="card-title">Regular Slots</h5>
                                <h2><?php echo $stats['regular_slots']; ?></h2>
                                <div class="stat-details">
                                    <span>Available: <?php echo $stats['regular_available']; ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card stat-card bg-success text-white">
                            <div class="card-body">
                                <h5 class="card-title">Handicap Slots</h5>
                                <h2><?php echo $stats['handicap_slots']; ?></h2>
                                <div class="stat-details">
                                    <span>Available: <?php echo $stats['handicap_available']; ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card stat-card bg-info text-white">
                            <div class="card-body">
                                <h5 class="card-title">Electric Slots</h5>
                                <h2><?php echo $stats['electric_slots']; ?></h2>
                                <div class="stat-details">
                                    <span>Available: <?php echo $stats['electric_available']; ?></span>
                                </div>
                            </div>
                        </div>
            </div>
        </div>

                <!-- Overall Statistics -->
                <div class="row mb-4">
                    <div class="col-md-3">
                        <div class="card stat-card bg-secondary text-white">
                            <div class="card-body">
                                <h5 class="card-title">Total Slots</h5>
                                <h2><?php echo $stats['total_slots']; ?></h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card stat-card bg-success text-white">
                            <div class="card-body">
                                <h5 class="card-title">Available</h5>
                                <h2><?php echo $stats['available_slots']; ?></h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card stat-card bg-warning text-white">
                            <div class="card-body">
                                <h5 class="card-title">Occupied</h5>
                                <h2><?php echo $stats['occupied_slots']; ?></h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card stat-card bg-danger text-white">
                            <div class="card-body">
                                <h5 class="card-title">Maintenance</h5>
                                <h2><?php echo $stats['maintenance_slots']; ?></h2>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Slot Utilization Chart -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5>Slot Utilization Overview</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="utilizationChart"></canvas>
                    </div>
                </div>

                <!-- Floor Maps -->
                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5>Floor Maps</h5>
                        <div class="btn-group">
                            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addFloorModal">
                                <i class="fas fa-plus"></i> Add Floor
                            </button>
                            <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#bulkAddModal">
                                <i class="fas fa-layer-group"></i> Bulk Add
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <?php foreach ($floor_stats as $floor): ?>
                                <div class="col-md-6 mb-4">
        <div class="card">
                                        <div class="card-header">
                                            <h6>Floor <?php echo $floor['floor']; ?></h6>
                                        </div>
                                        <div class="card-body">
                                            <div class="floor-map" data-floor="<?php echo $floor['floor']; ?>">
                                                <!-- Floor map will be rendered here -->
                                            </div>
                                            <div class="mt-3">
                                                <div class="row">
                                                    <div class="col-6">
                                                        <small class="text-muted">Total: <?php echo $floor['total_slots']; ?></small>
                                                    </div>
                                                    <div class="col-6">
                                                        <small class="text-muted">Available: <?php echo $floor['available_slots']; ?></small>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <!-- Maintenance Schedule -->
                <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                        <h5>Maintenance Schedule</h5>
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addMaintenanceModal">
                            <i class="fas fa-plus"></i> Schedule Maintenance
                </button>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                        <th>Slot</th>
                                        <th>Type</th>
                                        <th>Start Time</th>
                                        <th>End Time</th>
                                        <th>Reason</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($maintenance_schedule as $maintenance): ?>
                                        <tr>
                                            <td>Floor <?php echo $maintenance['floor']; ?> - <?php echo $maintenance['slot_number']; ?></td>
                                            <td><?php echo ucfirst($maintenance['type']); ?></td>
                                            <td><?php echo date('Y-m-d H:i', strtotime($maintenance['start_time'])); ?></td>
                                            <td><?php echo date('Y-m-d H:i', strtotime($maintenance['end_time'])); ?></td>
                                            <td><?php echo htmlspecialchars($maintenance['reason']); ?></td>
                                            <td>
                                                <span class="badge bg-<?php 
                                                    echo match($maintenance['status']) {
                                                        'scheduled' => 'warning',
                                                        'in_progress' => 'info',
                                                        'completed' => 'success',
                                                        'cancelled' => 'danger',
                                                        default => 'secondary'
                                                    };
                                                ?>">
                                                    <?php echo ucfirst($maintenance['status']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <button class="btn btn-sm btn-info edit-maintenance" data-id="<?php echo $maintenance['id']; ?>">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <button class="btn btn-sm btn-danger delete-maintenance" data-id="<?php echo $maintenance['id']; ?>">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Slot List -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5>All Parking Slots</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                <th>Slot Number</th>
                                <th>Floor</th>
                                <th>Type</th>
                                <th>Status</th>
                                        <th>Coordinates</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($slots as $slot): ?>
                                <tr>
                                            <td><?php echo $slot['id']; ?></td>
                                            <td><?php echo $slot['slot_number']; ?></td>
                                            <td><?php echo $slot['floor']; ?></td>
                                            <td>
                                                <span class="badge bg-<?php 
                                                    echo match($slot['type']) {
                                                        'regular' => 'primary',
                                                        'handicap' => 'success',
                                                        'electric' => 'warning',
                                                        default => 'secondary'
                                                    };
                                                ?>">
                                                    <?php echo ucfirst($slot['type']); ?>
                                                </span>
                                            </td>
                                    <td>
                                        <span class="badge bg-<?php 
                                                    echo match($slot['status']) {
                                                        'available' => 'success',
                                                        'occupied' => 'danger',
                                                        'maintenance' => 'warning',
                                                        default => 'secondary'
                                                    };
                                        ?>">
                                            <?php echo ucfirst($slot['status']); ?>
                                        </span>
                                    </td>
                                    <td>(<?php echo $slot['x_coordinate']; ?>, <?php echo $slot['y_coordinate']; ?>)</td>
                                    <td>
                                                <button class="btn btn-sm btn-info edit-slot" data-id="<?php echo $slot['id']; ?>">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                                <button class="btn btn-sm btn-danger delete-slot" data-id="<?php echo $slot['id']; ?>">
                                            <i class="fas fa-trash"></i>
                                                </button>
                                    </td>
                                </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Floor Modal -->
    <div class="modal fade" id="addFloorModal" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                    <h5 class="modal-title">Add New Floor</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                                <div class="modal-body">
                    <form id="addFloorForm">
                                                    <div class="mb-3">
                            <label class="form-label">Floor Number</label>
                            <input type="number" class="form-control" name="floor_number" required>
                                                    </div>
                                                    <div class="mb-3">
                            <label class="form-label">Floor Name</label>
                            <input type="text" class="form-control" name="floor_name">
                                                    </div>
                    </form>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" id="saveFloor">Save</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Bulk Add Modal -->
    <div class="modal fade" id="bulkAddModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Bulk Add Slots</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                    <div class="modal-body">
                    <form id="bulkAddForm">
                        <div class="mb-3">
                            <label class="form-label">Floor</label>
                            <select class="form-select" name="floor" required>
                                <?php foreach ($floor_stats as $floor): ?>
                                    <option value="<?php echo $floor['floor']; ?>">Floor <?php echo $floor['floor']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Start Slot Number</label>
                            <input type="text" class="form-control" name="start_slot" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Number of Slots</label>
                            <input type="number" class="form-control" name="slot_count" required min="1">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Slot Type</label>
                            <select class="form-select" name="type" required>
                                <option value="regular">Regular</option>
                                <option value="handicap">Handicap</option>
                                <option value="electric">Electric</option>
                            </select>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" id="saveBulk">Save</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Maintenance Modal -->
    <div class="modal fade" id="addMaintenanceModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Schedule Maintenance</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="addMaintenanceForm">
                        <div class="mb-3">
                            <label class="form-label">Slot</label>
                            <select class="form-select" name="slot_id" required>
                                <?php foreach ($slots as $slot): ?>
                                    <option value="<?php echo $slot['id']; ?>">
                                        Floor <?php echo $slot['floor']; ?> - <?php echo $slot['slot_number']; ?>
                                        (<?php echo ucfirst($slot['type']); ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Start Time</label>
                            <input type="datetime-local" class="form-control" name="start_time" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">End Time</label>
                            <input type="datetime-local" class="form-control" name="end_time" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Reason</label>
                            <textarea class="form-control" name="reason" required></textarea>
                        </div>
                    </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" id="saveMaintenance">Save</button>
                    </div>
            </div>
        </div>
    </div>

    <!-- Edit Slot Modal -->
    <div class="modal fade" id="editSlotModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Parking Slot</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="editSlotForm">
                        <input type="hidden" id="editSlotId" name="id">
                        <div class="mb-3">
                            <label class="form-label">Slot Number</label>
                            <input type="text" class="form-control" id="editSlotNumber" name="slot_number" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Floor</label>
                            <input type="text" class="form-control" id="editFloor" name="floor" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Type</label>
                            <select class="form-select" id="editType" name="type" required>
                                <option value="regular">Regular</option>
                                <option value="handicap">Handicap</option>
                                <option value="electric">Electric</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Status</label>
                            <select class="form-select" id="editStatus" name="status" required>
                                <option value="available">Available</option>
                                <option value="occupied">Occupied</option>
                                <option value="maintenance">Maintenance</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">X Coordinate</label>
                            <input type="number" class="form-control" id="editXCoordinate" name="x_coordinate" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Y Coordinate</label>
                            <input type="number" class="form-control" id="editYCoordinate" name="y_coordinate" required>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" id="saveEditSlot">Save Changes</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Slot Utilization Chart
        new Chart(document.getElementById('utilizationChart'), {
            type: 'line',
            data: {
                labels: <?php echo json_encode(array_column($utilization_history, 'date')); ?>,
                datasets: [{
                    label: 'Total Bookings',
                    data: <?php echo json_encode(array_column($utilization_history, 'total_bookings')); ?>,
                    borderColor: '#3498db',
                    tension: 0.1
                }, {
                    label: 'Completed',
                    data: <?php echo json_encode(array_column($utilization_history, 'completed_bookings')); ?>,
                    borderColor: '#2ecc71',
                    tension: 0.1
                }, {
                    label: 'Cancelled',
                    data: <?php echo json_encode(array_column($utilization_history, 'cancelled_bookings')); ?>,
                    borderColor: '#e74c3c',
                    tension: 0.1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    }
                }
            }
        });

        // Initialize floor maps
        document.querySelectorAll('.floor-map').forEach(map => {
            const floor = map.dataset.floor;
            // Implement floor map visualization
            // This would typically use a canvas or SVG to draw the parking layout
        });

        // Slot Management Actions
        document.querySelectorAll('.edit-slot').forEach(button => {
            button.addEventListener('click', function() {
                const slotId = this.dataset.id;
                // Get slot details
                fetch(`api/get-slot.php?id=${slotId}`)
                    .then(response => response.json())
                    .then(slot => {
                        if (slot.success) {
                            // Populate edit form
                            document.getElementById('editSlotId').value = slot.data.id;
                            document.getElementById('editSlotNumber').value = slot.data.slot_number;
                            document.getElementById('editFloor').value = slot.data.floor;
                            document.getElementById('editType').value = slot.data.type;
                            document.getElementById('editStatus').value = slot.data.status;
                            document.getElementById('editXCoordinate').value = slot.data.x_coordinate;
                            document.getElementById('editYCoordinate').value = slot.data.y_coordinate;
                            
                            // Show edit modal
                            new bootstrap.Modal(document.getElementById('editSlotModal')).show();
                        } else {
                            alert(slot.message);
                        }
                    });
            });
        });

        document.querySelectorAll('.delete-slot').forEach(button => {
            button.addEventListener('click', function() {
                const slotId = this.dataset.id;
                if (confirm('Are you sure you want to delete this slot?')) {
                    // Implement delete slot
                }
            });
        });

        // Maintenance Actions
        document.querySelectorAll('.edit-maintenance').forEach(button => {
            button.addEventListener('click', function() {
                const maintenanceId = this.dataset.id;
                // Implement edit maintenance
            });
        });

        document.querySelectorAll('.delete-maintenance').forEach(button => {
            button.addEventListener('click', function() {
                const maintenanceId = this.dataset.id;
                if (confirm('Are you sure you want to delete this maintenance schedule?')) {
                    // Implement delete maintenance
                }
            });
        });

        // Save new floor
        document.getElementById('saveFloor').addEventListener('click', function() {
            const form = document.getElementById('addFloorForm');
            const formData = new FormData(form);
            
            fetch('api/add-floor.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert(data.message);
                }
            });
        });

        // Save bulk slots
        document.getElementById('saveBulk').addEventListener('click', function() {
            const form = document.getElementById('bulkAddForm');
            const formData = new FormData(form);
            
            fetch('api/bulk-add-slots.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert(data.message);
                }
            });
        });

        // Save maintenance
        document.getElementById('saveMaintenance').addEventListener('click', function() {
            const form = document.getElementById('addMaintenanceForm');
            const formData = new FormData(form);
            
            fetch('api/add-maintenance.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert(data.message);
                }
            });
        });

        // Save edited slot
        document.getElementById('saveEditSlot').addEventListener('click', function() {
            const form = document.getElementById('editSlotForm');
            const formData = new FormData(form);
            
            fetch('api/edit-slot.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert(data.message);
                }
            });
        });
    });
    </script>
</body>
</html> 