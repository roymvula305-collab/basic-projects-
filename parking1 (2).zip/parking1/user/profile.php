<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';

// Check if user is logged in
if (!$auth->isLoggedIn()) {
    header('Location: ../login.php');
    exit();
}

$error = '';
$success = '';
$action = $_POST['action'] ?? '';

// Get user data
$stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Get user's vehicles
$stmt = $db->prepare("SELECT * FROM vehicles WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$vehicles = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get user's booking count
$stmt = $db->prepare("SELECT COUNT(*) as booking_count FROM bookings WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$booking_count = $stmt->fetch(PDO::FETCH_ASSOC)['booking_count'];

// Get recent activities
$stmt = $db->prepare("
    (SELECT 
        'booking' as type,
        b.check_in_time as activity_time,
        CONCAT('Booked parking slot #', ps.slot_number) as description
    FROM bookings b
    JOIN parking_slots ps ON b.slot_id = ps.id
    WHERE b.user_id = ?)
    UNION ALL
    (SELECT 
        'vehicle' as type,
        created_at as activity_time,
        CONCAT('Added new vehicle (', vehicle_model, ')') as description
    FROM vehicles 
    WHERE user_id = ?)
    UNION ALL
    (SELECT 
        'profile' as type,
        created_at as activity_time,
        'Updated profile information' as description
    FROM users 
    WHERE id = ?)
    ORDER BY activity_time DESC
    LIMIT 5
");
$stmt->execute([$_SESSION['user_id'], $_SESSION['user_id'], $_SESSION['user_id']]);
$activities = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Format activity dates
foreach ($activities as &$activity) {
    $activity['formatted_time'] = date('M d, Y H:i', strtotime($activity['activity_time']));
}
unset($activity); // Break the reference

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($action === 'update_profile') {
        $name = $_POST['name'] ?? '';
        $email = $_POST['email'] ?? '';
        $nrc_passport = $_POST['nrc_passport'] ?? '';
        $phone = $_POST['phone'] ?? '';
        $city = $_POST['city'] ?? '';
        $country = $_POST['country'] ?? '';
        $current_password = $_POST['current_password'] ?? '';
        $new_password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        
        // Handle profile picture upload
        $profile_picture = $user['profile_picture']; // Keep existing picture by default
        if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
            $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
            $max_size = 5 * 1024 * 1024; // 5MB
            
            if (!in_array($_FILES['profile_picture']['type'], $allowed_types)) {
                $error = "Invalid file type. Only JPEG, PNG, and GIF are allowed.";
            } elseif ($_FILES['profile_picture']['size'] > $max_size) {
                $error = "File is too large. Maximum size is 5MB.";
            } else {
                $upload_dir = '../uploads/profile_pictures/';
                if (!file_exists($upload_dir)) {
                    mkdir($upload_dir, 0777, true);
                }
                
                $file_extension = pathinfo($_FILES['profile_picture']['name'], PATHINFO_EXTENSION);
                $new_filename = uniqid('profile_') . '.' . $file_extension;
                $upload_path = $upload_dir . $new_filename;
                
                if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $upload_path)) {
                    // Delete old profile picture if exists
                    if (!empty($user['profile_picture']) && file_exists('../' . $user['profile_picture'])) {
                        unlink('../' . $user['profile_picture']);
                    }
                    $profile_picture = 'uploads/profile_pictures/' . $new_filename;
                } else {
                    $error = "Failed to upload profile picture.";
                }
            }
        }
        
        // Validate required fields
        if (empty($name) || empty($email) || empty($nrc_passport) || empty($phone) || empty($city) || empty($country)) {
            $error = "All fields are required.";
        } else {
            // Check if email is already taken by another user
            $stmt = $db->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
            $stmt->execute([$email, $_SESSION['user_id']]);
            if ($stmt->rowCount() > 0) {
                $error = "Email is already taken by another user.";
            } else {
                // Check if NRC/Passport is already taken by another user
                $stmt = $db->prepare("SELECT id FROM users WHERE nrc_passport = ? AND id != ?");
                $stmt->execute([$nrc_passport, $_SESSION['user_id']]);
                if ($stmt->rowCount() > 0) {
                    $error = "NRC/Passport number is already registered by another user.";
                } else {
                    // Check if phone is already taken by another user
                    $stmt = $db->prepare("SELECT id FROM users WHERE phone = ? AND id != ?");
                    $stmt->execute([$phone, $_SESSION['user_id']]);
                    if ($stmt->rowCount() > 0) {
                        $error = "Phone number is already registered by another user.";
                    } else {
                        // If changing password, verify current password
                        if (!empty($new_password)) {
                            if (empty($current_password)) {
                                $error = "Current password is required to change password.";
                            } else {
                                // Verify current password
                                $stmt = $db->prepare("SELECT password FROM users WHERE id = ?");
                                $stmt->execute([$_SESSION['user_id']]);
                                $result = $stmt->fetch(PDO::FETCH_ASSOC);
                                
                                if (!password_verify($current_password, $result['password'])) {
                                    $error = "Current password is incorrect.";
                                } else if ($new_password !== $confirm_password) {
                                    $error = "New passwords do not match.";
                                } else {
                                    // Update with new password
                                    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                                    $stmt = $db->prepare("UPDATE users SET name = ?, email = ?, nrc_passport = ?, phone = ?, city = ?, country = ?, password = ?, profile_picture = ? WHERE id = ?");
                                    $stmt->execute([$name, $email, $nrc_passport, $phone, $city, $country, $hashed_password, $profile_picture, $_SESSION['user_id']]);
                                }
                            }
                        } else {
                            // Update without changing password
                            $stmt = $db->prepare("UPDATE users SET name = ?, email = ?, nrc_passport = ?, phone = ?, city = ?, country = ?, profile_picture = ? WHERE id = ?");
                            if ($stmt->execute([$name, $email, $nrc_passport, $phone, $city, $country, $profile_picture, $_SESSION['user_id']])) {
                                $success = "Profile updated successfully.";
            // Refresh user data
            $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
                            } else {
                                $error = "Failed to update profile. Please try again.";
                            }
                        }
                    }
                }
            }
        }
    } elseif ($action === 'add_vehicle') {
        $vehicle_number = $_POST['vehicle_number'] ?? '';
        $vehicle_type = $_POST['vehicle_type'] ?? '';
        $vehicle_model = $_POST['vehicle_model'] ?? '';
        $vehicle_color = $_POST['vehicle_color'] ?? '';
        
        try {
            // Check if vehicle number already exists
            $stmt = $db->prepare("SELECT id FROM vehicles WHERE vehicle_number = ?");
            $stmt->execute([$vehicle_number]);
            if ($stmt->rowCount() > 0) {
                throw new Exception('Vehicle number already registered');
            }
            
            // Add new vehicle
            $stmt = $db->prepare("
                INSERT INTO vehicles (user_id, vehicle_number, vehicle_type, vehicle_model, vehicle_color)
                VALUES (?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $_SESSION['user_id'],
                $vehicle_number,
                $vehicle_type,
                $vehicle_model,
                $vehicle_color
            ]);
            
            $success = 'Vehicle added successfully';
            
            // Refresh vehicles list
            $stmt = $db->prepare("SELECT * FROM vehicles WHERE user_id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            $vehicles = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
        } catch (Exception $e) {
            $error = $e->getMessage();
        }
    } elseif ($action === 'delete_vehicle') {
        $vehicle_id = $_POST['vehicle_id'] ?? 0;
        
        try {
            // Verify vehicle belongs to user
            $stmt = $db->prepare("SELECT id FROM vehicles WHERE id = ? AND user_id = ?");
            $stmt->execute([$vehicle_id, $_SESSION['user_id']]);
            if ($stmt->rowCount() === 0) {
                throw new Exception('Vehicle not found');
            }
            
            // Delete vehicle
            $stmt = $db->prepare("DELETE FROM vehicles WHERE id = ?");
            $stmt->execute([$vehicle_id]);
            
            $success = 'Vehicle deleted successfully';
            
            // Refresh vehicles list
            $stmt = $db->prepare("SELECT * FROM vehicles WHERE user_id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            $vehicles = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
        } catch (Exception $e) {
            $error = $e->getMessage();
        }
    } elseif ($action === 'update_picture') {
        if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
            $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
            $max_size = 5 * 1024 * 1024; // 5MB
            
            if (!in_array($_FILES['profile_picture']['type'], $allowed_types)) {
                $error = "Invalid file type. Only JPEG, PNG, and GIF are allowed.";
            } elseif ($_FILES['profile_picture']['size'] > $max_size) {
                $error = "File is too large. Maximum size is 5MB.";
            } else {
                $upload_dir = '../uploads/profile_pictures/';
                if (!file_exists($upload_dir)) {
                    mkdir($upload_dir, 0777, true);
                }
                
                $file_extension = pathinfo($_FILES['profile_picture']['name'], PATHINFO_EXTENSION);
                $new_filename = uniqid('profile_') . '.' . $file_extension;
                $upload_path = $upload_dir . $new_filename;
                
                if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $upload_path)) {
                    // Delete old profile picture if exists
                    if (!empty($user['profile_picture']) && file_exists('../' . $user['profile_picture'])) {
                        unlink('../' . $user['profile_picture']);
                    }
                    
                    // Update profile picture in database
                    $profile_picture = 'uploads/profile_pictures/' . $new_filename;
                    $stmt = $db->prepare("UPDATE users SET profile_picture = ? WHERE id = ?");
                    if ($stmt->execute([$profile_picture, $_SESSION['user_id']])) {
                        $success = "Profile picture updated successfully.";
                        // Refresh user data
                        $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
                        $stmt->execute([$_SESSION['user_id']]);
                        $user = $stmt->fetch(PDO::FETCH_ASSOC);
                    } else {
                        $error = "Failed to update profile picture in database.";
                    }
                } else {
                    $error = "Failed to upload profile picture.";
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
        }
        .main-content {
            padding: 2rem 0;
        }
        .card {
            border: none;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            overflow: hidden;
            transition: all 0.3s ease;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(0,0,0,0.15);
        }
        .card-header {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            padding: 1.5rem;
            border-bottom: none;
            position: relative;
            overflow: hidden;
        }
        .card-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0) 100%);
            z-index: 1;
        }
        .card-header h4 {
            margin: 0;
            font-weight: 600;
            position: relative;
            z-index: 2;
        }
        .card-body {
            padding: 2rem;
        }
        .profile-picture-section {
            text-align: center;
            margin-bottom: 1.5rem;
        }
        
        .profile-picture-preview {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            margin: 0 auto;
            position: relative;
            overflow: hidden;
            border: 3px solid #1e3c72;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        
        .profile-picture {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .profile-picture-upload {
            position: absolute;
            bottom: 0;
            right: 0;
            background: #1e3c72;
            color: white;
            width: 32px;
            height: 32px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .profile-picture-upload:hover {
            background: #2a5298;
            transform: scale(1.1);
        }
        
        .profile-picture-upload i {
            font-size: 14px;
        }
        
        .profile-info {
            text-align: center;
            margin-top: 1rem;
        }
        
        .profile-info h4 {
            margin: 0;
            font-size: 1.2rem;
            color: #1e3c72;
        }
        
        .profile-info p {
            margin: 0.5rem 0 0;
            color: #6c757d;
            font-size: 0.9rem;
        }
        .form-control {
            border-radius: 12px;
            padding: 0.9rem 1.2rem;
            border: 2px solid #e9ecef;
            transition: all 0.3s ease;
            font-size: 0.95rem;
        }
        .form-control:focus {
            border-color: #1e3c72;
            box-shadow: 0 0 0 0.2rem rgba(30, 60, 114, 0.15);
        }
        .form-label {
            font-weight: 600;
            color: #495057;
            margin-bottom: 0.5rem;
        }
        .btn-primary {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            border: none;
            padding: 0.8rem 1.5rem;
            border-radius: 12px;
            font-weight: 600;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-size: 0.9rem;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(30, 60, 114, 0.3);
        }
        .alert {
            border-radius: 15px;
            border: none;
            padding: 1.25rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }
        .stats-card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
            border-left: 4px solid #1e3c72;
        }
        .stats-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        .stats-icon {
            font-size: 2rem;
            color: #1e3c72;
            margin-bottom: 15px;
        }
        .stats-value {
            font-size: 1.8rem;
            font-weight: 700;
            color: #1e3c72;
            margin-bottom: 5px;
        }
        .stats-label {
            font-size: 0.9rem;
            color: #6c757d;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .activity-timeline {
            position: relative;
            padding-left: 30px;
        }
        .activity-timeline::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            width: 2px;
            background: #e9ecef;
        }
        .activity-item {
            position: relative;
            padding-bottom: 20px;
        }
        .activity-item::before {
            content: '';
            position: absolute;
            left: -30px;
            top: 0;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: #1e3c72;
            border: 2px solid white;
        }
        .activity-date {
            font-size: 0.8rem;
            color: #6c757d;
            margin-bottom: 5px;
        }
        .activity-text {
            font-size: 0.95rem;
            color: #495057;
        }
        .security-section {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 20px;
            margin-top: 30px;
        }
        .security-icon {
            font-size: 1.5rem;
            color: #1e3c72;
            margin-right: 10px;
        }
        .security-text {
            font-size: 0.9rem;
            color: #6c757d;
        }
        @media (max-width: 768px) {
            .profile-picture-preview {
                width: 150px;
                height: 150px;
            }
            .stats-card {
                margin-bottom: 15px;
            }
        }
    </style>
</head>
<body>
    <?php include '../includes/user-nav.php'; ?>
    
    <div class="main-content">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="card mb-4">
                        <div class="card-body">
                            <div class="profile-picture-section">
                                <form method="POST" action="" enctype="multipart/form-data" id="profile-picture-form">
                                    <input type="hidden" name="action" value="update_picture">
                                    <div class="profile-picture-preview">
                                        <img src="<?php echo !empty($user['profile_picture']) ? '../' . htmlspecialchars($user['profile_picture']) : '../assets/images/default-profile.png'; ?>" 
                                             alt="Profile Picture" 
                                             class="profile-picture">
                                        <label for="profile_picture" class="profile-picture-upload">
                                            <i class="fas fa-camera"></i>
                                        </label>
                                        <input type="file" id="profile_picture" name="profile_picture" accept="image/*" style="display: none;">
            </div>
                                </form>
                                <div class="profile-info">
                                    <h4><?php echo htmlspecialchars($user['name'] ?? ''); ?></h4>
                                    <p>Member since <?php echo date('M Y', strtotime($user['created_at'])); ?></p>
                    </div>
                            </div>
                            <div class="row">
                                <div class="col-6">
                                    <div class="stats-card text-center">
                                        <div class="stats-icon">
                                            <i class="fas fa-car"></i>
                                        </div>
                                        <div class="stats-value"><?php echo count($vehicles); ?></div>
                                        <div class="stats-label">Vehicles</div>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="stats-card text-center">
                                        <div class="stats-icon">
                                            <i class="fas fa-calendar-check"></i>
                            </div>
                                        <div class="stats-value"><?php echo $booking_count; ?></div>
                                        <div class="stats-label">Bookings</div>
                            </div>
                            </div>
                            </div>
                    </div>
                </div>
            </div>
            
                <div class="col-md-8">
                    <div class="card">
                    <div class="card-header">
                            <h4><i class="fas fa-user-edit me-2"></i>Profile Information</h4>
                    </div>
                    <div class="card-body">
                            <?php if ($error): ?>
                                <div class="alert alert-danger">
                                    <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
                                </div>
                            <?php endif; ?>
                            
                            <?php if ($success): ?>
                                <div class="alert alert-success">
                                    <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
                            </div>
                        <?php endif; ?>
                        
                            <form method="POST" action="" enctype="multipart/form-data">
                                <input type="hidden" name="action" value="update_profile">
                                
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label class="form-label">Full Name</label>
                                        <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($user['name'] ?? ''); ?>" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Email</label>
                                        <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($user['email'] ?? ''); ?>" required>
                                    </div>
                                </div>
                                
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label class="form-label">NRC/Passport</label>
                                        <input type="text" name="nrc_passport" class="form-control" value="<?php echo htmlspecialchars($user['nrc_passport'] ?? ''); ?>" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Phone</label>
                                        <input type="tel" name="phone" class="form-control" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>" required>
                                    </div>
                            </div>
                            
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label class="form-label">City</label>
                                        <input type="text" name="city" class="form-control" value="<?php echo htmlspecialchars($user['city'] ?? ''); ?>" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Country</label>
                                        <input type="text" name="country" class="form-control" value="<?php echo htmlspecialchars($user['country'] ?? ''); ?>" required>
                                    </div>
                            </div>
                            
                                <div class="row mb-4">
                                    <div class="col-md-4">
                                        <label class="form-label">Current Password</label>
                                        <input type="password" name="current_password" class="form-control">
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label">New Password</label>
                                        <input type="password" name="new_password" class="form-control">
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label">Confirm Password</label>
                                        <input type="password" name="confirm_password" class="form-control">
                                    </div>
                            </div>
                            
                                <div class="text-end">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-save me-2"></i>Save Changes
                                    </button>
                            </div>
                            </form>
                            
                            <div class="activity-timeline mt-5">
                                <h5 class="mb-4">Recent Activity</h5>
                                <?php if (empty($activities)): ?>
                                    <div class="activity-item">
                                        <div class="activity-text">No recent activities</div>
                                    </div>
                                <?php else: ?>
                                    <?php foreach ($activities as $activity): ?>
                                        <div class="activity-item">
                                            <div class="activity-date"><?php echo $activity['formatted_time']; ?></div>
                                            <div class="activity-text"><?php echo htmlspecialchars($activity['description']); ?></div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const profilePictureInput = document.getElementById('profile_picture');
        const profilePictureForm = document.getElementById('profile-picture-form');
        const profilePicturePreview = document.querySelector('.profile-picture');
        
        profilePictureInput.addEventListener('change', function() {
            if (this.files && this.files[0]) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    profilePicturePreview.src = e.target.result;
                    // Submit the form automatically when a file is selected
                    profilePictureForm.submit();
                }
                
                reader.readAsDataURL(this.files[0]);
            }
        });
    });
    </script>
</body>
</html> 