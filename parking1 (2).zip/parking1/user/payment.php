<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';

// Check if user is logged in
if (!$auth->isLoggedIn()) {
    header('Location: ../login.php');
    exit();
}

$error = '';
$success = '';

// Get booking ID
$booking_id = $_GET['id'] ?? 0;

// Get booking details
$stmt = $db->prepare("
    SELECT b.*, ps.slot_number, ps.floor, ps.type
    FROM bookings b
    JOIN parking_slots ps ON b.slot_id = ps.id
    WHERE b.id = ? AND b.user_id = ? AND b.status = 'pending'
");
$stmt->execute([$booking_id, $_SESSION['user_id']]);
$booking = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$booking) {
    header('Location: my-bookings.php');
    exit();
}

// Calculate duration
$start_time = new DateTime($booking['start_time']);
$end_time = new DateTime($booking['end_time']);
$hours = $end_time->diff($start_time)->h;

// Calculate total amount (assuming K5 per hour)
$total_amount = $hours * 5;

// Handle payment
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $payment_method = $_POST['payment_method'];
    $account_number = $_POST['account_number'];
    $cvv = $_POST['cvv'];
    $expiry_date = $_POST['expiry_date'];
    $phone_number = $_POST['phone_number'];
    
    try {
        // Start transaction
        $db->beginTransaction();
        
        // Insert payment record
        $stmt = $db->prepare("
            INSERT INTO payments (booking_id, amount, payment_method, account_number, cvv, expiry_date, phone_number, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, 'completed')
        ");
        $stmt->execute([$booking_id, $total_amount, $payment_method, $account_number, $cvv, $expiry_date, $phone_number]);
        
        // Update booking status
        $stmt = $db->prepare("
            UPDATE bookings 
            SET status = 'confirmed', 
                payment_id = LAST_INSERT_ID()
            WHERE id = ?
        ");
        $stmt->execute([$booking_id]);
        
        // Update slot status
        $stmt = $db->prepare("
            UPDATE parking_slots 
            SET status = 'occupied' 
            WHERE id = ?
        ");
        $stmt->execute([$booking['slot_id']]);
        
        // Commit transaction
        $db->commit();
        
        header("Location: my-bookings.php?success=1");
        exit();
        
    } catch (Exception $e) {
        // Rollback transaction if it was started
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        $error = "Payment failed: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            overflow: hidden;
            transition: transform 0.3s ease;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .card-header {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            padding: 1.5rem;
            border-bottom: none;
        }
        .card-header h4 {
            margin: 0;
            font-weight: 600;
        }
        .card-body {
            padding: 2rem;
        }
        .payment-method {
            display: none;
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
        }
        .payment-method.active {
            display: block;
            animation: fadeIn 0.3s ease;
        }
        .payment-method:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        .payment-icon {
            font-size: 2rem;
            color: #1e3c72;
            margin-bottom: 15px;
        }
        .payment-details {
            margin-top: 15px;
        }
        .payment-details p {
            margin-bottom: 5px;
            color: #495057;
        }
        .payment-details strong {
            color: #1e3c72;
        }
        .btn-primary {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            border: none;
            padding: 0.8rem 1.5rem;
            border-radius: 10px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(30, 60, 114, 0.3);
        }
        .btn-outline-secondary {
            border-radius: 10px;
            padding: 0.8rem 1.5rem;
            transition: all 0.3s ease;
        }
        .btn-outline-secondary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .alert {
            border-radius: 10px;
            border: none;
        }
        .form-control {
            border-radius: 10px;
            padding: 0.8rem 1rem;
            border: 2px solid #e9ecef;
            transition: all 0.3s ease;
        }
        .form-control:focus {
            border-color: #1e3c72;
            box-shadow: 0 0 0 0.2rem rgba(30, 60, 114, 0.25);
        }
        .form-label {
            font-weight: 500;
            color: #495057;
        }
        .payment-summary {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .payment-summary h5 {
            color: #1e3c72;
            font-weight: 600;
            margin-bottom: 15px;
        }
        .payment-summary p {
            margin-bottom: 10px;
            color: #495057;
        }
        .payment-summary strong {
            color: #1e3c72;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
    <?php include '../includes/user-nav.php'; ?>
    
    <div class="main-content">
        <div class="container mt-4">
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="card fade-in">
                        <div class="card-header">
                            <h4>Booking Details</h4>
                        </div>
                        <div class="card-body">
                            <table class="table">
                                <tr>
                                    <th>Slot Number:</th>
                                    <td><?php echo htmlspecialchars($booking['slot_number']); ?></td>
                                </tr>
                                <tr>
                                    <th>Floor:</th>
                                    <td><?php echo htmlspecialchars($booking['floor']); ?></td>
                                </tr>
                                <tr>
                                    <th>Type:</th>
                                    <td><?php echo ucfirst($booking['type']); ?></td>
                                </tr>
                                <tr>
                                    <th>Start Time:</th>
                                    <td><?php echo date('M d, Y H:i', strtotime($booking['start_time'])); ?></td>
                                </tr>
                                <tr>
                                    <th>End Time:</th>
                                    <td><?php echo date('M d, Y H:i', strtotime($booking['end_time'])); ?></td>
                                </tr>
                                <tr>
                                    <th>Duration:</th>
                                    <td><?php echo $hours; ?> hours</td>
                                </tr>
                                <tr>
                                    <th>Total Amount:</th>
                                    <td>K<?php echo number_format($total_amount, 2); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="card fade-in">
                        <div class="card-header">
                            <h4>Payment Details</h4>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="">
                                <div class="mb-3">
                                    <label for="payment_method" class="form-label">Payment Method</label>
                                    <select class="form-select" id="payment_method" name="payment_method" required onchange="showPaymentFields(this.value)">
                                        <option value="">Select payment method</option>
                                        <option value="airtel_money">Airtel Money</option>
                                        <option value="mtn_money">MTN Money</option>
                                        <option value="zamtel_money">Zamtel Money</option>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="account_number" class="form-label">Account Number</label>
                                    <input type="text" class="form-control" id="account_number" name="account_number" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="cvv" class="form-label">CVV</label>
                                    <input type="password" class="form-control" id="cvv" name="cvv" maxlength="3" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="expiry_date" class="form-label">Expiry Date</label>
                                    <input type="month" class="form-control" id="expiry_date" name="expiry_date" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="phone_number" class="form-label">Phone Number</label>
                                    <input type="tel" class="form-control" id="phone_number" name="phone_number" placeholder="Enter your phone number" required>
                                    <small class="text-muted">Enter the phone number registered with your mobile money account</small>
                                </div>
                                
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-primary">Complete Payment</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function showPaymentFields(method) {
            // Hide all payment method fields
            document.querySelectorAll('.payment-method').forEach(field => {
                field.classList.remove('active');
            });
            
            // Show selected payment method fields
            if (method) {
                document.getElementById(method + '_fields').classList.add('active');
            }
        }
    </script>
</body>
</html> 