<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';

// Check if user is logged in
if (!$auth->isLoggedIn()) {
    header('Location: ../login.php');
    exit();
}

// Get user's bookings
$stmt = $db->prepare("
    SELECT b.*, ps.slot_number, ps.floor, ps.type, v.vehicle_number, v.vehicle_type, v.vehicle_model,
           p.id as payment_id,
           b.total_amount as payment_amount,
           b.amount as regular_amount,
           b.penalty_amount
    FROM bookings b
    JOIN parking_slots ps ON b.slot_id = ps.id
    JOIN vehicles v ON b.vehicle_id = v.id
    LEFT JOIN payments p ON b.id = p.booking_id
    WHERE b.user_id = ?
    ORDER BY b.created_at DESC
");
$stmt->execute([$_SESSION['user_id']]);
$bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Bookings - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            overflow: hidden;
            transition: transform 0.3s ease;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .card-header {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            padding: 1.5rem;
            border-bottom: none;
        }
        .card-header h4 {
            margin: 0;
            font-weight: 600;
        }
        .card-body {
            padding: 2rem;
        }
        .booking-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            border-left: 4px solid #1e3c72;
        }
        .booking-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        .booking-card.active {
            border-left-color: #28a745;
        }
        .booking-card.completed {
            border-left-color: #6c757d;
        }
        .booking-card.cancelled {
            border-left-color: #dc3545;
        }
        .booking-icon {
            font-size: 2rem;
            color: #1e3c72;
            margin-bottom: 15px;
        }
        .booking-details {
            margin-top: 15px;
        }
        .booking-details p {
            margin-bottom: 5px;
            color: #495057;
        }
        .booking-details strong {
            color: #1e3c72;
        }
        .btn-primary {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            border: none;
            padding: 0.8rem 1.5rem;
            border-radius: 10px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(30, 60, 114, 0.3);
        }
        .btn-outline-secondary {
            border-radius: 10px;
            padding: 0.8rem 1.5rem;
            transition: all 0.3s ease;
        }
        .btn-outline-secondary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .alert {
            border-radius: 10px;
            border: none;
        }
        .no-bookings {
            text-align: center;
            padding: 40px;
            color: #6c757d;
        }
        .no-bookings i {
            font-size: 3rem;
            color: #1e3c72;
            margin-bottom: 20px;
        }
        .status-badge {
            display: inline-block;
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 500;
            margin-left: 10px;
        }
        .status-badge.active {
            background: #d4edda;
            color: #155724;
        }
        .status-badge.completed {
            background: #e2e3e5;
            color: #383d41;
        }
        .status-badge.cancelled {
            background: #f8d7da;
            color: #721c24;
        }
        .booking-actions {
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px solid #e9ecef;
        }
        .filter-section {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .filter-section h5 {
            color: #1e3c72;
            font-weight: 600;
            margin-bottom: 15px;
        }
        .form-control {
            border-radius: 10px;
            padding: 0.8rem 1rem;
            border: 2px solid #e9ecef;
            transition: all 0.3s ease;
        }
        .form-control:focus {
            border-color: #1e3c72;
            box-shadow: 0 0 0 0.2rem rgba(30, 60, 114, 0.25);
        }
        .form-label {
            font-weight: 500;
            color: #495057;
        }
    </style>
</head>
<body>
    <?php include '../includes/user-nav.php'; ?>
    
    <div class="main-content">
    <div class="container mt-4">
        <div class="card fade-in">
            <div class="card-header">
                <h4><i class="fas fa-calendar-alt me-2"></i>My Bookings</h4>
            </div>
            <div class="card-body">
                <?php if (empty($bookings)): ?>
                    <div class="alert alert-info">
                        You have no bookings yet. <a href="dashboard.php">Book a parking slot now!</a>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Slot</th>
                                    <th>Floor</th>
                                    <th>Type</th>
                                    <th>Start Time</th>
                                    <th>End Time</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($bookings as $booking): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($booking['slot_number']); ?></td>
                                        <td><?php echo htmlspecialchars($booking['floor']); ?></td>
                                        <td><?php echo ucfirst($booking['type']); ?></td>
                                        <td><?php echo date('Y-m-d H:i', strtotime($booking['start_time'])); ?></td>
                                        <td><?php echo date('Y-m-d H:i', strtotime($booking['end_time'])); ?></td>
                                        <td>
                                            <span class="badge bg-<?php 
                                                echo $booking['status'] === 'active' ? 'success' : 
                                                    ($booking['status'] === 'completed' ? 'secondary' : 'danger'); 
                                            ?>">
                                                <?php echo ucfirst($booking['status']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php if ($booking['status'] === 'active'): ?>
                                                <?php if (empty($booking['check_in_time'])): ?>
                                                    <a href="check-in.php?id=<?php echo $booking['id']; ?>" class="btn btn-sm btn-success">Check In</a>
                                                <?php else: ?>
                                                    <a href="check-out.php?id=<?php echo $booking['id']; ?>" class="btn btn-sm btn-danger">Check Out</a>
                                                <?php endif; ?>
                                                <a href="cancel-booking.php?id=<?php echo $booking['id']; ?>" class="btn btn-sm btn-warning" onclick="return confirm('Are you sure you want to cancel this booking?')">Cancel</a>
                                            <?php endif; ?>
                                            <?php if ($booking['status'] === 'completed' && !empty($booking['payment_id'])): ?>
                                                <a href="view-receipt.php?id=<?php echo $booking['payment_id']; ?>" class="btn btn-sm btn-info">View Receipt</a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
</body>
</html> 