<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';

// Check if user is logged in
if (!$auth->isLoggedIn()) {
    header('Location: ../login.php');
    exit();
}

// Handle mark as read action
if (isset($_GET['mark_read']) && is_numeric($_GET['mark_read'])) {
    try {
        $stmt = $db->prepare("INSERT IGNORE INTO announcement_reads (announcement_id, user_id) VALUES (?, ?)");
        $stmt->execute([$_GET['mark_read'], $_SESSION['user_id']]);
        // Refresh the page to update the read status
        header('Location: announcements.php');
        exit();
    } catch (PDOException $e) {
        $error = 'Failed to mark announcement as read: ' . $e->getMessage();
    }
}

// Get all announcements for the user
$stmt = $db->prepare("
    SELECT a.*, 
           ar.read_at,
           CASE 
               WHEN a.expires_at IS NULL THEN 'Never'
               WHEN a.expires_at < NOW() THEN 'Expired'
               ELSE DATE_FORMAT(a.expires_at, '%M %d, %Y %H:%i')
           END as expiration_status
    FROM announcements a 
    LEFT JOIN announcement_reads ar ON a.id = ar.announcement_id AND ar.user_id = ?
    WHERE (a.recipient_type = 'all' 
    OR (a.recipient_type = 'specific' AND a.recipient_id = ?))
    AND (a.expires_at IS NULL OR a.expires_at > NOW())
    ORDER BY a.created_at DESC
");
$stmt->execute([$_SESSION['user_id'], $_SESSION['user_id']]);
$announcements = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get count of unread announcements
$stmt = $db->prepare("
    SELECT COUNT(*) 
    FROM announcements a 
    LEFT JOIN announcement_reads ar ON a.id = ar.announcement_id AND ar.user_id = ?
    WHERE (a.recipient_type = 'all' 
    OR (a.recipient_type = 'specific' AND a.recipient_id = ?))
    AND (a.expires_at IS NULL OR a.expires_at > NOW())
    AND ar.id IS NULL
");
$stmt->execute([$_SESSION['user_id'], $_SESSION['user_id']]);
$unread_count = $stmt->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Announcements - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            overflow: hidden;
            transition: transform 0.3s ease;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .card-header {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            padding: 1.5rem;
            border-bottom: none;
        }
        .card-header h4 {
            margin: 0;
            font-weight: 600;
        }
        .card-body {
            padding: 2rem;
        }
        .announcement-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            border-left: 4px solid #1e3c72;
        }
        .announcement-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        .announcement-card.unread {
            border-left-color: #dc3545;
            background: #fff5f5;
        }
        .announcement-title {
            font-size: 1.2rem;
            font-weight: 600;
            color: #1e3c72;
            margin-bottom: 10px;
        }
        .announcement-meta {
            font-size: 0.9rem;
            color: #6c757d;
            margin-bottom: 15px;
        }
        .announcement-content {
            color: #495057;
            line-height: 1.6;
        }
        .announcement-actions {
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px solid #e9ecef;
        }
        .btn-primary {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            border: none;
            padding: 0.8rem 1.5rem;
            border-radius: 10px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(30, 60, 114, 0.3);
        }
        .btn-light {
            border-radius: 10px;
            padding: 0.8rem 1.5rem;
            transition: all 0.3s ease;
        }
        .btn-light:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .badge {
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-weight: 500;
        }
        .no-announcements {
            text-align: center;
            padding: 40px;
            color: #6c757d;
        }
        .no-announcements i {
            font-size: 3rem;
            color: #1e3c72;
            margin-bottom: 20px;
        }
        .expiration-badge {
            display: inline-block;
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 500;
            margin-left: 10px;
        }
        .expiration-badge.expired {
            background: #f8d7da;
            color: #721c24;
        }
        .expiration-badge.never {
            background: #d4edda;
            color: #155724;
        }
        .expiration-badge.upcoming {
            background: #cce5ff;
            color: #004085;
        }
    </style>
</head>
<body>
    <?php include '../includes/user-nav.php'; ?>
    
    <div class="main-content">
        <div class="container-fluid py-4">
            <div class="card">
                <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">
                        <i class="fas fa-bullhorn me-2"></i>Announcements
                        <?php if ($unread_count > 0): ?>
                            <span class="badge bg-danger ms-2"><?php echo $unread_count; ?> new</span>
                        <?php endif; ?>
                    </h4>
                    <a href="dashboard.php" class="btn btn-light">
                        <i class="fas fa-arrow-left me-1"></i> Back to Dashboard
                    </a>
                </div>
                <div class="card-body">
                    <?php if (empty($announcements)): ?>
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i>No announcements available.
                        </div>
                    <?php else: ?>
                        <div class="announcements-list">
                            <?php foreach ($announcements as $announcement): ?>
                                <div class="announcement-item mb-4 p-3 border rounded <?php echo $announcement['read_at'] ? '' : 'bg-light'; ?>">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <h5 class="mb-2">
                                            <?php echo htmlspecialchars($announcement['title']); ?>
                                            <?php if ($announcement['expiration_status'] !== 'Never'): ?>
                                                <small class="text-muted">(Expires: <?php echo $announcement['expiration_status']; ?>)</small>
                                            <?php endif; ?>
                                        </h5>
                                        <?php if (!$announcement['read_at']): ?>
                                            <a href="?mark_read=<?php echo $announcement['id']; ?>" class="btn btn-sm btn-outline-primary">
                                                <i class="fas fa-check me-1"></i> Mark as Read
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                    <p class="mb-2"><?php echo htmlspecialchars($announcement['message']); ?></p>
                                    <div class="text-muted">
                                        <small>
                                            <i class="fas fa-clock me-1"></i>
                                            Posted: <?php echo date('M d, Y H:i', strtotime($announcement['created_at'])); ?>
                                            <?php if ($announcement['read_at']): ?>
                                                | <i class="fas fa-check-circle me-1"></i>
                                                Read: <?php echo date('M d, Y H:i', strtotime($announcement['read_at'])); ?>
                                            <?php endif; ?>
                                        </small>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

 