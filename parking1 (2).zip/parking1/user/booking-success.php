<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';

// Check if user is logged in
if (!$auth->isLoggedIn()) {
    header('Location: ../login.php');
    exit();
}

// Check if there's a booking in session
if (!isset($_SESSION['last_booking'])) {
    header('Location: dashboard.php');
    exit();
}

$booking = $_SESSION['last_booking'];

// Get vehicle details
$stmt = $db->prepare("SELECT * FROM vehicles WHERE id = ?");
$stmt->execute([$booking['vehicle_id']]);
$vehicle = $stmt->fetch(PDO::FETCH_ASSOC);

// Clear the booking from session
unset($_SESSION['last_booking']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Success - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
        }
        .success-card {
            max-width: 600px;
            margin: 2rem auto;
            border: none;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .success-header {
            background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%);
            color: white;
            padding: 2rem;
            text-align: center;
        }
        .success-icon {
            font-size: 4rem;
            margin-bottom: 1rem;
            animation: bounce 1s;
        }
        .success-body {
            padding: 2rem;
            background: white;
        }
        .booking-details {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
        }
        .detail-item {
            display: flex;
            justify-content: space-between;
            padding: 0.5rem 0;
            border-bottom: 1px solid #e9ecef;
        }
        .detail-item:last-child {
            border-bottom: none;
        }
        .detail-label {
            color: #6c757d;
            font-weight: 500;
        }
        .detail-value {
            color: #212529;
            font-weight: 600;
        }
        .btn-success {
            background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%);
            border: none;
            padding: 0.8rem 1.5rem;
            border-radius: 10px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        .btn-success:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(76, 175, 80, 0.3);
        }
        @keyframes bounce {
            0%, 20%, 50%, 80%, 100% {
                transform: translateY(0);
            }
            40% {
                transform: translateY(-20px);
            }
            60% {
                transform: translateY(-10px);
            }
        }
    </style>
</head>
<body>
    <?php include '../includes/user-nav.php'; ?>
    
    <div class="container">
        <div class="success-card">
            <div class="success-header">
                <i class="fas fa-check-circle success-icon"></i>
                <h3>Booking Successful!</h3>
                <p>Your parking slot has been booked and checked in successfully.</p>
            </div>
            <div class="success-body">
                <div class="booking-details">
                    <div class="detail-item">
                        <span class="detail-label">Slot Number:</span>
                        <span class="detail-value"><?php echo htmlspecialchars($booking['slot_number']); ?></span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Floor:</span>
                        <span class="detail-value"><?php echo htmlspecialchars($booking['floor']); ?></span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Vehicle:</span>
                        <span class="detail-value">
                            <?php echo htmlspecialchars($vehicle['vehicle_number']); ?> 
                            (<?php echo htmlspecialchars($vehicle['vehicle_type']); ?>)
                        </span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Start Time:</span>
                        <span class="detail-value"><?php echo date('M d, Y h:i A', strtotime($booking['start_time'])); ?></span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">End Time:</span>
                        <span class="detail-value"><?php echo date('M d, Y h:i A', strtotime($booking['end_time'])); ?></span>
                    </div>
                </div>
                <div class="text-center">
                    <a href="dashboard.php" class="btn btn-success">
                        <i class="fas fa-home me-2"></i>Go to Dashboard
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
</body>
</html> 