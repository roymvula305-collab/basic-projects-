<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';

// Check if user is logged in
if (!$auth->isLoggedIn()) {
    header('Location: ../login.php');
    exit();
}

$error = '';
$success = '';

// Handle vehicle deletion
if (isset($_POST['delete_vehicle'])) {
    $vehicle_id = (int)$_POST['vehicle_id'];
    
    // Check if vehicle belongs to user
    $stmt = $db->prepare("SELECT id FROM vehicles WHERE id = ? AND user_id = ?");
    $stmt->execute([$vehicle_id, $_SESSION['user_id']]);
    
    if ($stmt->fetch()) {
        // Delete vehicle
        $stmt = $db->prepare("DELETE FROM vehicles WHERE id = ?");
        $stmt->execute([$vehicle_id]);
        $success = 'Vehicle deleted successfully';
    } else {
        $error = 'Vehicle not found';
    }
}

// Get user's vehicles with booking information
$stmt = $db->prepare("
    SELECT v.*, 
           (SELECT COUNT(*) FROM bookings WHERE vehicle_id = v.id) as booking_count,
           (SELECT MAX(check_in_time) FROM bookings WHERE vehicle_id = v.id) as last_used
    FROM vehicles v 
    WHERE v.user_id = ? 
    ORDER BY v.created_at DESC
");
$stmt->execute([$_SESSION['user_id']]);
$vehicles = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Format the last used date
foreach ($vehicles as &$vehicle) {
    if ($vehicle['last_used']) {
        $vehicle['last_used_formatted'] = date('M d, Y H:i', strtotime($vehicle['last_used']));
    } else {
        $vehicle['last_used_formatted'] = 'Never used';
    }
}
unset($vehicle); // Break the reference
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Vehicles - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
        }
        .main-content {
            padding: 2rem 0;
        }
        .card {
            border: none;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            overflow: hidden;
            transition: all 0.3s ease;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(0,0,0,0.15);
        }
        .card-header {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            padding: 1.5rem;
            border-bottom: none;
            position: relative;
            overflow: hidden;
        }
        .card-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0) 100%);
            z-index: 1;
        }
        .card-header h4 {
            margin: 0;
            font-weight: 600;
            position: relative;
            z-index: 2;
        }
        .card-body {
            padding: 2rem;
        }
        .vehicle-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 25px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
            border-left: 4px solid #1e3c72;
            position: relative;
            overflow: hidden;
        }
        .vehicle-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, #1e3c72, #2a5298);
        }
        .vehicle-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        .vehicle-card.car {
            border-left-color: #1e3c72;
        }
        .vehicle-card.motorcycle {
            border-left-color: #2a5298;
        }
        .vehicle-card.truck {
            border-left-color: #4a90e2;
        }
        .vehicle-icon {
            font-size: 2.5rem;
            color: #1e3c72;
            margin-bottom: 20px;
            text-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .vehicle-details {
            margin-top: 20px;
        }
        .vehicle-details p {
            margin-bottom: 8px;
            color: #495057;
            font-size: 0.95rem;
        }
        .vehicle-details strong {
            color: #1e3c72;
            font-weight: 600;
        }
        .vehicle-number {
            font-size: 1.4rem;
            font-weight: 700;
            color: #1e3c72;
            margin-bottom: 15px;
            letter-spacing: 0.5px;
        }
        .vehicle-type {
            padding: 6px 18px;
            border-radius: 25px;
            font-weight: 600;
            font-size: 0.9rem;
            display: inline-block;
            margin-bottom: 15px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .type-car {
            background: #e3f2fd;
            color: #0d47a1;
        }
        .type-motorcycle {
            background: #e8f5e9;
            color: #1b5e20;
        }
        .type-truck {
            background: #fff3e0;
            color: #e65100;
        }
        .btn-primary {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            border: none;
            padding: 0.8rem 1.5rem;
            border-radius: 12px;
            font-weight: 600;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-size: 0.9rem;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(30, 60, 114, 0.3);
        }
        .btn-outline-danger {
            border-radius: 12px;
            padding: 0.8rem 1.5rem;
            transition: all 0.3s ease;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-size: 0.9rem;
        }
        .btn-outline-danger:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(220, 53, 69, 0.3);
        }
        .alert {
            border-radius: 15px;
            border: none;
            padding: 1.25rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }
        .no-vehicles {
            text-align: center;
            padding: 50px;
            color: #6c757d;
        }
        .no-vehicles i {
            font-size: 4rem;
            color: #1e3c72;
            margin-bottom: 25px;
            opacity: 0.7;
        }
        .no-vehicles h4 {
            font-weight: 600;
            margin-bottom: 15px;
            color: #1e3c72;
        }
        .no-vehicles p {
            font-size: 1.1rem;
            margin-bottom: 25px;
        }
        .form-control {
            border-radius: 12px;
            padding: 0.9rem 1.2rem;
            border: 2px solid #e9ecef;
            transition: all 0.3s ease;
            font-size: 0.95rem;
        }
        .form-control:focus {
            border-color: #1e3c72;
            box-shadow: 0 0 0 0.2rem rgba(30, 60, 114, 0.15);
        }
        .form-label {
            font-weight: 600;
            color: #495057;
            margin-bottom: 0.5rem;
        }
        .add-vehicle-section {
            background: white;
            border-radius: 20px;
            padding: 25px;
            margin-bottom: 25px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            border: 1px solid rgba(0,0,0,0.05);
        }
        .vehicle-actions {
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid rgba(0,0,0,0.05);
            display: flex;
            gap: 10px;
            justify-content: flex-end;
        }
        .vehicle-stats {
            display: flex;
            gap: 20px;
            margin-top: 15px;
        }
        .stat-item {
            background: #f8f9fa;
            padding: 10px 15px;
            border-radius: 10px;
            text-align: center;
            flex: 1;
        }
        .stat-label {
            font-size: 0.8rem;
            color: #6c757d;
            margin-bottom: 5px;
        }
        .stat-value {
            font-size: 1.1rem;
            font-weight: 600;
            color: #1e3c72;
        }
        @media (max-width: 768px) {
            .vehicle-stats {
                flex-direction: column;
                gap: 10px;
            }
            .vehicle-actions {
                flex-direction: column;
            }
            .btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <?php include '../includes/user-nav.php'; ?>
    
    <div class="main-content">
        <div class="container">
        <div class="row">
                <div class="col-md-8 mx-auto">
                <div class="card">
                        <div class="card-header">
                            <h4><i class="fas fa-car me-2"></i>My Vehicles</h4>
                    </div>
                    <div class="card-body">
                        <?php if ($error): ?>
                                <div class="alert alert-danger">
                                    <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
                                </div>
                        <?php endif; ?>
                        
                        <?php if ($success): ?>
                                <div class="alert alert-success">
                                    <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
                                </div>
                        <?php endif; ?>

                        <?php if (empty($vehicles)): ?>
                                <div class="no-vehicles">
                                    <i class="fas fa-car-crash"></i>
                                    <h4>No Vehicles Found</h4>
                                    <p>You haven't added any vehicles yet. Add your first vehicle to get started!</p>
                                    <a href="add-vehicle.php" class="btn btn-primary">
                                        <i class="fas fa-plus me-2"></i>Add Vehicle
                                    </a>
                            </div>
                        <?php else: ?>
                                <div class="row">
                                        <?php foreach ($vehicles as $vehicle): ?>
                                        <div class="col-md-6 mb-4">
                                            <div class="vehicle-card <?php echo $vehicle['vehicle_type']; ?>">
                                                <div class="vehicle-icon">
                                                    <?php if ($vehicle['vehicle_type'] === 'car'): ?>
                                                        <i class="fas fa-car"></i>
                                                    <?php elseif ($vehicle['vehicle_type'] === 'motorcycle'): ?>
                                                        <i class="fas fa-motorcycle"></i>
                                                    <?php else: ?>
                                                        <i class="fas fa-truck"></i>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="vehicle-number"><?php echo htmlspecialchars($vehicle['vehicle_number']); ?></div>
                                                <div class="vehicle-type type-<?php echo $vehicle['vehicle_type']; ?>">
                                                    <?php echo ucfirst($vehicle['vehicle_type']); ?>
                                                </div>
                                                <div class="vehicle-details">
                                                    <p><strong>Model:</strong> <?php echo htmlspecialchars($vehicle['vehicle_model']); ?></p>
                                                    <p><strong>Color:</strong> <?php echo htmlspecialchars($vehicle['vehicle_color']); ?></p>
                                                    <p><strong>Bookings:</strong> <?php echo $vehicle['booking_count']; ?></p>
                                                    <p><strong>Last Used:</strong> <?php echo $vehicle['last_used_formatted']; ?></p>
                                                </div>
                                                <div class="mt-4">
                                                    <form method="POST" action="" style="display: inline;">
                                                        <input type="hidden" name="vehicle_id" value="<?php echo $vehicle['id']; ?>">
                                                        <button type="submit" name="delete_vehicle" class="btn btn-outline-danger" 
                                                                onclick="return confirm('Are you sure you want to delete this vehicle?')">
                                                            <i class="fas fa-trash me-2"></i>Delete
                                                        </button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; ?>
                                </div>
                                <div class="text-center mt-4">
                                    <a href="add-vehicle.php" class="btn btn-primary">
                                        <i class="fas fa-plus me-2"></i>Add Another Vehicle
                                    </a>
                            </div>
                        <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
</body>
</html> 