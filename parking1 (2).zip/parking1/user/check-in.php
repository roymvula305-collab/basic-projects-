<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';

// Check if user is logged in
if (!$auth->isLoggedIn()) {
    header('Location: ../login.php');
    exit();
}

$error = '';
$success = '';

// Get booking ID
$booking_id = $_GET['id'] ?? 0;

// Verify booking belongs to user and is active
$stmt = $db->prepare("
    SELECT b.*, p.slot_number, p.floor 
    FROM bookings b 
    JOIN parking_slots p ON b.slot_id = p.id 
    WHERE b.id = ? AND b.user_id = ? AND b.status = 'active'
");
$stmt->execute([$booking_id, $_SESSION['user_id']]);
$booking = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$booking) {
    header('Location: my-bookings.php');
    exit();
}

try {
    // Start transaction
    $db->beginTransaction();
    
    // Update booking with check-in time
    $stmt = $db->prepare("
        UPDATE bookings 
        SET check_in_time = NOW() 
        WHERE id = ? AND user_id = ? AND status = 'active'
    ");
    $stmt->execute([$booking_id, $_SESSION['user_id']]);
    
    
    // Commit transaction
    $db->commit();
    
    $success = 'Check-in successful!';
    
} catch (Exception $e) {
    $db->rollBack();
    $error = 'Check-in failed: ' . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Check In - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <?php include '../includes/user-nav.php'; ?>
    
    <div class="main-content">
    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card fade-in">
                    <div class="card-header">
                        <h4>Check In</h4>
                    </div>
                    <div class="card-body text-center">
                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        
                        <?php if ($success): ?>
                            <div class="alert alert-success"><?php echo $success; ?></div>
                            
                            <div class="mb-4">
                                <h5>Booking Details</h5>
                                <p>
                                    <strong>Slot Number:</strong> <?php echo htmlspecialchars($booking['slot_number']); ?><br>
                                    <strong>Floor:</strong> <?php echo htmlspecialchars($booking['floor']); ?><br>
                                    <strong>Check-in Time:</strong> <?php echo date('Y-m-d H:i:s'); ?>
                                </p>
                            </div>
                            
                            <div class="d-grid gap-2">
                                <a href="my-bookings.php" class="btn btn-primary">Back to My Bookings</a>
                            </div>
                        <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
</body>
</html> 