<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';

// Check if user is logged in
if (!$auth->isLoggedIn()) {
    header('Location: ../login.php');
    exit();
}

$error = '';
$success = '';

// Get slot ID from URL
$slot_id = isset($_GET['slot_id']) ? (int)$_GET['slot_id'] : 0;

// Get slot details
$stmt = $db->prepare("
    SELECT * FROM parking_slots 
    WHERE id = ? AND status = 'available'
");
$stmt->execute([$slot_id]);
$slot = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$slot) {
    header('Location: dashboard.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $start_time = $_POST['start_time'] ?? '';
    $end_time = $_POST['end_time'] ?? '';
    $vehicle_id = $_POST['vehicle_id'] ?? 0;

    if (empty($start_time) || empty($end_time) || empty($vehicle_id)) {
        $error = 'Please fill in all required fields';
    } else {
        try {
            $db->beginTransaction();

            // Create booking
            $stmt = $db->prepare("
                INSERT INTO bookings (user_id, slot_id, vehicle_id, start_time, end_time, status, check_in_time)
                VALUES (?, ?, ?, ?, ?, 'active', NOW())
            ");
            $stmt->execute([
                $_SESSION['user_id'],
                $slot_id,
                $vehicle_id,
                $start_time,
                $end_time
            ]);
            $booking_id = $db->lastInsertId();

            // Update slot status
            $stmt = $db->prepare("
                UPDATE parking_slots 
                SET status = 'occupied' 
                WHERE id = ?
            ");
            $stmt->execute([$slot_id]);

            $db->commit();
            $success = 'Slot booked and checked in successfully!';
            
            // Store booking details in session for success page
            $_SESSION['last_booking'] = [
                'id' => $booking_id,
                'slot_number' => $slot['slot_number'],
                'floor' => $slot['floor'],
                'start_time' => $start_time,
                'end_time' => $end_time,
                'vehicle_id' => $vehicle_id
            ];
            
            // Redirect to success page
            header('Location: booking-success.php');
            exit();
        } catch (PDOException $e) {
            $db->rollBack();
            $error = 'Error booking slot: ' . $e->getMessage();
        }
    }
}

// Get user's vehicles
$stmt = $db->prepare("
    SELECT * FROM vehicles 
    WHERE user_id = ?
");
$stmt->execute([$_SESSION['user_id']]);
$vehicles = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Parking Slot - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            overflow: hidden;
            transition: transform 0.3s ease;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .card-header {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            padding: 1.5rem;
            border-bottom: none;
        }
        .card-header h4 {
            margin: 0;
            font-weight: 600;
        }
        .card-body {
            padding: 2rem;
        }
        .slot-selection {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .slot-selection h5 {
            color: #1e3c72;
            font-weight: 600;
            margin-bottom: 15px;
        }
        .slot-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        .slot-item {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 15px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            border: 2px solid transparent;
        }
        .slot-item:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .slot-item.selected {
            border-color: #1e3c72;
            background: #e9ecef;
        }
        .slot-item.occupied {
            background: #f8d7da;
            color: #721c24;
            cursor: not-allowed;
        }
        .slot-item.available {
            background: #d4edda;
            color: #155724;
        }
        .slot-item.maintenance {
            background: #fff3cd;
            color: #856404;
            cursor: not-allowed;
        }
        .slot-number {
            font-weight: 600;
            margin-bottom: 5px;
        }
        .slot-type {
            font-size: 0.8rem;
            color: #6c757d;
        }
        .btn-primary {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            border: none;
            padding: 0.8rem 1.5rem;
            border-radius: 10px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(30, 60, 114, 0.3);
        }
        .btn-outline-secondary {
            border-radius: 10px;
            padding: 0.8rem 1.5rem;
            transition: all 0.3s ease;
        }
        .btn-outline-secondary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .alert {
            border-radius: 10px;
            border: none;
        }
        .form-control {
            border-radius: 10px;
            padding: 0.8rem 1rem;
            border: 2px solid #e9ecef;
            transition: all 0.3s ease;
        }
        .form-control:focus {
            border-color: #1e3c72;
            box-shadow: 0 0 0 0.2rem rgba(30, 60, 114, 0.25);
        }
        .form-label {
            font-weight: 500;
            color: #495057;
        }
        .booking-summary {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .booking-summary h5 {
            color: #1e3c72;
            font-weight: 600;
            margin-bottom: 15px;
        }
        .booking-summary p {
            margin-bottom: 10px;
            color: #495057;
        }
        .booking-summary strong {
            color: #1e3c72;
        }
        .floor-selector {
            background: white;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .floor-selector h6 {
            color: #1e3c72;
            font-weight: 600;
            margin-bottom: 10px;
        }
        .floor-buttons {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        .floor-button {
            padding: 0.5rem 1rem;
            border-radius: 10px;
            background: #f8f9fa;
            border: 2px solid #e9ecef;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        .floor-button:hover {
            background: #e9ecef;
        }
        .floor-button.active {
            background: #1e3c72;
            color: white;
            border-color: #1e3c72;
        }
    </style>
</head>
<body>
    <?php include '../includes/user-nav.php'; ?>
    
    <div class="main-content">
    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                            <h4><i class="fas fa-parking me-2"></i>Book Parking Slot</h4>
                    </div>
                    <div class="card-body">
                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>

                        <?php if ($success): ?>
                            <div class="alert alert-success"><?php echo $success; ?></div>
                        <?php endif; ?>

                        <form method="POST" action="">
                            <div class="mb-3">
                                <label class="form-label">Slot Number</label>
                                <input type="text" class="form-control" value="<?php echo htmlspecialchars($slot['slot_number']); ?>" readonly>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Floor</label>
                                <input type="text" class="form-control" value="<?php echo htmlspecialchars($slot['floor']); ?>" readonly>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Type</label>
                                <input type="text" class="form-control" value="<?php echo ucfirst($slot['type']); ?>" readonly>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Vehicle</label>
                                <select name="vehicle_id" class="form-select" required>
                                    <option value="">Select Vehicle</option>
                                    <?php foreach ($vehicles as $vehicle): ?>
                                        <option value="<?php echo $vehicle['id']; ?>">
                                            <?php echo htmlspecialchars($vehicle['vehicle_number']); ?> - 
                                            <?php echo htmlspecialchars($vehicle['vehicle_type']); ?> 
                                            <?php echo htmlspecialchars($vehicle['vehicle_model']); ?>
                                            (<?php echo htmlspecialchars($vehicle['vehicle_color']); ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Start Time</label>
                                <input type="datetime-local" name="start_time" class="form-control" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">End Time</label>
                                <input type="datetime-local" name="end_time" class="form-control" required>
                            </div>

                            <div class="alert alert-info">
                                <strong>Rate:</strong> K50.00 per hour
                            </div>

                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">Book Slot</button>
                            </div>
                        </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
</body>
</html> 