<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';

// Check if user is logged in
if (!$auth->isLoggedIn()) {
    header('Location: ../login.php');
    exit();
}

// Get booking ID from URL
$booking_id = $_GET['id'] ?? 0;

if ($booking_id) {
    try {
        $db->beginTransaction();
        
        // Get booking details
        $stmt = $db->prepare("
            SELECT b.*, ps.id as slot_id 
            FROM bookings b 
            JOIN parking_slots ps ON b.slot_id = ps.id 
            WHERE b.id = ? AND b.user_id = ?
        ");
        $stmt->execute([$booking_id, $_SESSION['user_id']]);
        $booking = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($booking) {
            // Update booking status to cancelled
            $stmt = $db->prepare("UPDATE bookings SET status = 'cancelled' WHERE id = ?");
            $stmt->execute([$booking_id]);
            
            // Update slot status to available
            $stmt = $db->prepare("UPDATE parking_slots SET status = 'available' WHERE id = ?");
            $stmt->execute([$booking['slot_id']]);
            
            // If there's a payment, mark it as refunded
            $stmt = $db->prepare("UPDATE payments SET status = 'refunded' WHERE booking_id = ?");
            $stmt->execute([$booking_id]);
            
            $db->commit();
            header("Location: my-bookings.php?success=3");
            exit();
        } else {
            throw new Exception("Booking not found");
        }
    } catch (Exception $e) {
        $db->rollBack();
        header("Location: my-bookings.php?error=1");
        exit();
    }
} else {
    header("Location: my-bookings.php");
    exit();
}
?> 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cancel Booking - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            overflow: hidden;
            transition: transform 0.3s ease;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .card-header {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            padding: 1.5rem;
            border-bottom: none;
        }
        .card-header h4 {
            margin: 0;
            font-weight: 600;
        }
        .card-body {
            padding: 2rem;
        }
        .booking-details {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .booking-details h5 {
            color: #1e3c72;
            font-weight: 600;
            margin-bottom: 15px;
        }
        .booking-details p {
            margin-bottom: 10px;
            color: #495057;
        }
        .booking-details strong {
            color: #1e3c72;
        }
        .btn-primary {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            border: none;
            padding: 0.8rem 1.5rem;
            border-radius: 10px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(30, 60, 114, 0.3);
        }
        .btn-outline-secondary {
            border-radius: 10px;
            padding: 0.8rem 1.5rem;
            transition: all 0.3s ease;
        }
        .btn-outline-secondary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .alert {
            border-radius: 10px;
            border: none;
        }
        .form-control {
            border-radius: 10px;
            padding: 0.8rem 1rem;
            border: 2px solid #e9ecef;
            transition: all 0.3s ease;
        }
        .form-control:focus {
            border-color: #1e3c72;
            box-shadow: 0 0 0 0.2rem rgba(30, 60, 114, 0.25);
        }
        .form-label {
            font-weight: 500;
            color: #495057;
        }
        .cancellation-summary {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .cancellation-summary h5 {
            color: #1e3c72;
            font-weight: 600;
            margin-bottom: 15px;
        }
        .cancellation-summary p {
            margin-bottom: 10px;
            color: #495057;
        }
        .cancellation-summary strong {
            color: #1e3c72;
        }
        .duration-badge {
            display: inline-block;
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 500;
            background: #d4edda;
            color: #155724;
            margin-bottom: 15px;
        }
        .vehicle-info {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 20px;
        }
        .vehicle-info p {
            margin-bottom: 5px;
        }
        .vehicle-info strong {
            color: #1e3c72;
        }
        .warning-message {
            background: #fff3cd;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 20px;
            border-left: 4px solid #ffc107;
        }
        .warning-message i {
            color: #856404;
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <?php include '../includes/user-nav.php'; ?>
    
    <div class="main-content">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <h4><i class="fas fa-times-circle me-2"></i>Cancel Booking</h4>
                        </div>
                        <div class="card-body">
                            <div class="booking-details">
                                <h5>Booking Details</h5>
                                <p><strong>Booking ID:</strong> <?php echo $booking['id']; ?></p>
                                <p><strong>Slot ID:</strong> <?php echo $booking['slot_id']; ?></p>
                                <p><strong>Booking Date:</strong> <?php echo $booking['booking_date']; ?></p>
                                <p><strong>Duration:</strong> <?php echo $booking['duration']; ?> hours</p>
                                <p><strong>Vehicle:</strong> <?php echo $booking['vehicle']; ?></p>
                            </div>
                            <div class="cancellation-summary">
                                <h5>Cancellation Summary</h5>
                                <p><strong>Reason for Cancellation:</strong> <?php echo $booking['cancellation_reason']; ?></p>
                                <p><strong>Refund Amount:</strong> <?php echo $booking['refund_amount']; ?> USD</p>
                            </div>
                            <div class="vehicle-info">
                                <h5>Vehicle Information</h5>
                                <p><strong>License Plate:</strong> <?php echo $booking['license_plate']; ?></p>
                                <p><strong>Vehicle Type:</strong> <?php echo $booking['vehicle_type']; ?></p>
                            </div>
                            <div class="warning-message">
                                <i class="fas fa-exclamation-circle me-2"></i>
                                <strong>Note:</strong>
                                <p>Cancelling this booking will result in a full refund. Please ensure you have a valid reason for cancelling.</p>
                            </div>
                            <form action="cancel-booking.php" method="post">
                                <input type="hidden" name="booking_id" value="<?php echo $booking['id']; ?>">
                                <button type="submit" class="btn btn-primary">Confirm Cancellation</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html> 