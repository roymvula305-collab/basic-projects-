<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';

// Check if user is logged in
if (!$auth->isLoggedIn()) {
    header('Location: ../login.php');
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $vehicle_number = trim($_POST['vehicle_number'] ?? '');
    $vehicle_type = trim($_POST['vehicle_type'] ?? '');
    $vehicle_model = trim($_POST['vehicle_model'] ?? '');
    $vehicle_color = trim($_POST['vehicle_color'] ?? '');

    if (empty($vehicle_number) || empty($vehicle_type) || empty($vehicle_model) || empty($vehicle_color)) {
        $error = 'Please fill in all fields';
    } else {
        try {
            // Check if vehicle number already exists for this user
            $stmt = $db->prepare("SELECT id FROM vehicles WHERE vehicle_number = ? AND user_id = ?");
            $stmt->execute([$vehicle_number, $_SESSION['user_id']]);
            
            if ($stmt->fetch()) {
                $error = 'This vehicle number is already registered';
            } else {
                // Insert new vehicle
                $stmt = $db->prepare("
                    INSERT INTO vehicles (user_id, vehicle_number, vehicle_type, vehicle_model, vehicle_color)
                    VALUES (?, ?, ?, ?, ?)
                ");
                $stmt->execute([
                    $_SESSION['user_id'],
                    $vehicle_number,
                    $vehicle_type,
                    $vehicle_model,
                    $vehicle_color
                ]);
                
                $success = 'Vehicle added successfully';
                header('Location: my-vehicles.php?success=1');
                exit();
            }
        } catch (Exception $e) {
            $error = 'Error adding vehicle: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Vehicle - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <?php include '../includes/user-nav.php'; ?>
    
    <div class="main-content">
        <div class="container mt-4">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <h4>Add New Vehicle</h4>
                        </div>
                        <div class="card-body">
                            <?php if ($error): ?>
                                <div class="alert alert-danger"><?php echo $error; ?></div>
                            <?php endif; ?>
                            
                            <?php if ($success): ?>
                                <div class="alert alert-success"><?php echo $success; ?></div>
                            <?php endif; ?>

                            <form method="POST" action="">
                                <div class="mb-3">
                                    <label class="form-label">Vehicle Number</label>
                                    <input type="text" name="vehicle_number" class="form-control" required>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Vehicle Type</label>
                                    <select name="vehicle_type" class="form-select" required>
                                        <option value="">Select Vehicle Type</option>
                                        <option value="car">Car</option>
                                        <option value="motorcycle">Motorcycle</option>
                                        <option value="truck">Truck</option>
                                        <option value="van">Van</option>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Vehicle Model</label>
                                    <input type="text" name="vehicle_model" class="form-control" required>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Vehicle Color</label>
                                    <input type="text" name="vehicle_color" class="form-control" required>
                                </div>

                                <div class="d-grid">
                                    <button type="submit" class="btn btn-primary">Add Vehicle</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
</body>
</html> 