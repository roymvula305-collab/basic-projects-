<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';

// Check if user is logged in
if (!$auth->isLoggedIn()) {
    header('Location: ../login.php');
    exit();
}

// Get payment ID from URL
$payment_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$payment_id) {
    header('Location: my-bookings.php');
    exit();
}

// Get booking details
$stmt = $db->prepare("
    SELECT 
        b.*,
        u.name as user_name,
        u.email as user_email,
        u.phone,
        ps.slot_number,
        ps.floor,
        ps.type as slot_type,
        p.amount as payment_amount,
        p.status as payment_status,
        p.created_at as payment_date,
        p.id as payment_id,
        v.vehicle_number,
        v.vehicle_type,
        v.vehicle_model,
        v.vehicle_color,
        TIMESTAMPDIFF(HOUR, b.start_time, b.end_time) as total_hours,
        TIMESTAMPDIFF(MINUTE, b.start_time, b.end_time) % 60 as remaining_minutes,
        FLOOR(TIMESTAMPDIFF(HOUR, b.start_time, b.end_time) / 24) as days
    FROM bookings b
    JOIN users u ON b.user_id = u.id
    JOIN parking_slots ps ON b.slot_id = ps.id
    JOIN payments p ON b.id = p.booking_id
    JOIN vehicles v ON b.vehicle_id = v.id
    WHERE p.id = ?
    AND b.user_id = ?
");
$stmt->execute([$payment_id, $_SESSION['user_id']]);
$booking = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$booking) {
    $_SESSION['error'] = "Booking not found or you don't have permission to view this receipt.";
    header('Location: my-bookings.php');
    exit();
}

// Calculate duration in hours
$start = new DateTime($booking['check_in_time']);
$end = new DateTime($booking['check_out_time']);
$duration = $start->diff($end);
$hours = $duration->h + ($duration->days * 24);
if ($duration->i > 0) {
    $hours += 1; // Round up to the next hour for partial hours
}

// Calculate total amount
$booking['total_amount'] = $booking['payment_amount'];

// Generate QR code data
$qr_data = [
    'receipt_id' => $booking['payment_id'],
    'amount' => $booking['total_amount'],
    'vehicle' => $booking['vehicle_number'],
    'user' => $booking['user_name'],
    'date' => date('Y-m-d H:i', strtotime($booking['payment_date'])),
    'slot' => $booking['slot_number'],
    'floor' => $booking['floor'],
    'duration' => $hours . ' hours',
    'status' => $booking['payment_status']
];
$qr_text = json_encode($qr_data);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Receipt - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
    <script src="https://cdn.rawgit.com/davidshimjs/qrcodejs/gh-pages/qrcode.min.js"></script>
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
        }
        @media print {
            body {
                background: white;
            }
            .card {
                box-shadow: none;
                border: 1px solid #ddd;
            }
            .btn-secondary, .btn-primary {
                display: none;
            }
            .card-header {
                background: #f8f9fa !important;
                color: black !important;
                border-bottom: 2px solid #ddd;
            }
            .receipt-details, .qr-code-container {
                box-shadow: none;
                border: 1px solid #ddd;
            }
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            overflow: hidden;
            transition: transform 0.3s ease;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .card-header {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            padding: 1.5rem;
            border-bottom: none;
        }
        .card-header h4 {
            margin: 0;
            font-weight: 600;
        }
        .card-body {
            padding: 2rem;
        }
        .receipt-details {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .receipt-details h5 {
            color: #1e3c72;
            font-weight: 600;
            margin-bottom: 15px;
        }
        .receipt-details p {
            margin-bottom: 10px;
            color: #495057;
        }
        .receipt-details strong {
            color: #1e3c72;
        }
        .btn-primary {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            border: none;
            padding: 0.8rem 1.5rem;
            border-radius: 10px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(30, 60, 114, 0.3);
        }
        .btn-outline-secondary {
            border-radius: 10px;
            padding: 0.8rem 1.5rem;
            transition: all 0.3s ease;
        }
        .btn-outline-secondary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .alert {
            border-radius: 10px;
            border: none;
        }
        .qr-code-container {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        .qr-code-container img {
            max-width: 200px;
                margin: 0 auto;
        }
        .payment-details {
            background: #f8f9fa;
            border-radius: 10px;
                padding: 20px;
            margin-bottom: 20px;
        }
        .payment-details h6 {
            color: #1e3c72;
            font-weight: 600;
            margin-bottom: 15px;
        }
        .payment-details p {
            margin-bottom: 5px;
            color: #495057;
        }
        .payment-details strong {
            color: #1e3c72;
        }
        .receipt-footer {
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #e9ecef;
            text-align: center;
            color: #6c757d;
        }
        .receipt-footer p {
            margin-bottom: 5px;
        }
        .receipt-footer small {
            color: #adb5bd;
        }
        .receipt-header {
            text-align: center;
            margin-bottom: 30px;
        }
        .receipt-header h3 {
            color: #1e3c72;
            font-weight: 600;
            margin-bottom: 10px;
        }
        .receipt-header p {
            color: #6c757d;
            margin-bottom: 0;
        }
        .receipt-section {
            margin-bottom: 30px;
        }
        .receipt-section h5 {
            color: #1e3c72;
            font-weight: 600;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid #e9ecef;
        }
        .receipt-section .row {
            margin-bottom: 10px;
        }
        .receipt-section .col-sm-4 {
            font-weight: 500;
            color: #495057;
        }
        .receipt-section .col-sm-8 {
            color: #212529;
        }
    </style>
</head>
<body>
    <?php include '../includes/user-nav.php'; ?>
    
    <div class="main-content">
    <div class="container mt-4">
        <div class="row">
            <div class="col-12 mb-3">
                <a href="my-bookings.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back to My Bookings
                </a>
                <button onclick="window.print()" class="btn btn-primary ms-2">
                    <i class="fas fa-print"></i> Print Receipt
                </button>
            </div>
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h4><i class="fas fa-receipt me-2"></i>Parking Receipt</h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card mb-4">
                                    <div class="card-header bg-primary text-white">
                                        <h5 class="card-title mb-0">Receipt Details</h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="row mb-3">
                                            <div class="col-sm-4 fw-bold">Receipt ID:</div>
                                            <div class="col-sm-8">#<?php echo str_pad($booking['id'], 6, '0', STR_PAD_LEFT); ?></div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-sm-4 fw-bold">Date Issued:</div>
                                            <div class="col-sm-8"><?php echo date('Y-m-d H:i', strtotime($booking['created_at'])); ?></div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-sm-4 fw-bold">Status:</div>
                                            <div class="col-sm-8">
                                                <span class="badge bg-<?php echo $booking['payment_status'] === 'completed' ? 'success' : 'warning'; ?>">
                                                    <?php echo $booking['payment_status'] === 'completed' ? 'Paid' : 'Not Paid'; ?>
                                                </span>
                                            </div>
                                        </div>
                                        <hr>
                                        <div class="row mb-3">
                                            <div class="col-sm-4 fw-bold">Vehicle Details:</div>
                                            <div class="col-sm-8">
                                                <div class="mb-1">
                                                    <strong>Number:</strong> <?php echo htmlspecialchars($booking['vehicle_number']); ?>
                                                </div>
                                                <div class="mb-1">
                                                    <strong>Type:</strong> <?php echo htmlspecialchars($booking['vehicle_type']); ?>
                                                </div>
                                                <div class="mb-1">
                                                    <strong>Model:</strong> <?php echo htmlspecialchars($booking['vehicle_model']); ?>
                                                </div>
                                                <div>
                                                    <strong>Color:</strong> <?php echo htmlspecialchars($booking['vehicle_color']); ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-sm-4 fw-bold">User Information:</div>
                                            <div class="col-sm-8">
                                                <div class="mb-1">
                                                    <strong>Name:</strong> <?php echo htmlspecialchars($booking['user_name']); ?>
                                                </div>
                                                <div class="mb-1">
                                                    <strong>Phone:</strong> <?php echo htmlspecialchars($booking['phone'] ?? 'Not provided'); ?>
                                                </div>
                                            </div>
                                        </div>
                                        <hr>
                                        <div class="row mb-3">
                                            <div class="col-sm-4 fw-bold">Parking Details:</div>
                                            <div class="col-sm-8">
                                                <div class="mb-1">
                                                    <strong>Period:</strong> 
                                                    <?php 
                                                    echo date('Y-m-d H:i', strtotime($booking['check_in_time'])) . ' to ' . 
                                                         date('Y-m-d H:i', strtotime($booking['check_out_time']));
                                                    ?>
                                                </div>
                                                <div class="mb-1">
                                                    <strong>Duration:</strong> 
                                                    <?php 
                                                    $days = $booking['days'];
                                                    $hours = $booking['total_hours'] % 24;
                                                    $minutes = $booking['remaining_minutes'];
                                                    
                                                    $duration_text = '';
                                                    if ($days > 0) {
                                                        $duration_text .= $days . ' day' . ($days > 1 ? 's' : '') . ' ';
                                                    }
                                                    if ($hours > 0) {
                                                        $duration_text .= $hours . ' hour' . ($hours > 1 ? 's' : '') . ' ';
                                                    }
                                                    if ($minutes > 0) {
                                                        $duration_text .= $minutes . ' minute' . ($minutes > 1 ? 's' : '');
                                                    }
                                                    if (empty($duration_text)) {
                                                        $duration_text = 'Less than a minute';
                                                    }
                                                    echo trim($duration_text);
                                                    ?>
                                                </div>
                                                <div class="mb-1">
                                                    <strong>Location:</strong> 
                                                    Slot <?php echo htmlspecialchars($booking['slot_number']); ?> 
                                                    (Floor <?php echo htmlspecialchars($booking['floor']); ?>)
                                                </div>
                                                <div>
                                                    <strong>Slot Type:</strong> <?php echo ucfirst(htmlspecialchars($booking['slot_type'])); ?>
                                                </div>
                                            </div>
                                        </div>
                                        <hr>
                                        <?php if ($booking['penalty_amount'] > 0): ?>
                                        <div class="row mb-3">
                                            <div class="col-sm-4 fw-bold">Penalty Details:</div>
                                            <div class="col-sm-8">
                                                <div class="mb-1 text-danger">
                                                    <strong>Penalty Hours:</strong> <?php echo ceil($booking['penalty_amount'] / 100); ?> hours (K100 per hour)
                                                </div>
                                                <div class="mb-1 text-danger">
                                                    <strong>Penalty Amount:</strong> K<?php echo number_format($booking['penalty_amount'], 2); ?>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card">
                                    <div class="card-header bg-primary text-white">
                                        <h5 class="card-title mb-0">QR Code</h5>
                                    </div>
                                    <div class="card-body text-center">
                                        <div id="qrcode" class="mb-3"></div>
                                        <p class="text-muted">Scan this QR code at the parking exit</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card mt-4">
                            <div class="card-body text-center">
                                <p class="mb-0">
                                    <strong><?php echo SITE_NAME; ?></strong><br>
                                    Thank you for choosing our parking services<br>
                                    For any queries, please contact our support team
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Create QR code data in a structured format
        const qrData = {
            "Receipt ID": <?php echo $booking['payment_id']; ?>,
            "Vehicle": {
                "Number": "<?php echo htmlspecialchars($booking['vehicle_number']); ?>",
                "Type": "<?php echo htmlspecialchars($booking['vehicle_type']); ?>",
                "Model": "<?php echo htmlspecialchars($booking['vehicle_model']); ?>",
                "Color": "<?php echo htmlspecialchars($booking['vehicle_color']); ?>"
            },
            "User": {
                "Name": "<?php echo htmlspecialchars($booking['user_name']); ?>",
                "Phone": "<?php echo htmlspecialchars($booking['phone'] ?? 'Not provided'); ?>"
            },
            "Parking": {
                "Start": "<?php echo date('Y-m-d H:i', strtotime($booking['check_in_time'])); ?>",
                "End": "<?php echo date('Y-m-d H:i', strtotime($booking['check_out_time'])); ?>",
                "Slot": "<?php echo htmlspecialchars($booking['slot_number']); ?>",
                "Floor": "<?php echo htmlspecialchars($booking['floor']); ?>",
                "Type": "<?php echo htmlspecialchars($booking['slot_type']); ?>"
            },
            "Status": "<?php echo $booking['payment_status'] === 'completed' ? 'Paid' : 'Not Paid'; ?>"
        };

        // Generate QR code with formatted text
        new QRCode(document.getElementById("qrcode"), {
            text: JSON.stringify(qrData, null, 2),
            width: 200,
            height: 200,
            colorDark: "#000000",
            colorLight: "#ffffff",
            correctLevel: QRCode.CorrectLevel.H
        });
    });
    </script>
</body>
</html> 