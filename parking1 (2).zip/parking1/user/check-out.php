<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';

// Check if user is logged in
if (!$auth->isLoggedIn()) {
    header('Location: ../login.php');
    exit();
}

$error = '';
$success = '';

// Get booking ID from URL
$booking_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$booking_id) {
    header('Location: my-bookings.php');
    exit();
}

// Get booking details
$stmt = $db->prepare("
    SELECT b.*, ps.slot_number, ps.floor, ps.type, v.vehicle_number, v.vehicle_type, v.vehicle_model,
           b.check_in_time, b.start_time, b.end_time
    FROM bookings b
    JOIN parking_slots ps ON b.slot_id = ps.id
    JOIN vehicles v ON b.vehicle_id = v.id
    WHERE b.id = ? AND b.user_id = ? AND b.status = 'active' AND b.check_in_time IS NOT NULL
");
$stmt->execute([$booking_id, $_SESSION['user_id']]);
$booking = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$booking) {
    header('Location: my-bookings.php');
    exit();
}

// Calculate parking fee
$start_time = new DateTime($booking['check_in_time']); // Use actual check-in time
$now = new DateTime(); // Current time for check-out
$end_time = new DateTime($booking['end_time']); // Original booking end time

// Ensure we're using the correct time for calculation
if ($now < $start_time) {
    // If current time is before check-in time, use the original end time
    $now = $end_time;
}

// Calculate actual parking duration
$interval = $start_time->diff($now);
$total_hours = ($interval->days * 24) + $interval->h;
if ($interval->i > 0 || $interval->s > 0) {
    $total_hours += 1; // Round up to the next hour for partial hours
}

// Regular parking fee
$regular_rate = 50; // K50 per hour
$regular_amount = $total_hours * $regular_rate;

// Calculate penalty if overdue
$penalty_hours = 0;
$penalty_amount = 0;
if ($now > $end_time) {
    $overdue_interval = $end_time->diff($now);
    $penalty_hours = ($overdue_interval->days * 24) + $overdue_interval->h;
    if ($overdue_interval->i > 0 || $overdue_interval->s > 0) {
        $penalty_hours += 1; // Round up to the next hour for partial hours
    }
    $penalty_amount = $penalty_hours * 100; // K100 per hour penalty
}

// Total amount including penalty
$total_amount = $regular_amount + $penalty_amount;

// Debug information to display
$debug_info = [
    'Booking ID' => $booking_id,
    'Check-in time' => $booking['check_in_time'],
    'Current time' => $now->format('Y-m-d H:i:s'),
    'Original end time' => $booking['end_time'],
    'Total hours' => $total_hours,
    'Days' => $interval->days,
    'Hours' => $interval->h,
    'Minutes' => $interval->i,
    'Seconds' => $interval->s,
    'Regular amount' => $regular_amount,
    'Penalty amount' => $penalty_amount,
    'Total amount' => $total_amount
];

// Update booking with new end time and amount
$stmt = $db->prepare("
    UPDATE bookings 
    SET end_time = NOW(), 
        amount = ?,
        penalty_amount = ?,
        total_amount = ?,
        check_out_time = NOW()
    WHERE id = ?
");
$stmt->execute([$regular_amount, $penalty_amount, $total_amount, $booking_id]);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $payment_method = $_POST['payment_method'] ?? '';
    $phone_number = $_POST['phone_number'] ?? '';

    if (empty($payment_method) || empty($phone_number)) {
        $error = 'Please fill in all required fields';
    } else {
        try {
            $db->beginTransaction();

            // Insert payment record first
            $stmt = $db->prepare("
                INSERT INTO payments (booking_id, amount, payment_method, phone_number, status)
                VALUES (?, ?, ?, ?, 'completed')
            ");
            $stmt->execute([
                $booking_id,
                $total_amount,
                $payment_method,
                $phone_number
            ]);
            $payment_id = $db->lastInsertId();

            // Update booking status to completed
            $stmt = $db->prepare("
                UPDATE bookings 
                SET status = 'completed'
                WHERE id = ?
            ");
            $stmt->execute([$booking_id]);

            // Update slot status to available
            $stmt = $db->prepare("
                UPDATE parking_slots 
                SET status = 'available' 
                WHERE id = ?
            ");
            $stmt->execute([$booking['slot_id']]);

            $db->commit();
            
            // Redirect to view receipt
            header('Location: view-receipt.php?id=' . $payment_id);
            exit();
        } catch (Exception $e) {
            $db->rollBack();
            $error = 'Payment failed: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Check Out - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            overflow: hidden;
            transition: transform 0.3s ease;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .card-header {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            padding: 1.5rem;
            border-bottom: none;
        }
        .card-header h4 {
            margin: 0;
            font-weight: 600;
        }
        .card-body {
            padding: 2rem;
        }
        .booking-details {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .booking-details h5 {
            color: #1e3c72;
            font-weight: 600;
            margin-bottom: 15px;
        }
        .booking-details p {
            margin-bottom: 10px;
            color: #495057;
        }
        .booking-details strong {
            color: #1e3c72;
        }
        .btn-primary {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            border: none;
            padding: 0.8rem 1.5rem;
            border-radius: 10px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(30, 60, 114, 0.3);
        }
        .btn-outline-secondary {
            border-radius: 10px;
            padding: 0.8rem 1.5rem;
            transition: all 0.3s ease;
        }
        .btn-outline-secondary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .alert {
            border-radius: 10px;
            border: none;
        }
        .form-control {
            border-radius: 10px;
            padding: 0.8rem 1rem;
            border: 2px solid #e9ecef;
            transition: all 0.3s ease;
        }
        .form-control:focus {
            border-color: #1e3c72;
            box-shadow: 0 0 0 0.2rem rgba(30, 60, 114, 0.25);
        }
        .form-label {
            font-weight: 500;
            color: #495057;
        }
        .checkout-summary {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .checkout-summary h5 {
            color: #1e3c72;
            font-weight: 600;
            margin-bottom: 15px;
        }
        .checkout-summary p {
            margin-bottom: 10px;
            color: #495057;
        }
        .checkout-summary strong {
            color: #1e3c72;
        }
        .duration-badge {
            display: inline-block;
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 500;
            background: #d4edda;
            color: #155724;
            margin-bottom: 15px;
        }
        .vehicle-info {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 20px;
        }
        .vehicle-info p {
            margin-bottom: 5px;
        }
        .vehicle-info strong {
            color: #1e3c72;
        }
    </style>
</head>
<body>
    <?php include '../includes/user-nav.php'; ?>
    
    <div class="main-content">
    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h4><i class="fas fa-sign-out-alt me-2"></i>Check Out</h4>
                    </div>
                    <div class="card-body">
                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>

                        <div class="mb-4">
                            <h5>Booking Details</h5>
                            <table class="table">
                                <tr>
                                    <th>Booking ID:</th>
                                    <td><?php echo htmlspecialchars($booking_id); ?></td>
                                </tr>
                                <tr>
                                    <th>Slot Number:</th>
                                    <td><?php echo htmlspecialchars($booking['slot_number']); ?></td>
                                </tr>
                                <tr>
                                    <th>Floor:</th>
                                    <td><?php echo htmlspecialchars($booking['floor']); ?></td>
                                </tr>
                                <tr>
                                    <th>Vehicle:</th>
                                    <td>
                                        <?php echo htmlspecialchars($booking['vehicle_number']); ?> - 
                                        <?php echo htmlspecialchars($booking['vehicle_type']); ?> 
                                        <?php echo htmlspecialchars($booking['vehicle_model']); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Duration:</th>
                                    <td>
                                        <?php 
                                        echo $total_hours . ' hours';
                                        if ($penalty_hours > 0) {
                                            echo ' (including ' . $penalty_hours . ' penalty hours)';
                                        }
                                        ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Regular Rate:</th>
                                    <td>K50.00 per hour</td>
                                </tr>
                                <tr>
                                    <th>Regular Amount:</th>
                                    <td>K<?php echo number_format($regular_amount, 2); ?></td>
                                </tr>
                                <?php if ($penalty_hours > 0): ?>
                                <tr>
                                    <th>Penalty Hours:</th>
                                    <td><?php echo $penalty_hours; ?> hours (K100 per hour)</td>
                                </tr>
                                <tr>
                                    <th>Penalty Amount:</th>
                                    <td class="text-danger">K<?php echo number_format($penalty_amount, 2); ?></td>
                                </tr>
                                <?php endif; ?>
                                <tr class="fw-bold">
                                    <th>Total Amount:</th>
                                    <td>K<?php echo number_format($total_amount, 2); ?></td>
                                </tr>
                            </table>
                        </div>

                        <form method="POST" action="">
                            <div class="mb-3">
                                <label class="form-label">Payment Method</label>
                                <select name="payment_method" class="form-select" required>
                                    <option value="">Select Payment Method</option>
                                    <option value="airtel_money">Airtel Money</option>
                                    <option value="mtn_money">MTN Money</option>
                                    <option value="zamtel_money">Zamtel Money</option>
                                    <option value="debit_card">Debit Card</option>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Phone Number</label>
                                <input type="tel" name="phone_number" class="form-control" required>
                            </div>

                            <div id="card-details" style="display: none;">
                                <div class="mb-3">
                                    <label class="form-label">Card Number</label>
                                    <input type="text" name="account_number" class="form-control">
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label">CVV</label>
                                            <input type="text" name="cvv" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label">Expiry Date</label>
                                            <input type="month" name="expiry_date" class="form-control">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">Pay K<?php echo number_format($total_amount, 2); ?></button>
                            </div>
                        </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Show/hide card details based on payment method
        document.querySelector('select[name="payment_method"]').addEventListener('change', function() {
            const cardDetails = document.getElementById('card-details');
            const accountNumber = document.querySelector('input[name="account_number"]');
            const cvv = document.querySelector('input[name="cvv"]');
            const expiryDate = document.querySelector('input[name="expiry_date"]');
            
            if (this.value === 'debit_card') {
                cardDetails.style.display = 'block';
                accountNumber.required = true;
                cvv.required = true;
                expiryDate.required = true;
            } else {
                cardDetails.style.display = 'none';
                accountNumber.required = false;
                cvv.required = false;
                expiryDate.required = false;
            }
        });
    </script>
</body>
</html> 