<?php
// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}
?>
<nav class="user-navbar">
    <div class="user-nav-container">
        <div class="user-nav-brand">
            <a href="dashboard.php">
                <i class="fas fa-parking"></i>
                <span><?php echo SITE_NAME; ?></span>
            </a>
        </div>
        
        <div class="user-nav-links">
            <?php if (basename($_SERVER['PHP_SELF']) !== 'dashboard.php'): ?>
                <a href="dashboard.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>">
                    <i class="fas fa-home"></i>
                    <span>Dashboard</span>
                </a>
                
                <a href="my-bookings.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'my-bookings.php' ? 'active' : ''; ?>">
                    <i class="fas fa-list"></i>
                    <span>My Bookings</span>
                </a>
                
                <a href="my-vehicles.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'my-vehicles.php' ? 'active' : ''; ?>">
                    <i class="fas fa-car"></i>
                    <span>My Vehicles</span>
                </a>
                
                <a href="profile.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'profile.php' ? 'active' : ''; ?>">
                    <i class="fas fa-user"></i>
                    <span>Profile</span>
                </a>
            <?php endif; ?>
            
            <a href="../logout.php" class="nav-link logout">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>
    </div>
</nav>

<style>
.user-navbar {
    background: linear-gradient(135deg, #2c3e50, #3498db);
    padding: 0.5rem 0;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    position: sticky;
    top: 0;
    z-index: 1000;
}

.user-nav-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 1rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.user-nav-brand {
    display: flex;
    align-items: center;
}

.user-nav-brand a {
    color: white;
    text-decoration: none;
    font-size: 1.5rem;
    font-weight: bold;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.user-nav-brand i {
    font-size: 1.8rem;
}

.user-nav-links {
    display: flex;
    gap: 1rem;
    align-items: center;
}

.nav-link {
    color: rgba(255, 255, 255, 0.8);
    text-decoration: none;
    padding: 0.5rem 1rem;
    border-radius: 5px;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    transition: all 0.3s ease;
}

.nav-link:hover {
    color: white;
    background: rgba(255, 255, 255, 0.1);
}

.nav-link.active {
    color: white;
    background: rgba(255, 255, 255, 0.2);
}

.nav-link.logout {
    color: #ff6b6b;
}

.nav-link.logout:hover {
    background: rgba(255, 107, 107, 0.1);
}

/* Mobile Menu Button */
.mobile-menu-btn {
    display: none;
    background: none;
    border: none;
    color: white;
    font-size: 1.5rem;
    cursor: pointer;
    padding: 0.5rem;
}

@media (max-width: 768px) {
    .mobile-menu-btn {
        display: block;
    }
    
    .user-nav-container {
        flex-direction: column;
        gap: 1rem;
    }
    
    .user-nav-links {
        display: none;
        width: 100%;
        flex-direction: column;
        align-items: flex-start;
        gap: 0.5rem;
    }
    
    .user-nav-links.active {
        display: flex;
    }
    
    .nav-link {
        width: 100%;
        padding: 0.75rem 1rem;
    }
    
    .user-nav-brand {
        width: 100%;
        justify-content: space-between;
    }
}

/* Animation for mobile menu */
@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.user-nav-links.active {
    animation: slideDown 0.3s ease-out;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const mobileMenuBtn = document.createElement('button');
    mobileMenuBtn.className = 'mobile-menu-btn';
    mobileMenuBtn.innerHTML = '<i class="fas fa-bars"></i>';
    
    const navLinks = document.querySelector('.user-nav-links');
    const navBrand = document.querySelector('.user-nav-brand');
    
    navBrand.appendChild(mobileMenuBtn);
    
    mobileMenuBtn.addEventListener('click', function() {
        navLinks.classList.toggle('active');
    });
});
</script> 