<?php
require_once 'db.php';

class Auth {
    private $db;
    
    public function __construct($db) {
        $this->db = $db;
    }
    
    public function register($name, $email, $nrc_passport, $phone, $city, $country, $password, $role) {
        try {
            // Check if user already exists
            $stmt = $this->db->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->rowCount() > 0) {
                return ['success' => false, 'message' => 'Email already exists'];
            }
            
            // Check if NRC/Passport already exists
            $stmt = $this->db->prepare("SELECT id FROM users WHERE nrc_passport = ?");
            $stmt->execute([$nrc_passport]);
            if ($stmt->rowCount() > 0) {
                return ['success' => false, 'message' => 'NRC/Passport number already exists'];
            }
            
            // Check if phone number already exists
            $stmt = $this->db->prepare("SELECT id FROM users WHERE phone = ?");
            $stmt->execute([$phone]);
            if ($stmt->rowCount() > 0) {
                return ['success' => false, 'message' => 'Phone number already exists'];
            }
            
            // Hash password
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            
            // Insert new user with all required fields
            $stmt = $this->db->prepare("
                INSERT INTO users (name, email, nrc_passport, phone, city, country, password, role, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
            ");
            $stmt->execute([$name, $email, $nrc_passport, $phone, $city, $country, $hashedPassword, $role]);
            
            return ['success' => true, 'message' => 'Registration successful'];
        } catch(PDOException $e) {
            return ['success' => false, 'message' => 'Registration failed: ' . $e->getMessage()];
        }
    }
    
    public function login($email, $password) {
        try {
            $stmt = $this->db->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['user_role'] = $user['role'];
                return true;
            }
            
            return false;
        } catch (PDOException $e) {
            return false;
        }
    }
    
    public function logout() {
        session_destroy();
        header('Location: login.php');
        exit();
    }
    
    public function isLoggedIn() {
        return isset($_SESSION['user_id']);
    }
    
    public function isAdmin() {
        return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
    }
    
    public function getCurrentUser() {
        if ($this->isLoggedIn()) {
            try {
                $stmt = $this->db->prepare("
                    SELECT id, name, email, nrc_passport, phone, city, country, role 
                    FROM users 
                    WHERE id = ?
                ");
                $stmt->execute([$_SESSION['user_id']]);
                return $stmt->fetch(PDO::FETCH_ASSOC);
            } catch (PDOException $e) {
                return null;
            }
        }
        return null;
    }

    public function isMaintenanceMode() {
        return isset($_SESSION['settings']['maintenance_mode']) && $_SESSION['settings']['maintenance_mode'] == '1';
    }

    public function checkMaintenanceMode() {
        if ($this->isMaintenanceMode() && !$this->isAdmin()) {
            header('Location: maintenance.php');
            exit();
        }
    }
}

// Create auth instance
$auth = new Auth($db);
?> 