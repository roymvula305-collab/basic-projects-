<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';

// Check if user is already logged in
if ($auth->isLoggedIn()) {
    if ($auth->isAdmin()) {
        header('Location: admin/dashboard.php');
    } else {
        header('Location: user/dashboard.php');
    }
    exit();
}

// Get parking statistics
$db = new Database();
$conn = $db->getConnection();

// Get total slots and available slots
$stmt = $conn->query("SELECT COUNT(*) as total FROM parking_slots");
$total_slots = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

$stmt = $conn->query("SELECT COUNT(*) as available FROM parking_slots WHERE status = 'available'");
$available_slots = $stmt->fetch(PDO::FETCH_ASSOC)['available'];
$occupied_slots = $total_slots - $available_slots;

// Get handicap slots statistics
$stmt = $conn->query("SELECT COUNT(*) as total FROM parking_slots WHERE type = 'handicap'");
$total_handicap = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

$stmt = $conn->query("SELECT COUNT(*) as available FROM parking_slots WHERE type = 'handicap' AND status = 'available'");
$available_handicap = $stmt->fetch(PDO::FETCH_ASSOC)['available'];
$occupied_handicap = $total_handicap - $available_handicap;

// Get today's bookings
$stmt = $conn->query("SELECT COUNT(*) as total FROM bookings WHERE DATE(created_at) = CURDATE()");
$today_bookings = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

// Get active bookings
$stmt = $conn->query("SELECT COUNT(*) as total FROM bookings WHERE status = 'active'");
$active_bookings = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

// Get popular parking times
$stmt = $conn->query("
    SELECT HOUR(start_time) as hour, COUNT(*) as count 
    FROM bookings 
    WHERE status = 'completed' 
    GROUP BY HOUR(start_time) 
    ORDER BY count DESC 
    LIMIT 5
");
$popular_times = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get average parking duration
$stmt = $conn->query("
    SELECT AVG(TIMESTAMPDIFF(HOUR, start_time, end_time)) as avg_duration 
    FROM bookings 
    WHERE status = 'completed'
");
$avg_duration = round($stmt->fetch(PDO::FETCH_ASSOC)['avg_duration'], 1);

// Get recent announcements
$stmt = $conn->query("
    SELECT * FROM announcements 
    WHERE expires_at IS NULL OR expires_at > NOW()
    ORDER BY created_at DESC 
    LIMIT 3
");
$recent_announcements = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <style>
        .hero-section {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            padding: 100px 0;
            position: relative;
            overflow: hidden;
        }
        .hero-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('assets/images/pattern.png') repeat;
            opacity: 0.1;
            animation: movePattern 20s linear infinite;
        }
        @keyframes movePattern {
            0% { background-position: 0 0; }
            100% { background-position: 100% 100%; }
        }
        .stats-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        .stats-card::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(45deg, transparent, rgba(255,255,255,0.1), transparent);
            transform: translateX(-100%);
            transition: transform 0.6s ease;
        }
        .stats-card:hover::after {
            transform: translateX(100%);
        }
        .stats-card:hover {
            transform: translateY(-5px) scale(1.02);
        }
        .stats-icon {
            font-size: 2.5rem;
            margin-bottom: 15px;
        }
        .handicap-section {
            background: #f8f9fa;
            padding: 50px 0;
        }
        .feature-card {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            text-align: center;
            margin-bottom: 30px;
            transition: transform 0.3s ease;
        }
        .feature-card:hover {
            transform: translateY(-5px);
        }
        .feature-icon {
            font-size: 2.5rem;
            color: #1e3c72;
            margin-bottom: 20px;
        }
        .availability-badge {
            font-size: 0.9rem;
            padding: 5px 10px;
            border-radius: 20px;
        }
        .cta-section {
            background: #f8f9fa;
            padding: 80px 0;
        }
        .popular-times {
            background: #f8f9fa;
            padding: 50px 0;
        }
        .time-bar {
            height: 30px;
            background: #e9ecef;
            border-radius: 15px;
            margin-bottom: 10px;
            overflow: hidden;
        }
        .time-fill {
            height: 100%;
            background: #1e3c72;
            border-radius: 15px;
        }
        .announcement-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .announcement-date {
            font-size: 0.9rem;
            color: #6c757d;
        }
        .pricing-section {
            background: white;
            padding: 50px 0;
        }
        .pricing-card {
            border: 1px solid #dee2e6;
            border-radius: 10px;
            padding: 30px;
            text-align: center;
            transition: transform 0.3s ease;
        }
        .pricing-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .pricing-header {
            margin-bottom: 20px;
        }
        .pricing-amount {
            font-size: 2.5rem;
            font-weight: bold;
            color: #1e3c72;
        }
        .pricing-period {
            color: #6c757d;
        }
        .testimonial-section {
            background: #f8f9fa;
            padding: 80px 0;
        }
        .testimonial-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            margin: 20px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            position: relative;
        }
        .testimonial-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 8px 15px rgba(0,0,0,0.1);
        }
        .testimonial-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            margin: 0 auto 20px;
            overflow: hidden;
            border: 3px solid #1e3c72;
        }
        .testimonial-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .testimonial-quote {
            font-size: 1.2rem;
            color: #6c757d;
            margin-bottom: 20px;
            position: relative;
        }
        .testimonial-quote::before {
            content: '"';
            font-size: 4rem;
            color: #1e3c72;
            opacity: 0.2;
            position: absolute;
            top: -20px;
            left: -10px;
        }
        .how-it-works {
            padding: 80px 0;
            background: white;
        }
        .step-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            margin: 20px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            position: relative;
            text-align: center;
        }
        .step-number {
            width: 50px;
            height: 50px;
            background: #1e3c72;
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            font-weight: bold;
            margin: 0 auto 20px;
        }
        .step-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 8px 15px rgba(0,0,0,0.1);
        }
        .parking-types {
            padding: 80px 0;
            background: #f8f9fa;
        }
        .type-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            margin: 20px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            text-align: center;
        }
        .type-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 8px 15px rgba(0,0,0,0.1);
        }
        .type-icon {
            font-size: 3rem;
            color: #1e3c72;
            margin-bottom: 20px;
        }
        .fade-in {
            opacity: 0;
            transform: translateY(20px);
            transition: all 0.6s ease;
        }
        .fade-in.visible {
            opacity: 1;
            transform: translateY(0);
        }
        body {
            padding-top: 76px;
        }
        .navbar {
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .navbar-brand {
            font-weight: 600;
            font-size: 1.5rem;
        }
        .nav-link {
            font-weight: 500;
            padding: 0.5rem 1rem;
            transition: color 0.3s ease;
        }
        .nav-link:hover {
            color: #fff !important;
        }
    </style>
    <script>
        // Intersection Observer for fade-in animations
        document.addEventListener('DOMContentLoaded', function() {
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('visible');
                    }
                });
            }, {
                threshold: 0.1
            });

            document.querySelectorAll('.fade-in').forEach((el) => observer.observe(el));
        });
    </script>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center" href="index.php">
                <i class="fas fa-parking me-2"></i>
                <?php echo SITE_NAME; ?>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#features">Features</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#pricing">Pricing</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#contact">Contact</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="btn btn-primary ms-2" href="register.php">Register</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <h1 class="display-4 fw-bold mb-4">Smart Parking Solutions</h1>
                    <p class="lead mb-4">Find and book parking slots with ease. Real-time availability and instant booking.</p>
                    <div class="cta-buttons">
                        <a href="register.php" class="btn btn-primary btn-lg me-3">Get Started</a>
                        <a href="#features" class="btn btn-outline-light btn-lg">Learn More</a>
                    </div>
                </div>
                <div class="col-lg-6">
                    <img src="assets/images/parking-hero.png" alt="Parking System" class="img-fluid">
                </div>
            </div>
        </div>
    </section>

    <!-- Statistics Section -->
    <section class="py-5">
        <div class="container">
            <h2 class="text-center mb-5">Real-time Parking Statistics</h2>
            <div class="row">
                <div class="col-md-3">
                    <div class="stats-card text-center">
                        <i class="fas fa-parking stats-icon text-primary"></i>
                        <h3><?php echo $total_slots; ?></h3>
                        <p class="text-muted">Total Parking Slots</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stats-card text-center">
                        <i class="fas fa-check-circle stats-icon text-success"></i>
                        <h3><?php echo $available_slots; ?></h3>
                        <p class="text-muted">Available Slots</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stats-card text-center">
                        <i class="fas fa-car stats-icon text-danger"></i>
                        <h3><?php echo $occupied_slots; ?></h3>
                        <p class="text-muted">Occupied Slots</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stats-card text-center">
                        <i class="fas fa-calendar-check stats-icon text-info"></i>
                        <h3><?php echo $today_bookings; ?></h3>
                        <p class="text-muted">Today's Bookings</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Handicap Section -->
    <section class="handicap-section">
        <div class="container">
            <h2 class="text-center mb-5">Handicap Parking Availability</h2>
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <div class="stats-card text-center">
                        <i class="fas fa-wheelchair stats-icon text-primary"></i>
                        <h3><?php echo $total_handicap; ?> Handicap Slots</h3>
                        <p class="mb-3"><?php echo $available_handicap; ?> slots available</p>
                        <span class="availability-badge <?php echo $available_handicap > 0 ? 'bg-success' : 'bg-danger'; ?> text-white">
                            <?php echo $available_handicap > 0 ? 'Slots Available' : 'No Slots Available'; ?>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section id="features" class="py-5">
        <div class="container">
            <h2 class="text-center mb-5">Key Features</h2>
            <div class="row">
                <div class="col-md-4">
                    <div class="feature-card">
                        <i class="fas fa-calendar-check feature-icon"></i>
                        <h3>Easy Booking</h3>
                        <p>Book your parking slot in advance and avoid last-minute hassles.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="feature-card">
                        <i class="fas fa-qrcode feature-icon"></i>
                        <h3>QR Code Entry</h3>
                        <p>Quick entry using QR codes for a seamless parking experience.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="feature-card">
                        <i class="fas fa-chart-line feature-icon"></i>
                        <h3>Real-time Updates</h3>
                        <p>Get real-time information about parking slot availability.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta-section">
        <div class="container text-center">
            <h2 class="mb-4">Ready to Park Smart?</h2>
            <p class="lead mb-4">Join thousands of satisfied customers who trust our parking system.</p>
            <a href="register.php" class="btn btn-primary btn-lg">Create Your Account Now</a>
        </div>
    </section>

    <!-- Popular Times Section -->
    <section class="popular-times">
        <div class="container">
            <h2 class="text-center mb-5">Popular Parking Times</h2>
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <?php foreach ($popular_times as $time): ?>
                        <div class="mb-3">
                            <div class="d-flex justify-content-between mb-2">
                                <span><?php echo date('h:i A', strtotime($time['hour'] . ':00')); ?></span>
                                <span><?php echo $time['count']; ?> bookings</span>
                            </div>
                            <div class="time-bar">
                                <div class="time-fill" style="width: <?php echo ($time['count'] / max(array_column($popular_times, 'count'))) * 100; ?>%"></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                    <p class="text-center mt-4">
                        Average parking duration: <?php echo $avg_duration; ?> hours
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- Announcements Section -->
    <section class="py-5">
        <div class="container">
            <h2 class="text-center mb-5">Latest Updates</h2>
            <div class="row">
                <?php foreach ($recent_announcements as $announcement): ?>
                    <div class="col-md-4">
                        <div class="announcement-card">
                            <h4><?php echo htmlspecialchars($announcement['title']); ?></h4>
                            <p class="announcement-date">
                                <?php echo date('M d, Y', strtotime($announcement['created_at'])); ?>
                            </p>
                            <p><?php echo htmlspecialchars($announcement['message']); ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Smart Parking Features -->
    <section class="py-5 bg-light">
        <div class="container">
            <h2 class="text-center mb-5">Smart Parking Features</h2>
            <div class="row">
                <div class="col-md-4">
                    <div class="feature-card">
                        <i class="fas fa-map-marker-alt feature-icon"></i>
                        <h3>Smart Navigation</h3>
                        <p>Find the nearest available parking slot with our intelligent navigation system.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="feature-card">
                        <i class="fas fa-clock feature-icon"></i>
                        <h3>Time Management</h3>
                        <p>Set your parking duration and get reminders before your time expires.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="feature-card">
                        <i class="fas fa-shield-alt feature-icon"></i>
                        <h3>Secure Parking</h3>
                        <p>24/7 security monitoring and surveillance for your peace of mind.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Benefits Section -->
    <section class="py-5">
        <div class="container">
            <h2 class="text-center mb-5">Why Choose Our Parking System?</h2>
            <div class="row">
                <div class="col-md-6">
                    <div class="benefit-item mb-4">
                        <i class="fas fa-check-circle text-success me-2"></i>
                        <span>Real-time slot availability updates</span>
                    </div>
                    <div class="benefit-item mb-4">
                        <i class="fas fa-check-circle text-success me-2"></i>
                        <span>Easy booking and cancellation process</span>
                    </div>
                    <div class="benefit-item mb-4">
                        <i class="fas fa-check-circle text-success me-2"></i>
                        <span>Dedicated handicap parking spaces</span>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="benefit-item mb-4">
                        <i class="fas fa-check-circle text-success me-2"></i>
                        <span>Multiple vehicle registration support</span>
                    </div>
                    <div class="benefit-item mb-4">
                        <i class="fas fa-check-circle text-success me-2"></i>
                        <span>Instant booking confirmation</span>
                    </div>
                    <div class="benefit-item mb-4">
                        <i class="fas fa-check-circle text-success me-2"></i>
                        <span>Regular maintenance and cleaning</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- How It Works Section -->
    <section class="how-it-works">
        <div class="container">
            <h2 class="text-center mb-5 fade-in">How It Works</h2>
            <div class="row">
                <div class="col-md-4 fade-in">
                    <div class="step-card">
                        <div class="step-number">1</div>
                        <h3>Find a Parking Spot</h3>
                        <p>Browse available parking slots in real-time and choose your preferred location.</p>
                        <i class="fas fa-search-location fa-3x text-primary mt-3"></i>
                    </div>
                </div>
                <div class="col-md-4 fade-in">
                    <div class="step-card">
                        <div class="step-number">2</div>
                        <h3>Book Your Slot</h3>
                        <p>Select your vehicle and time slot, then confirm your booking instantly.</p>
                        <i class="fas fa-calendar-check fa-3x text-primary mt-3"></i>
                    </div>
                </div>
                <div class="col-md-4 fade-in">
                    <div class="step-card">
                        <div class="step-number">3</div>
                        <h3>Park with Ease</h3>
                        <p>Arrive at your reserved spot and enjoy hassle-free parking.</p>
                        <i class="fas fa-parking fa-3x text-primary mt-3"></i>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Parking Types Section -->
    <section class="parking-types">
        <div class="container">
            <h2 class="text-center mb-5 fade-in">Parking Types</h2>
            <div class="row">
                <div class="col-md-4 fade-in">
                    <div class="type-card">
                        <i class="fas fa-wheelchair type-icon"></i>
                        <h3>Handicap Parking</h3>
                        <p>Dedicated spaces for people with disabilities, located near building entrances.</p>
                    </div>
                </div>
                <div class="col-md-4 fade-in">
                    <div class="type-card">
                        <i class="fas fa-bolt type-icon"></i>
                        <h3>Electric Vehicle</h3>
                        <p>Charging stations available for electric vehicles.</p>
                    </div>
                </div>
                <div class="col-md-4 fade-in">
                    <div class="type-card">
                        <i class="fas fa-car type-icon"></i>
                        <h3>Regular Parking</h3>
                        <p>Standard parking spaces for all types of vehicles.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-dark text-light py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-4 mb-lg-0">
                    <h5 class="mb-4"><?php echo SITE_NAME; ?></h5>
                    <p class="mb-4">Making parking management simple and efficient for everyone.</p>
                    <div class="social-links">
                        <a href="#" class="text-light me-3"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="text-light me-3"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="text-light me-3"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="text-light"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
                <div class="col-lg-2 col-md-4 mb-4 mb-md-0">
                    <h6 class="mb-4">Quick Links</h6>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="index.php" class="text-light text-decoration-none">Home</a></li>
                        <li class="mb-2"><a href="#features" class="text-light text-decoration-none">Features</a></li>
                        <li class="mb-2"><a href="#pricing" class="text-light text-decoration-none">Pricing</a></li>
                        <li class="mb-2"><a href="#contact" class="text-light text-decoration-none">Contact</a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-md-4 mb-4 mb-md-0">
                    <h6 class="mb-4">Services</h6>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="#" class="text-light text-decoration-none">Parking Booking</a></li>
                        <li class="mb-2"><a href="#" class="text-light text-decoration-none">Subscription Plans</a></li>
                        <li class="mb-2"><a href="#" class="text-light text-decoration-none">Business Solutions</a></li>
                        <li class="mb-2"><a href="#" class="text-light text-decoration-none">Support</a></li>
                    </ul>
                </div>
                <div class="col-lg-4 col-md-4">
                    <h6 class="mb-4">Contact Us</h6>
                    <ul class="list-unstyled">
                        <li class="mb-2">
                            <i class="fas fa-map-marker-alt me-2"></i>
                            123 Parking Street, City
                        </li>
                        <li class="mb-2">
                            <i class="fas fa-phone me-2"></i>
                            +1 234 567 890
                        </li>
                        <li class="mb-2">
                            <i class="fas fa-envelope me-2"></i>
                            info@parkingsystem.com
                        </li>
                    </ul>
                </div>
            </div>
            <hr class="my-4">
            <div class="row">
                <div class="col-md-6 text-center text-md-start">
                    <p class="mb-0">&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. All rights reserved.</p>
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <a href="#" class="text-light text-decoration-none me-3">Privacy Policy</a>
                    <a href="#" class="text-light text-decoration-none">Terms of Service</a>
                </div>
            </div>
        </div>
    </footer>

    <style>
        footer {
            background: linear-gradient(135deg, #1a1a1a 0%, #2a2a2a 100%);
        }
        footer a {
            transition: color 0.3s ease;
        }
        footer a:hover {
            color: #fff !important;
            opacity: 0.8;
        }
        .social-links a {
            display: inline-block;
            width: 36px;
            height: 36px;
            line-height: 36px;
            text-align: center;
            background: rgba(255,255,255,0.1);
            border-radius: 50%;
            transition: all 0.3s ease;
        }
        .social-links a:hover {
            background: #007bff;
            transform: translateY(-3px);
        }
        footer hr {
            border-color: rgba(255,255,255,0.1);
        }
    </style>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html> 