-- Create database
CREATE DATABASE IF NOT EXISTS parking_system;
USE parking_system;

-- Create users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    nrc_passport VARCHAR(50) UNIQUE,
    phone VARCHAR(20) UNIQUE,
    city VARCHAR(100),
    country VARCHAR(100),
    password VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    profile_picture VARCHAR(255) DEFAULT NULL,
    role ENUM('user', 'admin', 'guard') DEFAULT 'user',
    reset_token VARCHAR(64) DEFAULT NULL,
    reset_token_expires DATETIME DEFAULT NULL,
    last_login DATETIME DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Create vehicles table
CREATE TABLE IF NOT EXISTS vehicles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    vehicle_number VARCHAR(20) NOT NULL,
    vehicle_type ENUM('car', 'motorcycle', 'truck') NOT NULL,
    vehicle_model VARCHAR(100) NOT NULL,
    vehicle_color VARCHAR(50) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Create parking_slots table
CREATE TABLE IF NOT EXISTS parking_slots (
    id INT AUTO_INCREMENT PRIMARY KEY,
    slot_number VARCHAR(10) NOT NULL,
    floor INT NOT NULL,
    type ENUM('regular', 'handicap', 'electric') NOT NULL DEFAULT 'regular',
    status ENUM('available', 'occupied', 'maintenance') NOT NULL DEFAULT 'available',
    x_coordinate INT NOT NULL DEFAULT 0,
    y_coordinate INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_slot (floor, slot_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create bookings table
CREATE TABLE IF NOT EXISTS bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    slot_id INT NOT NULL,
    vehicle_id INT NOT NULL,
    start_time DATETIME NOT NULL,
    end_time DATETIME,
    status ENUM('pending', 'active', 'completed', 'cancelled') DEFAULT 'pending',
    amount DECIMAL(10,2) DEFAULT 0.00,
    penalty_amount DECIMAL(10,2) DEFAULT 0.00,
    total_amount DECIMAL(10,2) DEFAULT 0.00,
    check_in_time DATETIME,
    check_out_time DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (slot_id) REFERENCES parking_slots(id) ON DELETE CASCADE,
    FOREIGN KEY (vehicle_id) REFERENCES vehicles(id)
);

-- Create payments table
CREATE TABLE IF NOT EXISTS payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_method ENUM('airtel_money', 'mtn_money', 'zamtel_money') NOT NULL,
    account_number VARCHAR(20) NOT NULL,
    cvv VARCHAR(3) NOT NULL,
    expiry_date DATE NOT NULL,
    phone_number VARCHAR(15) NOT NULL,
    status ENUM('pending', 'completed', 'failed', 'refunded') DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (booking_id) REFERENCES bookings(id)
);

-- Create settings table
CREATE TABLE IF NOT EXISTS settings (
    setting_key VARCHAR(50) PRIMARY KEY,
    setting_value TEXT NOT NULL
);

-- Create announcements table
CREATE TABLE IF NOT EXISTS announcements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    recipient_type ENUM('all', 'specific') NOT NULL DEFAULT 'all',
    recipient_id INT,
    created_at DATETIME NOT NULL,
    expires_at DATETIME,
    duration_days INT DEFAULT NULL,
    FOREIGN KEY (recipient_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create announcement_reads table
CREATE TABLE IF NOT EXISTS announcement_reads (
    id INT AUTO_INCREMENT PRIMARY KEY,
    announcement_id INT NOT NULL,
    user_id INT NOT NULL,
    read_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (announcement_id) REFERENCES announcements(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_announcement_user (announcement_id, user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create user_login_history table
CREATE TABLE IF NOT EXISTS user_login_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    login_time DATETIME NOT NULL,
    status ENUM('success', 'failed') NOT NULL,
    ip_address VARCHAR(45),
    user_agent TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Insert default admin user
INSERT INTO users (email, password, name, role) VALUES 
('admin@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Admin User', 'admin');

-- Insert parking slots for Floor 1 (Ground Floor)
INSERT INTO parking_slots (slot_number, floor, type, x_coordinate, y_coordinate) VALUES
-- Row 1: Handicap slots closest to building entrance (x=0)
('1A', 1, 'handicap', 0, 0),
('1B', 1, 'handicap', 0, 1),
('1C', 1, 'handicap', 0, 2),
('1D', 1, 'handicap', 0, 3),
-- Row 2: Regular slots
('2A', 1, 'regular', 1, 0),
('2B', 1, 'regular', 1, 1),
('2C', 1, 'regular', 1, 2),
('2D', 1, 'regular', 1, 3),
-- Row 3: Electric vehicle slots
('3A', 1, 'electric', 2, 0),
('3B', 1, 'electric', 2, 1),
('3C', 1, 'electric', 2, 2),
('3D', 1, 'electric', 2, 3),
-- Row 4: Regular slots
('4A', 1, 'regular', 3, 0),
('4B', 1, 'regular', 3, 1),
('4C', 1, 'regular', 3, 2),
('4D', 1, 'regular', 3, 3),
-- Row 5: Regular slots
('5A', 1, 'regular', 4, 0),
('5B', 1, 'regular', 4, 1),
('5C', 1, 'regular', 4, 2),
('5D', 1, 'regular', 4, 3);

-- Insert parking slots for Floor 2
INSERT INTO parking_slots (slot_number, floor, type, x_coordinate, y_coordinate) VALUES
-- Row 1: Handicap slots closest to building entrance (x=0)
('1E', 2, 'handicap', 0, 0),
('1F', 2, 'handicap', 0, 1),
('1G', 2, 'handicap', 0, 2),
('1H', 2, 'handicap', 0, 3),
-- Row 2: Regular slots
('2E', 2, 'regular', 1, 0),
('2F', 2, 'regular', 1, 1),
('2G', 2, 'regular', 1, 2),
('2H', 2, 'regular', 1, 3),
-- Row 3: Electric vehicle slots
('3E', 2, 'electric', 2, 0),
('3F', 2, 'electric', 2, 1),
('3G', 2, 'electric', 2, 2),
('3H', 2, 'electric', 2, 3),
-- Row 4: Regular slots
('4E', 2, 'regular', 3, 0),
('4F', 2, 'regular', 3, 1),
('4G', 2, 'regular', 3, 2),
('4H', 2, 'regular', 3, 3),
-- Row 5: Regular slots
('5E', 2, 'regular', 4, 0),
('5F', 2, 'regular', 4, 1),
('5G', 2, 'regular', 4, 2),
('5H', 2, 'regular', 4, 3);

-- Insert default settings
INSERT INTO settings (setting_key, setting_value) VALUES
('regular_rate', '5.00'),
('handicap_rate', '3.00'),
('electric_rate', '4.00'),
('email_notifications', '1'),
('sms_notifications', '0'),
('notification_email', ''),
('site_name', 'Parking Management System'),
('site_description', 'A modern parking management system'),
('maintenance_mode', '0'); 