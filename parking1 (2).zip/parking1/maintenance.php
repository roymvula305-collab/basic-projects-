<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';

$auth = new Auth($db);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maintenance Mode - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem;
        }
        .maintenance-container {
            max-width: 600px;
            width: 100%;
            text-align: center;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .card-body {
            padding: 3rem;
        }
        .maintenance-icon {
            font-size: 4rem;
            color: #ffc107;
            margin-bottom: 1.5rem;
        }
        h1 {
            color: #1e3c72;
            margin-bottom: 1rem;
        }
        p {
            color: #6c757d;
            margin-bottom: 2rem;
        }
        .btn-primary {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            border: none;
            padding: 0.8rem 1.5rem;
            border-radius: 10px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(30, 60, 114, 0.3);
        }
    </style>
</head>
<body>
    <div class="maintenance-container">
        <div class="card fade-in">
            <div class="card-body">
                <i class="fas fa-tools maintenance-icon"></i>
                <h1>System Maintenance</h1>
                <p>We are currently performing scheduled maintenance on our system. During this time, the system will be unavailable to regular users. We apologize for any inconvenience this may cause.</p>
                <p>Expected completion time: <?php echo date('F j, Y, g:i a', strtotime('+2 hours')); ?></p>
                <?php if ($auth->isAdmin()): ?>
                    <a href="admin/dashboard.php" class="btn btn-primary">
                        <i class="fas fa-cog me-2"></i>Admin Dashboard
                    </a>
                <?php else: ?>
                    <a href="index.php" class="btn btn-primary">
                        <i class="fas fa-home me-2"></i>Back to Home
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 