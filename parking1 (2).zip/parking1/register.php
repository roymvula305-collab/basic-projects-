<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $nrc_passport = $_POST['nrc_passport'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $city = $_POST['city'] ?? '';
    $country = $_POST['country'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $role = $_POST['role'] ?? 'user';
    
    // Vehicle details
    $vehicle_number = $_POST['vehicle_number'] ?? '';
    $vehicle_type = $_POST['vehicle_type'] ?? '';
    $vehicle_model = $_POST['vehicle_model'] ?? '';
    $vehicle_color = $_POST['vehicle_color'] ?? '';
    
    // Handle profile picture upload
    $profile_picture = null;
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        $file_type = $_FILES['profile_picture']['type'];
        
        if (!in_array($file_type, $allowed_types)) {
            $error = "Only JPG, PNG and GIF files are allowed for profile picture.";
        } else {
            $file_name = uniqid() . '_' . $_FILES['profile_picture']['name'];
            $upload_dir = 'uploads/profile_pictures/';
            
            // Create directory if it doesn't exist
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            $target_path = $upload_dir . $file_name;
            
            if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $target_path)) {
                $profile_picture = $target_path;
            } else {
                $error = "Failed to upload profile picture.";
            }
        }
    }
    
    // Validate password
    $password_errors = [];
    if (strlen($password) < 8) {
        $password_errors[] = "Password must be at least 8 characters long";
    }
    if (!preg_match('/[A-Z]/', $password)) {
        $password_errors[] = "Password must contain at least one uppercase letter";
    }
    if (!preg_match('/[a-z]/', $password)) {
        $password_errors[] = "Password must contain at least one lowercase letter";
    }
    if (!preg_match('/[0-9]/', $password)) {
        $password_errors[] = "Password must contain at least one number";
    }
    if (!preg_match('/[^A-Za-z0-9]/', $password)) {
        $password_errors[] = "Password must contain at least one special character";
    }

    if (empty($password_errors) && empty($error)) {
        if ($password === $confirm_password) {
            try {
                // Start transaction
                $db->beginTransaction();
                
                // Register user with all fields including profile picture
                $stmt = $db->prepare("
                    INSERT INTO users (name, email, nrc_passport, phone, city, country, password, role, profile_picture)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                
                $stmt->execute([
                    $name,
                    $email,
                    $nrc_passport,
                    $phone,
                    $city,
                    $country,
                    $hashed_password,
                    $role,
                    $profile_picture
                ]);
                
                $user_id = $db->lastInsertId();
                    
                    if ($user_id) {
                    // Register vehicle
                        $stmt = $db->prepare("
                            INSERT INTO vehicles (user_id, vehicle_number, vehicle_type, vehicle_model, vehicle_color)
                            VALUES (?, ?, ?, ?, ?)
                        ");
                        $stmt->execute([
                            $user_id,
                            $vehicle_number,
                            $vehicle_type,
                            $vehicle_model,
                            $vehicle_color
                        ]);
                        
                        // Commit transaction
                        $db->commit();
                        
                    $success = "Registration successful! You can now login.";
                        // Redirect to login page after 2 seconds
                        header("refresh:2;url=login.php");
                    } else {
                        throw new Exception("Failed to get user ID after registration");
                }
            } catch (Exception $e) {
                $db->rollBack();
                // If profile picture was uploaded, delete it
                if ($profile_picture && file_exists($profile_picture)) {
                    unlink($profile_picture);
                }
                $error = $e->getMessage();
            }
        } else {
            $error = "Passwords do not match";
        }
    } else if (!empty($password_errors)) {
        $error = implode("<br>", $password_errors);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            padding: 2rem 0;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .card-header {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            padding: 2rem;
            text-align: center;
            border-bottom: none;
        }
        .card-header h3 {
            margin: 0;
            font-weight: 600;
        }
        .card-body {
            padding: 2rem;
        }
        .form-control {
            border-radius: 10px;
            padding: 0.8rem 1rem;
            border: 2px solid #e9ecef;
            transition: all 0.3s ease;
        }
        .form-control:focus {
            border-color: #1e3c72;
            box-shadow: 0 0 0 0.2rem rgba(30, 60, 114, 0.25);
        }
        .btn-primary {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            border: none;
            padding: 0.8rem;
            border-radius: 10px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(30, 60, 114, 0.3);
        }
        .profile-picture-preview {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            margin: 10px auto;
            border: 3px solid #1e3c72;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            transition: all 0.3s ease;
        }
        .profile-picture-preview:hover {
            transform: scale(1.05);
        }
        .profile-picture-container {
            text-align: center;
            margin-bottom: 30px;
            padding: 20px;
            background: rgba(30, 60, 114, 0.05);
            border-radius: 15px;
        }
        .section-title {
            color: #1e3c72;
            font-weight: 600;
            margin-bottom: 1.5rem;
            padding-bottom: 0.5rem;
            border-bottom: 2px solid rgba(30, 60, 114, 0.1);
        }
        .input-group-text {
            border-radius: 10px 0 0 10px;
            background: #f8f9fa;
            border: 2px solid #e9ecef;
            border-right: none;
        }
        .input-group .form-control {
            border-radius: 0 10px 10px 0;
        }
        .registration-footer {
            text-align: center;
            margin-top: 2rem;
            padding-top: 1rem;
            border-top: 1px solid rgba(0,0,0,0.1);
        }
        .registration-footer a {
            color: #1e3c72;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        .registration-footer a:hover {
            color: #2a5298;
        }
        .form-label {
            font-weight: 500;
            color: #495057;
        }
        .alert {
            border-radius: 10px;
            border: none;
        }
        .btn-outline-secondary {
            border-radius: 10px;
            padding: 0.8rem;
            transition: all 0.3s ease;
        }
        .btn-outline-secondary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center mt-5">
            <div class="col-md-8">
                <div class="card fade-in">
                    <div class="card-header">
                        <h3>Create Your Account</h3>
                        <p class="mb-0">Join our parking community today</p>
                    </div>
                    <div class="card-body">
                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        
                        <?php if ($success): ?>
                            <div class="alert alert-success"><?php echo $success; ?></div>
                        <?php endif; ?>
                        
                        <form method="POST" action="" enctype="multipart/form-data">
                            <h5 class="section-title">
                                <i class="fas fa-user-circle me-2"></i>Personal Information
                            </h5>
                            
                            <div class="profile-picture-container">
                                <img src="assets/images/default-profile.png" alt="Profile Picture Preview" class="profile-picture-preview" id="profilePicturePreview">
                            <div class="mb-3">
                                    <label for="profile_picture" class="form-label">Profile Picture</label>
                                    <input type="file" class="form-control" id="profile_picture" name="profile_picture" accept="image/*" onchange="previewImage(this)">
                                    <div class="form-text">Allowed formats: JPG, PNG, GIF. Max size: 2MB</div>
                                </div>
                            </div>
                            
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-user"></i></span>
                                <input type="text" class="form-control" id="name" name="name" required>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email address</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            <div class="mb-3">
                                <label for="nrc_passport" class="form-label">NRC/Passport Number</label>
                                <input type="text" class="form-control" id="nrc_passport" name="nrc_passport" required>
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="form-label">Phone Number</label>
                                <input type="tel" class="form-control" id="phone" name="phone" required>
                            </div>
                            <div class="mb-3">
                                <label for="city" class="form-label">City</label>
                                <input type="text" class="form-control" id="city" name="city" required>
                            </div>
                            <div class="mb-3">
                                <label for="country" class="form-label">Country</label>
                                <input type="text" class="form-control" id="country" name="country" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Password</label>
                                <div class="input-group">
                                    <input type="password" name="password" class="form-control" id="password" required>
                                    <button class="btn btn-outline-secondary" type="button" onclick="togglePassword('password')">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                                <div class="form-text">
                                    Password must contain:
                                    <ul class="mb-0">
                                        <li>At least 8 characters</li>
                                        <li>At least one uppercase letter</li>
                                        <li>At least one lowercase letter</li>
                                        <li>At least one number</li>
                                        <li>At least one special character</li>
                                    </ul>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="confirm_password" class="form-label">Confirm Password</label>
                                <div class="input-group">
                                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                                    <button class="btn btn-outline-secondary" type="button" onclick="togglePassword('confirm_password')">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                            </div>
                            
                            <hr>
                            
                            <h5 class="section-title">
                                <i class="fas fa-car me-2"></i>Vehicle Information
                            </h5>
                            <div class="mb-3">
                                <label for="vehicle_number" class="form-label">Vehicle Number</label>
                                <input type="text" class="form-control" id="vehicle_number" name="vehicle_number" required>
                            </div>
                            <div class="mb-3">
                                <label for="vehicle_type" class="form-label">Vehicle Type</label>
                                <select class="form-select" id="vehicle_type" name="vehicle_type" required>
                                    <option value="">Select vehicle type</option>
                                    <option value="car">Car</option>
                                    <option value="motorcycle">Motorcycle</option>
                                    <option value="truck">Truck</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="vehicle_model" class="form-label">Vehicle Model</label>
                                <input type="text" class="form-control" id="vehicle_model" name="vehicle_model" required>
                            </div>
                            <div class="mb-3">
                                <label for="vehicle_color" class="form-label">Vehicle Color</label>
                                <input type="text" class="form-control" id="vehicle_color" name="vehicle_color" required>
                            </div>
                            
                            <div class="registration-footer">
                                <p>Already have an account? <a href="login.php">Login here</a></p>
                                <a href="index.php" class="btn btn-outline-secondary">
                                    <i class="fas fa-home me-2"></i>Back to Home
                                </a>
                            </div>
                            
                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary">Register</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function togglePassword(inputId) {
            const input = document.getElementById(inputId);
            input.type = input.type === 'password' ? 'text' : 'password';
        }

        function previewImage(input) {
            const preview = document.getElementById('profilePicturePreview');
            const file = input.files[0];
            
            if (file) {
                // Check file size (2MB limit)
                if (file.size > 2 * 1024 * 1024) {
                    alert('File size must be less than 2MB');
                    input.value = '';
                    return;
                }
                
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                }
                reader.readAsDataURL(file);
            }
        }
    </script>
</body>
</html> 